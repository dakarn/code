<?php

namespace BlokBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BlokBundle extends Bundle
{
}
