<?php

namespace BlokBundle\Helper;

class MenuLoader {


	public static $instance = null;
	private $loaded = false;
	private $doct;
	private $menu_arr = [];


	private function  __construct(){ }

	private function __clone(){ }


	public static function getInstance()
	{

		if( self::$instance === null )
		{
			self::$instance = new self();
		}

		return self::$instance;
	}


	private function all()
	{
		$result = $this->doct->getRepository('BlokBundle:Menu')->findBy( [], [ 'priority' => 'ASC' ] );
		$this->menu_arr = $result;
		return $result;
	}


	private function getMenu( $typeMenu )
	{
		$arr = [];

		foreach( $this->menu_arr as $key => $value )
		{
			if( $value->getType() == $typeMenu ) { $arr[] = $value; }
		}

		return $arr;
	}


	public function loader( $doct, $typeMenu )
	{

		if( !$this->loaded )
		{
			$this->doct = $doct;
			$this->loaded = true;
			$this->all();
		}

		return $this->getMenu( $typeMenu );

	}

}