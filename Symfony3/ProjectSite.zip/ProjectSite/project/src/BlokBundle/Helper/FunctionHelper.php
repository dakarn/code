<?php

namespace BlokBundle\Helper;

class FunctionHelper {


	public static function exists_value_in_arr( $str, $arr, $returntype = 'bool' )
	{
		if( !is_array( $arr )) return false;

		foreach( $arr as $key => $value )
		{
			if( key_exists( $str, $value ) )
			{
				return $returntype == 'bool' ? true : ( $returntype == 'array' ? $value : $value[$str] );
			}
		}

		return false;
	}

	public static function escapeSql($text)
	{

		$text = str_replace('"', '\"', $text);
		return str_replace("'", "\'", $text);
	}

}