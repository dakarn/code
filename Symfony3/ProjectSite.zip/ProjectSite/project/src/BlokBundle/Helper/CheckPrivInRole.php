<?php

namespace BlokBundle\Helper;


use Symfony\Component\Security\Core\Exception\AccessDeniedException;

class CheckPrivInRole {


	public static $error = [ 'Ваш аккуант не имеет привилегий для выполнения данной операции.' ];


	public function parse( $priv, $role, $roles_priv )
	{

		$find = false;
		$check_priv = explode( ':', $priv );

		$check_priv_list = explode( '--', $check_priv[1] );
		$priv_list = explode( ';', $roles_priv ); array_pop( $priv_list );

		foreach( $priv_list as $value )
		{

			$only_priv = explode( ':', $value );

			if( $check_priv[0] == $only_priv[0]  )
			{
				$item_priv = explode( '--', $only_priv[1] );

				if( in_array( $check_priv[1], $item_priv))
				{
					$find = true;
				}

			}

		}


		return $find;

	}

	public static function legal( $container, $role, $return, $priv, $roles_priv = false )
	{

		$granted = $container->get('security.authorization_checker')->isGranted($role);

		if( $granted )
		{

			if( $roles_priv !== false )
			{

				$roles_priv = $container->get('options');

				if( !static::parse( $priv, $role, $roles_priv->getRoles()[$role] ) )
				{
					if( $return ) return false;
					throw new AccessDeniedException( self::$error[0] );
				}

				return true;

			}

			return true;
		}

		if( $return ) return false;
		throw new AccessDeniedException( self::$error[0] );

	}

}