<?php

namespace BlokBundle\Helper;


class UploadFile {


	public function setUploader( $upload )
	{

		return $upload->validate();
	}
}