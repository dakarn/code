<?php

namespace BlokBundle\Helper;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints as Assert;


class ErrorsForm
{

	public static function get( $errors )
	{

		$error_text = [];

		if( !is_array( $errors ) )
		{
			return $errors;
		}

		foreach ( $errors as $key => $error )
		{
			$error_text[] = $error->getMessage();
		}

		return implode( '<br>', $error_text );
	}


}