<?php

namespace BlokBundle\Helper;

use Symfony\Component\HttpFoundation\Session\Session;


class BanExist {


	static $message = [
		'У вас имеется действующий бан, не разрешающий написание сообщений в гостевой и в новостях.',
		'У вас имеется бан, не разрешающий изменение пароля.',
		'У вас имеется действующий бан, не разрешающий создание темы на форуме.',
		'У вас имеется действующий бан, не разрешающий написание поста на форуме.',
		'У вас имеется действующий бан, который не позволяет вам изменять ваш профиль.',
		'У вас имеется действующий бан, который запрещает покупку ключей доступа или получение других платных услуг.',
		'У вас имеется действующий бан, который на дает смотреть темы на форуме и посты.',
		'У вас имеется действующий бан, запрещающий обращаться в тех. поддержку.',
		'У вас имеется действующий бан, запрещающий смотреть комментарии к новостям.',
		'У вас имеется действующий бан, запрещающий изменять свой пост в форуме.',
	];

	public static function getErrors()
	{
		return self::$message;
	}

	public static function isBan( $level, $key_text = -1 )
	{

		$session = new Session();

		if( $session->has( 'ban_user' ) )
		{
			if( $session->get( 'ban_user' )->getLevel() >= $level )
			{

				if( (int)$session->get( 'ban_user' )->getCreatedAt()+(int)($session->get( 'ban_user' )->getDuration() ) > time() )
				{
					return $key_text === -1 ? true : self::$message[$key_text];
				}

			}
		}

		return false;
	}

}