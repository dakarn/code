<?php

namespace BlokBundle\Helper\Upload;


class Upload_Bind_Picture
{

	private $max_count_file = 10;
	private $maxSize_kb = 1000;
	private $allow_format = 'JPG|JPEG|PNG|GIF|BMP|TIFF';
	private $path_upload = '';
	private $maxWH = ['w' => 800, 'h' => 800];
	private $result = [
		'Вы не отправили файл.',
		'Слишком большой размер файла. Максимальный размер %sКБ.',
		'Файл такого формата не может быть загружен. Разрешены только %s.',
		'Файл не удалось загрузить. Возникли проблемы в системе.',
		'Слишком большое разрешение изображения. Разрешение не должно превышать %dx%d',
		'Слишком большое количество файлов для прикрепления.'];

	private $files_name = [];


	public function __construct( $path_save )
	{
		$this->path_upload = $path_save;
	}

	private function existFileRename( $file )
	{

		if( !file_exists( $file )) return $file;

		$i = 0;
		$name = basename( $file );
		$dir = pathinfo( $file )['dirname'];
		$file = $dir.'/1_'.$name;

		if( file_exists( $file ))
		{
			$file = $dir.'/'.random_int(11111,999999).'_'.$name;
		}

		return $file;
	}

	public function validate()
	{

		if( empty( $_FILES['assign_file']['tmp_name'] ) ) return [true];

		if( count($_FILES['assign_file']['name'] ) > $this->max_count_file ) return [$this->result[5]];


		foreach( $_FILES['assign_file']['name'] as $key => $value )
		{

			if( empty( $_FILES['assign_file']['name'][$key] ) ) continue;


			if( $_FILES['assign_file']['size'][$key]/1000 > $this->maxSize_kb )
			{
				return [sprintf( $this->result[1], $this->maxSize_kb )];
			}


			if( !preg_match( '/\.('.$this->allow_format.')$/i' , $_FILES['assign_file']['name'][$key] ) )
			{
				return [sprintf( $this->result[2], $this->allow_format )];
			}


			$path_save = $this->existFileRename( ROOT.$this->path_upload.$_FILES['assign_file']['name'][$key] );

			if ( !move_uploaded_file( $_FILES['assign_file']['tmp_name'][$key], $path_save ) )
			{
				return [$this->result[3]];
			}


			$image = getimagesize( $path_save );

			if( $image[0] > $this->maxWH['w'] ||  $image[1] > $this->maxWH['h'] )
			{
				unlink( $path_save );
				return [sprintf( $this->result[4], $this->maxWH['w'], $this->maxWH['h'] )];
			}

			$this->files_name[] = $value;
		}

		return [ true, $this->files_name ];

	}


}