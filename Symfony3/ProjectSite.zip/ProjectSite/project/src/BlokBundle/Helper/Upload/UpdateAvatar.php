<?php

namespace BlokBundle\Helper\Upload;

use Symfony\Component\Config\Definition\Exception\Exception;


class UpdateAvatar {

	private $default_avatar = 'no-avatar.jpg';
	private $maxSize_kb = 1000;
	private $allow_format = 'JPG|JPEG|PNG|BMP';
	private $path_upload = '/assets/image/avatar/';
	private $maxWH = [ 'w' => 300, 'h' => 300];
	private $result = [
		'Вы не отправили файл.',
		'Слишком большой размер файла. Максимальный размер %sКБ.',
		'Файл такого формата не может быть загружен. Разрешены только %s.',
		'Файл не удалось загрузить. Возникли проблемы в системе.',
		'Слишком большое разрешение изображения. Разрешение не должно превышать %dx%d.' ];

	private $doct;
	private $user;

	public function __construct( $doct, $user )
	{
		$this->user = $user;
		$this->doct = $doct;
	}


	public function validate( $generate, $options )
	{

		$em = $this->doct;

		if( empty( $_FILES['avatar']['tmp_name'] ) )
		{
			throw new Exception( $this->result[0] );
		}

		if( $_FILES['avatar']['size']/1000 > $this->maxSize_kb )
		{
			throw new Exception( sprintf( $this->result[1], $this->maxSize_kb ) );
		}

		if( !preg_match( '/\.('.$this->allow_format.')$/i' , $_FILES['avatar']['name'] ) )
		{
			throw new Exception( sprintf( $this->result[2], $this->allow_format ) );
		}

		$ext = '.'.pathinfo( basename($_FILES['avatar']['name'] ) )['extension'];
		$generate_name = $generate->generateNameImage( 15 ).$ext;

		$path_save = ROOT.$this->path_upload.$generate_name;

		if ( !move_uploaded_file( $_FILES['avatar']['tmp_name'], $path_save ) )
		{
			throw new Exception( $this->result[3] );
		}


		$image = getimagesize( $path_save );

		if( $image[0] > $this->maxWH['w'] ||  $image[1] > $this->maxWH['h'] )
		{
			unlink( $path_save );
			throw new Exception( sprintf( $this->result[4], $this->maxWH['w'], $this->maxWH['h'] ) );
		}

		if( !empty( $avatar_db = $this->user->getAvatar() ) )
		{
			if( file_exists( $path_to_delete = ROOT.$options->key('path_to_avatar').$avatar_db ) )
			{
				unlink( $path_to_delete );
			}
		}

		if( $this->default_avatar != $this->user->getAvatar() )
		{
			unlink( ROOT.$options->path_to_avatar.$this->user->getAvatar() );
		}

		$this->user->setAvatar( $generate_name );
		$em->flush();

	}

}