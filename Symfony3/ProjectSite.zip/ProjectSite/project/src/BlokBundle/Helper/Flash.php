<?php


namespace BlokBundle\Helper;


use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class Flash {



	public static function exec( $container, $type, $text, $route, $params = [] )
	{

		switch( $type )
		{
			case 's': $type = 'success'; break;
			case 'i': $type = 'info'; break;
			case 'w': $type = 'warning'; break;
			case 'd': $type = 'danger'; break;

		}

		$url = $container->get('router')->generate($route, $params, UrlGeneratorInterface::ABSOLUTE_PATH);
		$container->get('notice')->add( $type, $text );
		return new RedirectResponse( $url );
	}

}