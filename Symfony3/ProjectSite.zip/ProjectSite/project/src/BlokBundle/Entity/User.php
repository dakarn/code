<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Security\Core\User\UserInterface;
use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;


/**
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\UserRepository")
 * @ORM\Table(name="users")
 */
class User implements UserInterface, \Serializable
{


	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	public $id;

	/**
	 * @ORM\Column(type="string", length=255, unique=true)
	 */
	private $username;


	/**
	 * @ORM\Column(type="string", length=255, unique=true)
	 */
	public $email;

	/**
	 * @ORM\Column(type="string")
	 */
	public $password;

	/**
	 * @ORM\Column(type="string")
	 */
	public $role;

	/**
	 * @ORM\Column(type="string")
	 */
	public $avatar;

	/**
	 * @ORM\Column(type="integer")
	 */
	public $age;

	/**
	 * @ORM\Column(type="string")
	 */
	public $gender;

	/**
	 * @ORM\Column(type="integer")
	 */
	public $countpost;

	/**
	 * @ORM\Column(type="string")
	 */
	public $country;

	/**
	 * @ORM\Column(type="string")
	 */
	public $city;

	/**
	 * @ORM\Column(type="integer")
	 */
	public $created_at;

	/**
	 * @ORM\Column(type="boolean")
	 */
	public $is_active;
	
	/**
	 * @ORM\Column(type="integer")
	 */
	public $updated_at;

	/**
	 * @ORM\Column(type="string")
	 */
	public $last_enter;
	/**
	 * @ORM\Column(type="string")
	 */
	public $activation_key;

	/**
	 * @ORM\Column(type="integer")
	 */
	public $balance;


	public $salt;

	/**
	 *
	 * @return string The salt.
	 */
	public function getSalt()
	{
		return null;
	}

	public function getActivationKey()
	{
		return $this->activation_key;
	}

	public function setActivationKey($activation_key)
	{
		$this->activation_key = $activation_key;
		return $this;
	}

	public function getEmail()
	{
		return $this->email;
	}

	public function setEmail($email)
	{
		$this->email = $email;
		return $this;
	}

	public function getBalance()
	{
		return $this->balance;
	}

	public function setBalance($balance)
	{
		$this->balance = $balance;
		return $this;
	}

	public function getUsername()
	{
		return $this->username;
	}

	public function setUsername($username)
	{
		$this->username = $username;
		return $this;
	}

	public function getPassword()
	{
		return $this->password;
	}

	public function setPassword($password)
	{
		$this->password = $password;
		return $this;
	}


	public function eraseCredentials()
	{
	}

	public function setRoles( $role )
	{
		$this->role = $role;
		return $this;
	}

	public function getRoles()
	{
		return explode( ',', $this->role );
	}

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('username', new NotBlank( [ 'message'=>'Поле Login не может быть пустым.'] ));
		$metadata->addPropertyConstraint('password', new NotBlank( [ 'message'=>'Поле Password не может быть пустым.'] ));
		$metadata->addPropertyConstraint('email', new Assert\Email( [ 'message'=>'Поле E-mail не заполнено, как надо.'] ));
		$metadata->addPropertyConstraint('email', new NotBlank( [ 'message'=>'Поле E-mail не заполнено, как надо.'] ));
		$metadata->addPropertyConstraint('gender', new Assert\Choice( [ 'choices' => [ 'man', 'woman', '' ], 'message'=>'Не верно указан пол.'] ));
		$metadata->addPropertyConstraint('age', new NotBlank( [ 'message'=>'Поле Age не заполнено, как надо.'] ));
	}


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set age
     *
     * @param integer $age
     *
     * @return User
     */
    public function setAge($age)
    {
        $this->age = $age;

        return $this;
    }

    /**
     * Get age
     *
     * @return integer
     */
    public function getAge()
    {
        return $this->age;
    }

    /**
     * Set gender
     *
     * @param string $gender
     *
     * @return User
     */
    public function setGender($gender)
    {
        $this->gender = $gender;

        return $this;
    }

    /**
     * Get gender
     *
     * @return string
     */
    public function getGender()
    {
        return $this->gender;
    }

    /**
     * Set createdAt
     *
     * @param integer $createdAt
     *
     * @return User
     */
    public function setCreatedAt($createdAt)
    {
        $this->created_at = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return integer
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * Set isActive
     *
     * @param boolean $isActive
     *
     * @return User
     */
    public function setIsActive($isActive)
    {
        $this->is_active = $isActive;

        return $this;
    }

    /**
     * Get isActive
     *
     * @return boolean
     */
    public function getIsActive()
    {
        return $this->is_active;
    }

	public function serialize()
	{
		return serialize(array(
			$this->id,
			$this->username,
			$this->password,
		));
	}


	public function unserialize($serialized)
	{
		list (
			$this->id,
			$this->username,
			$this->password,
			) = unserialize($serialized);
	}

    /**
     * Set role
     *
     * @param string $role
     *
     * @return User
     */
    public function setRole($role)
    {
        $this->role = $role;

        return $this;
    }

    /**
     * Get role
     *
     * @return string
     */
    public function getRole()
    {
        return $this->role;
    }

    /**
     * Set updatedAt
     *
     * @param integer $updatedAt
     *
     * @return User
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updated_at = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return integer
     */
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }

    /**
     * Set lastEnter
     *
     * @param string $lastEnter
     *
     * @return User
     */
    public function setLastEnter($lastEnter)
    {
        $this->last_enter = $lastEnter;

        return $this;
    }

    /**
     * Get lastEnter
     *
     * @return string
     */
    public function getLastEnter()
    {
        return $this->last_enter;
    }

    /**
     * Set avatar
     *
     * @param string $avatar
     *
     * @return User
     */
    public function setAvatar($avatar)
    {
        $this->avatar = $avatar;

        return $this;
    }

    /**
     * Get avatar
     *
     * @return string
     */
    public function getAvatar()
    {
        return $this->avatar;
    }

	public function getMessages()
	{
		return $this->messages;
	}

	public function getBalanceFilter( )
	{

		$balance = $this->balance;

		$end_str = substr( $balance, -2 );

		if( $end_str == '00' )
		{
			$balance = substr( $balance, 0, strlen( $balance)-2 );
			$balance .= '.00';

		} else {

			$balance = substr( $balance, 0, strlen( $balance)-2 );
			$balance .= '.'.$end_str;
		}

		return $balance;
	}

	public function setBalanceFilter( $balance )
	{

		if( !strpos( $balance,'.' ) )
		{
			$balance .= '.00';
		}

		if( preg_match( '/^[0-9]{1,10}\.[0-9]{2}$/',$balance ) )
		{
			$balance = str_replace( '.', '', $balance );
		}

		if( preg_match( '/^[0-9]{1,10}\.[0-9]{1}$/',$balance ) )
		{
			$balance = str_replace( '.', '', $balance ).'0';
		}

		$this->balance = $balance;
		return $this;
	}

    /**
     * Set countpost
     *
     * @param integer $countpost
     *
     * @return User
     */
    public function setCountpost($countpost)
    {
        $this->countpost = $countpost;

        return $this;
    }

    /**
     * Get countpost
     *
     * @return integer
     */
    public function getCountpost()
    {
        return $this->countpost;
    }

    /**
     * Set country
     *
     * @param string $country
     *
     * @return User
     */
    public function setCountry($country)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return string
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Set city
     *
     * @param string $city
     *
     * @return User
     */
    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get city
     *
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }
}
