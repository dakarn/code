<?php

namespace BlokBundle\Entity\FormValidator\Admin;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints as Assert;


class NewsValidator
{
	public $title;
	public $message;

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('title', new NotBlank( [ 'message'=>'Не введен заголовок новости.'] ));
		$metadata->addPropertyConstraint('message', new NotBlank( [ 'message' => 'Не введен текст новости.'] ));
	}


}