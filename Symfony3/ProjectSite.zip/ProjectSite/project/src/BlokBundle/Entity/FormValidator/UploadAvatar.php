<?php

namespace BlokBundle\Entity\FormValidator;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints as Assert;
use Symfony\Component\HttpFoundation\File\File;

class UploadAvatar
{

	public $avatar;


	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('avatar', new Assert\File( [ 'maxSize' => '100k',
			'mimeTypes' => [
				'image/png',
				'image/jpg' ] ] ) );
	}


}