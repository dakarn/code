<?php

namespace BlokBundle\Entity\FormValidator;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints as Assert;
use Captcha\Bundle\CaptchaBundle\Validator\Constraints as CaptchaAssert;

class CommentNewsValidator
{

	public $message;


	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{

		$metadata->addPropertyConstraint('message', new NotBlank( [ 'message'=>'Вы не ввели текст комментария.'] ));

	}


}