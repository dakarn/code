<?php

namespace BlokBundle\Entity\FormValidator\Admin;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints as Assert;


class AddForumValidator
{

	public $forum_title;

	public function __construct()
	{
		$this->forum_title = $_POST['forum_title'];
	}

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('forum_title', new Assert\NotBlank( [ 'message'=>'Поле "Название" не может быть пустым.'] ));
	}


}