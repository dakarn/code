<?php

namespace BlokBundle\Entity\FormValidator;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints as Assert;

class SendSMSValidator
{
	public $phone;
	public $message;
	public $theme;
	public $keyCode;
	public $from;

	public function setData()
	{
		$this->keyCode = $_GET['keyCode'];
		$this->message = $_POST['message'];
		$this->theme = $_POST['theme'];
		$this->phone = $_POST['phone'];
		$this->from = $_POST['from'];
	}

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('phone', new Assert\Regex([ 'pattern' => '/^8[0-9]{3}[0-9]{3}[0-9]{4}$/', 'message' => 'Неправильный формат номера телефона.']));
		$metadata->addPropertyConstraint('phone', new NotBlank([ 'message' => 'Не введен номер телефона.']));
		$metadata->addPropertyConstraint('message', new NotBlank([ 'message' => 'Поле с Сообщением не может быть пустым.']));
		$metadata->addPropertyConstraint('theme', new NotBlank([ 'message' => 'Поле с Темой не может быть пустым.']));
		$metadata->addPropertyConstraint('keyCode', new NotBlank([ 'message' => 'Вы не ввели ключ.']));
		$metadata->addPropertyConstraint('from', new NotBlank([ 'message' => 'Вы не заполнили поле "От кого".']));
	}


}