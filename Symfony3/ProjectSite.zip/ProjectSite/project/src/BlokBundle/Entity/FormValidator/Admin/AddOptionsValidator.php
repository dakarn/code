<?php

namespace BlokBundle\Entity\FormValidator\Admin;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints as Assert;


class AddOptionsValidator
{

	public $name_options;
	public $type_options;
	public $type_form_options;

	public function __construct()
	{
		$this->name_options = $_POST['name_options'];
		$this->type_options = $_POST['type_options'];
		$this->type_form_options = $_POST['type_form_options'];
	}
	
	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('name_options', new Assert\NotBlank( [ 'message'=>'Поле с "Имя" не может быть пустым.'] ));
		$metadata->addPropertyConstraint('type_options', new Assert\NotBlank( [ 'message'=>'Поле с "Тип опции" бана не может быть пустым.'] ));
		$metadata->addPropertyConstraint('type_form_options', new Assert\NotBlank( [ 'message' => 'Поле с "Тип поля" не может быть пустым.'] ));
	}


}