<?php

namespace BlokBundle\Entity\FormValidator;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints as Assert;
use Captcha\Bundle\CaptchaBundle\Validator\Constraints as CaptchaAssert;

class GuestValidator
{
	public $login;
	public $message;
    public $captchaCode;

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('login', new NotBlank( [ 'message'=>'Вы не ввели свое имя.'] ));
		//$metadata->addPropertyConstraint('captchaCode', new CaptchaAssert\ValidCaptcha( [ 'message'=>'Код с картинки введен не правильно.'] ));
		$metadata->addPropertyConstraint('message', new NotBlank( [ 'message'=>'Поле с Сообщением не может быть пустым.'] ));
		$metadata->addPropertyConstraint('message', new Assert\Length(
			[ 'min' => 2, 'max' => 500,
			  'minMessage'=>'Сообщение должно быть длиннее {{ limit }} символов.',
			  'maxMessage' => 'Сообщение слишком длинное, Не более {{ limit }} символов'] ));
	}


}