<?php

namespace BlokBundle\Entity\FormValidator;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints as Assert;


class EditProfileValidator
{

	public $username;
	public $email;
	public $gender;
	public $age;
	public $city;
	public $country;

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('username', new NotBlank( [ 'message'=>'Поле "Username" не может быть пустым.'] ));
		$metadata->addPropertyConstraint('email', new Assert\Email( [ 'message'=>'Поле "Email" не правильно заполнено.'] ));
		$metadata->addPropertyConstraint('email', new NotBlank( [ 'message'=>'Поле "Email" не может быть пустым.'] ));
		$metadata->addPropertyConstraint('age', new NotBlank( [ 'message'=>'Поле "Age" не может быть пустым.'] ));
		$metadata->addPropertyConstraint('country', new NotBlank( [ 'message'=>'Поле Country не заполнено.'] ));
		$metadata->addPropertyConstraint('city', new NotBlank( [ 'message'=>'Поле City не заполнено.'] ));
		$metadata->addPropertyConstraint('gender', new Assert\Choice( [ 'choices' => [ 'man', 'woman', 'other'] , 'message'=>'Поле "Age" не может быть пустым.'] ));
	}


}