<?php

namespace BlokBundle\Entity\FormValidator\Admin;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints as Assert;


class CommonValidator
{
	public $protocol;
	public $site_url;
	public $admin_email;
	public $title;
	public $keywords;
	public $enable_guest;
	public $activate_user;
	public $subscribe_email;
	public $enable_register;

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('protocol', new Assert\Choice( [ 'choices' => ['http', 'https'],  'message'=>'Не верно заполнен протокол.'] ));
		$metadata->addPropertyConstraint('title', new NotBlank( [ 'message'=>'Не введен заголовок главной страницы.'] ));
		$metadata->addPropertyConstraint('site_url', new NotBlank( [ 'message' => 'Не введен адрес сайта'] ));
		$metadata->addPropertyConstraint('admin_email', new Assert\Email( [ 'message' => 'Введен не правильный E-mail'] ));
	}


}