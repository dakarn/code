<?php

namespace BlokBundle\Entity\FormValidator\Admin;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints as Assert;


class BannedValidator
{
	public $cause;
	public $duration;
	public $level;

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('cause', new NotBlank( [ 'message'=>'Поле с "Причиной" не может быть пустым.'] ));
		$metadata->addPropertyConstraint('duration', new NotBlank( [ 'message'=>'Поле с "Длительность" бана не может быть пустым.'] ));
		$metadata->addPropertyConstraint('level', new Assert\Type( [ 'type' => 'integer', 'message' => 'Введен не допустимый уровень бана, возможно вы ошиблись в цифрах'] ));
		$metadata->addPropertyConstraint('level', new NotBlank( [ 'message' => 'Введен не допустимый уровень бана, возможно вы ошиблись в цифрах'] ));
	}


}