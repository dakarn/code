<?php

namespace BlokBundle\Entity\FormValidator;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints as Assert;

class RegisterValid
{
	public $username;
	public $password;
	public $email;
    public $age;
    public $gender;
    public $country;
    public $city;

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('username', new NotBlank( [ 'message'=>'Поле Login не может быть пустым.'] ));
		$metadata->addPropertyConstraint('password', new NotBlank( [ 'message'=>'Поле Password не может быть пустым.'] ));
		$metadata->addPropertyConstraint('email', new Assert\Email( [ 'message'=>'Поле E-mail не заполнено, как надо.'] ));
		$metadata->addPropertyConstraint('email', new NotBlank( [ 'message'=>'Поле E-mail не заполнено, как надо.'] ));
		$metadata->addPropertyConstraint('gender', new Assert\Choice( [ 'choices' => [ 'woman', 'man', 'other' ], 'message'=>'Не верно указан пол.'] ));
		$metadata->addPropertyConstraint('age', new NotBlank( [ 'message'=>'Поле Age не заполнено, как надо.'] ));
		$metadata->addPropertyConstraint('country', new NotBlank( [ 'message'=>'Поле Country не заполнено.'] ));
		$metadata->addPropertyConstraint('city', new NotBlank( [ 'message'=>'Поле City не заполнено.'] ));
	}


}