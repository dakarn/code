<?php

namespace BlokBundle\Entity\FormValidator;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints as Assert;

class ThemeValidator
{
	public $title;
	public $message;


	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{

		$metadata->addPropertyConstraint('message', new NotBlank([ 'message' => 'Поле с Сообщением не может быть пустым.']));
		$metadata->addPropertyConstraint('title', new NotBlank([ 'message' => 'Поле с Темой не может быть пустым.']));

	}


}