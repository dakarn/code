<?php

namespace BlokBundle\Entity\FormValidator;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints as Assert;
use Captcha\Bundle\CaptchaBundle\Validator\Constraints as CaptchaAssert;

class MoneybackValidator
{
	public $service;
	public $cause;

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('service', new NotBlank( [ 'message'=>'Вы не указали услугу.'] ));
		$metadata->addPropertyConstraint('cause', new NotBlank( [ 'message'=>'Вы не указали причину. Без причины средства не возвращаются.'] ));
	}


}