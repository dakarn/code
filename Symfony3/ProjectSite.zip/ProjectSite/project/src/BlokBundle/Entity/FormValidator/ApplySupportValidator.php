<?php

namespace BlokBundle\Entity\FormValidator;

use Symfony\Component\Validator\Mapping\ClassMetadata;
use Symfony\Component\Validator\Constraints\NotBlank;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints as Assert;
use Captcha\Bundle\CaptchaBundle\Validator\Constraints as CaptchaAssert;

class ApplySupportValidator
{
	public $desc;
	public $message;
	public $type_cause;

	public function __construct()
	{
		$this->desc = $_POST['desc'];
		$this->message = $_POST['message'];
		$this->type_cause = $_POST['type_cause'];
	}

	public static function loadValidatorMetadata(ClassMetadata $metadata)
	{
		$metadata->addPropertyConstraint('desc', new NotBlank( [ 'message'=>'Вы не указали краткое описание проблемы.'] ));
		$metadata->addPropertyConstraint('message', new NotBlank( [ 'message'=>'Вы не указали подробное описание проблемы.'] ));
		$metadata->addPropertyConstraint('type_cause', new NotBlank( [ 'message'=>'Такого типа проблемы не найдено.'] ));
	}


}