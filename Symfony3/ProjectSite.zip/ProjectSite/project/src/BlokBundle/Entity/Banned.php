<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Banned
 *
 * @ORM\Table(name="banned_users")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\BannedRepository")
 */
class Banned
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;


    /**
     * @var int
     *
     * @ORM\Column(name="duration", type="integer")
     */
    private $duration;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="created_at", type="integer")
	 */
	private $created_at;

    /**
     * @var string
     *
     * @ORM\Column(name="cause", type="string", length=255)
     */
    private $cause;

    /**
     * @var int
     *
     * @ORM\Column(name="level", type="integer")
     */
    private $level;

    /**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $userId;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set duration
     *
     * @param integer $duration
     *
     * @return Banned
     */
    public function setDuration($duration)
    {
        $this->duration = $duration;

        return $this;
    }

    /**
     * Get duration
     *
     * @return int
     */
    public function getDuration()
    {
        return $this->duration;
    }

	public function setCreatedAt($created_at)
	{
		$this->created_at = $created_at;

		return $this;
	}

	/**
	 * Get duration
	 *
	 * @return int
	 */
	public function getCreatedAt()
	{
		return $this->created_at;
	}

    /**
     * Set cause
     *
     * @param string $cause
     *
     * @return Banned
     */
    public function setCause($cause)
    {
        $this->cause = $cause;

        return $this;
    }

	public function getUser()
	{
		return $this->user;
	}

    /**
     * Get cause
     *
     * @return string
     */
    public function getCause()
    {
        return $this->cause;
    }

    /**
     * Set level
     *
     * @param integer $level
     *
     * @return Banned
     */
    public function setLevel($level)
    {
        $this->level = $level;

        return $this;
    }

    /**
     * Get level
     *
     * @return int
     */
    public function getLevel()
    {
        return $this->level;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return Banned
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return int
     */
    public function getUserId()
    {
        return $this->userId;
    }
}

