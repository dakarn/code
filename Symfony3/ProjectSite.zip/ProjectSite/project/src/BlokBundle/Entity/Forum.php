<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Forum
 *
 * @ORM\Table(name="forum")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\ForumRepository")
 */
class Forum
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=100)
     */
    private $title;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="icon", type="string", length=100)
	 */
	private $icon;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="updated_at_text", type="string", length=100)
	 */
	private $updatedAtText;

    /**
     * @var int
     *
     * @ORM\Column(name="count_theme", type="integer")
     */
    private $countTheme;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="isclose", type="integer")
	 */
	private $isclose;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="last_message_id", type="integer")
	 */
	private $lastMessageId;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="last_author_id", type="integer")
	 */
	private $last_author_id;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="last_author", type="string")
	 */
	private $last_author;

    /**
     * @var int
     *
     * @ORM\Column(name="count_posts", type="integer")
     */
    private $countPosts;

    /**
     * @var int
     *
     * @ORM\Column(name="parent_id", type="integer")
     */
    private $parentId;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Forum
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set countTheme
     *
     * @param integer $countTheme
     *
     * @return Forum
     */
    public function setCountTheme($countTheme)
    {
        $this->countTheme = $countTheme;

        return $this;
    }

    /**
     * Get countTheme
     *
     * @return int
     */
    public function getCountTheme()
    {
        return $this->countTheme;
    }

    /**
     * Set countPosts
     *
     * @param integer $countPosts
     *
     * @return Forum
     */
    public function setCountPosts($countPosts)
    {
        $this->countPosts = $countPosts;

        return $this;
    }

    /**
     * Get countPosts
     *
     * @return int
     */
    public function getCountPosts()
    {
        return $this->countPosts;
    }

    /**
     * Set parentId
     *
     * @param integer $parentId
     *
     * @return Forum
     */
    public function setParentId($parentId)
    {
        $this->parentId = $parentId;

        return $this;
    }

    /**
     * Get parentId
     *
     * @return int
     */
    public function getParentId()
    {
        return $this->parentId;
    }

	public function setIcon($icon)
	{
		$this->icon = $icon;

		return $this;
	}

	public function getIcon()
	{
		return $this->icon;
	}

    /**
     * Set lastMessageId
     *
     * @param integer $lastMessageId
     *
     * @return Forum
     */
    public function setLastMessageId($lastMessageId)
    {
        $this->lastMessageId = $lastMessageId;

        return $this;
    }

    /**
     * Get lastMessageId
     *
     * @return integer
     */
    public function getLastMessageId()
    {
        return $this->lastMessageId;
    }

    /**
     * Set lastAuthorId
     *
     * @param integer $lastAuthorId
     *
     * @return Forum
     */
    public function setLastAuthorId($lastAuthorId)
    {
        $this->last_author_id = $lastAuthorId;

        return $this;
    }

    /**
     * Get lastAuthorId
     *
     * @return integer
     */
    public function getLastAuthorId()
    {
        return $this->last_author_id;
    }

    /**
     * Set lastAuthor
     *
     * @param string $lastAuthor
     *
     * @return Forum
     */
    public function setLastAuthor($lastAuthor)
    {
        $this->last_author = $lastAuthor;

        return $this;
    }

    /**
     * Get lastAuthor
     *
     * @return string
     */
    public function getLastAuthor()
    {
        return $this->last_author;
    }

    /**
     * Set isclose
     *
     * @param integer $isclose
     *
     * @return Forum
     */
    public function setIsclose($isclose)
    {
        $this->isclose = $isclose;

        return $this;
    }

    /**
     * Get isclose
     *
     * @return integer
     */
    public function getIsclose()
    {
        return $this->isclose;
    }

    /**
     * Set updateAtText
     *
     * @param string $updateAtText
     *
     * @return Forum
     */
    public function setUpdatedAtText($updatedAtText)
    {
        $this->updatedAtText = $updatedAtText;

        return $this;
    }

    /**
     * Get updateAtText
     *
     * @return string
     */
    public function getUpdatedAtText()
    {
        return $this->updatedAtText;
    }
}
