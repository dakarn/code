<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * SMS
 *
 * @ORM\Table(name="sms")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\SMSRepository")
 */
class SMS
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="message", type="string", length=300)
     */
    private $message;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="from_whom", type="string", length=300)
	 */
	private $from;

    /**
     * @var string
     *
     * @ORM\Column(name="theme", type="string", length=60)
     */
    private $theme;

    /**
     * @var int
     *
     * @ORM\Column(name="created_at", type="integer")
     */
    private $createdAt;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="user_id", type="integer")
	 */
	private $user_id;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="key_code", type="string", length=50)
	 */
	private $keycode;

    /**
     * @var int
     *
     * @ORM\Column(name="phone_number", type="integer")
     */
    private $phoneNumber;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set message
     *
     * @param string $message
     *
     * @return SMS
     */
    public function setMessage($message)
    {
        $this->message = $message;

        return $this;
    }

    /**
     * Get message
     *
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * Set theme
     *
     * @param string $theme
     *
     * @return SMS
     */
    public function setTheme($theme)
    {
        $this->theme = $theme;

        return $this;
    }

    /**
     * Get theme
     *
     * @return string
     */
    public function getTheme()
    {
        return $this->theme;
    }

    /**
     * Set createdAt
     *
     * @param integer $createdAt
     *
     * @return SMS
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return int
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set phoneNumber
     *
     * @param integer $phoneNumber
     *
     * @return SMS
     */
    public function setPhoneNumber($phoneNumber)
    {
        $this->phoneNumber = $phoneNumber;

        return $this;
    }

    /**
     * Get phoneNumber
     *
     * @return int
     */
    public function getPhoneNumber()
    {
        return $this->phoneNumber;
    }


	public function setUserId($userid)
	{
		$this->user_id = $userid;

		return $this;
	}

	public function getUserId()
	{
		return $this->user_id;
	}

	public function setKeycode($keycode)
	{
		$this->keycode = $keycode;

		return $this;
	}

	public function getKeycode()
	{
		return $this->keycode;
	}

    /**
     * Set from
     *
     * @param string $from
     *
     * @return SMS
     */
    public function setFrom($from)
    {
        $this->from = $from;

        return $this;
    }

    /**
     * Get from
     *
     * @return string
     */
    public function getFrom()
    {
        return $this->from;
    }
}
