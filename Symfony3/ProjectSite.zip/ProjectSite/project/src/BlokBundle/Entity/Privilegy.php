<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Privilegy
 *
 * @ORM\Table(name="privilegy")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\PrivilegyRepository")
 */
class Privilegy
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255, unique=true)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="discription", type="string", length=255)
     */
    private $discription;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Privilegy
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Set description
     *
     * @param string $description
     *
     * @return Privilegy
     */
    public function setDescription($discription)
    {
        $this->discription = $discription;

        return $this;
    }

    /**
     * Get description
     *
     * @return string
     */
    public function getdiscription()
    {
        return $this->discription;
    }
}

