<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * News
 *
 * @ORM\Table(name="news")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\NewsRepository")
 */
class News
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255)
     */
    private $title;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="files", type="string", length=1000)
	 */
	private $files;

    /**
     * @var string
     *
     * @ORM\Column(name="text", type="string", length=800)
     */
    private $text;

    /**
     * @var int
     *
     * @ORM\Column(name="created_at", type="integer")
     */
    private $createdAt;

    /**
     * @var int
     *
     * @ORM\Column(name="count_comment", type="integer")
     */
    private $countComment;

    /**
     * @var int
     *
     * @ORM\Column(name="count_views", type="integer")
     */
    private $countViews;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="close_comment", type="integer")
	 */
	private $closeComment;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return News
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set text
     *
     * @param string $text
     *
     * @return News
     */
    public function setText($text)
    {
        $this->text = $text;

        return $this;
    }

    /**
     * Get text
     *
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * Set createdAt
     *
     * @param integer $createdAt
     *
     * @return News
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return int
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set countComment
     *
     * @param integer $countComment
     *
     * @return News
     */
    public function setCountComment($countComment)
    {
        $this->countComment = $countComment;

        return $this;
    }

    /**
     * Get countComment
     *
     * @return int
     */
    public function getCountComment()
    {
        return $this->countComment;
    }


    public function setCountViews($countViews)
    {
        $this->countViews = $countViews;

        return $this;
    }


    public function getCountViews()
    {
        return $this->countViews;
    }

    /**
     * Set closeComment
     *
     * @param integer $closeComment
     *
     * @return News
     */
    public function setCloseComment($closeComment)
    {
        $this->closeComment = $closeComment;

        return $this;
    }

    /**
     * Get closeComment
     *
     * @return integer
     */
    public function getCloseComment()
    {
        return $this->closeComment;
    }

    /**
     * Set files
     *
     * @param string $files
     *
     * @return News
     */
    public function setFiles($files)
    {
        $this->files = $files;

        return $this;
    }

    /**
     * Get files
     *
     * @return string
     */
    public function getFiles()
    {
        return $this->files;
    }
}
