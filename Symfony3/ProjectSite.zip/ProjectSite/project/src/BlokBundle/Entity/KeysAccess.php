<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * KeysAccess
 *
 * @ORM\Table(name="keys_access")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\KeysAccessRepository")
 */
class KeysAccess
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="key_code", type="string", length=255, unique=true)
     */
    private $keyCode;

    /**
     * @var int
     *
     * @ORM\Column(name="created_at", type="integer")
     */
    private $createdAt;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="type_key", type="string")
	 */
	private $keyType;

    /**
     * @var int
     *
     * @ORM\Column(name="updated_at", type="integer")
     */
    private $updatedAt;

    /**
     * @var int
     *
     * @ORM\Column(name="expires_at", type="integer")
     */
    private $expiresAt;

    /**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $userId;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set keyCode
     *
     * @param string $keyCode
     *
     * @return KeysAccess
     */
    public function setKeyCode($keyCode)
    {
        $this->keyCode = $keyCode;

        return $this;
    }

    /**
     * Get keyCode
     *
     * @return string
     */
    public function getKeyCode()
    {
        return $this->keyCode;
    }


	public function setKeyType($keyType)
	{
		$this->keyType = $keyType;

		return $this;
	}


	public function getKeyType()
	{
		return $this->keyType;
	}

    /**
     * Set createdAt
     *
     * @param integer $createdAt
     *
     * @return KeysAccess
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return int
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param integer $updatedAt
     *
     * @return KeysAccess
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return int
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set expiresAt
     *
     * @param integer $expiresAt
     *
     * @return KeysAccess
     */
    public function setExpiresAt($expiresAt)
    {
        $this->expiresAt = $expiresAt;

        return $this;
    }

    /**
     * Get expiresAt
     *
     * @return int
     */
    public function getExpiresAt()
    {
        return $this->expiresAt;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return KeysAccess
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return int
     */
    public function getUserId()
    {
        return $this->userId;
    }
}

