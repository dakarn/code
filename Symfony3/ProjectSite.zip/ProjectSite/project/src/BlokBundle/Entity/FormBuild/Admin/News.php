<?php

namespace BlokBundle\Entity\FormBuild\Admin;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;


class News extends AbstractType {


	public $title;
	public $message;
	public $level;

	public function buildForm( FormBuilderInterface $builder , array $options )
	{

		$builder->add('title', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Заголовок новости: *'] )
			->add('message', TextareaType::class, [ 'required'=>true, 'label' => 'Текст новости: * ', 'attr' => ['class'=>'form-control']  ] );

	}
}