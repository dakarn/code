<?php

namespace BlokBundle\Entity\FormBuild;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\RepeatedType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Validator\Constraints\Choice;


class Registration extends AbstractType {


	public $username;
	public $password;
	public $email;
	public $age;
	public $gender;
	public $city;
	public $country;

	public function buildForm( FormBuilderInterface $builder , array $options )
	{

		$builder->add('username', TextType::class,
			[ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Логин ( не более 20 букв): *'] )
		->add('password', RepeatedType::class,
			['required'=>false, 'type' => PasswordType::class,
			 'invalid_message' => 'Введеные пароли не совпадают.',
			 'first_options'  => [ 'label' => 'Пароль  ( не менее 6 букв и не более 30 ): *', 'attr' => ['class'=>'form-control'] ],
			 'second_options' => [ 'label' => 'Повторите пароль: *', 'attr' => ['class'=>'form-control'] ] ] )
		->add('email', TextType::class, [ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'E-mail: *'] )
		->add('country', TextType::class, [ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Страна: *'] )
		->add('city', TextType::class, [ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Город: *'] )
		->add('age', IntegerType::class, [  'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Сколько вам лет?: *'] )
		->add('gender', ChoiceType::class, [
			'choices'  => array(
				'Другое' => 'other',
				'Мужской' => 'man',
				'Женский' => 'woman' ),
			'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Ваш пол: *'] )
		->add('save', SubmitType::class, [ 'attr' => ['class'=>'btn btn-primary btn-lg'], 'label'=>'Продолжить регистрацию'] );

	}
}