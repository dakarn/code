<?php

namespace BlokBundle\Entity\FormBuild\Admin;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;

class CommonSetting extends AbstractType {


	public $title;
	public $keywords;
	public $subscribe_email;
	public $enable_guest;
	public $enable_register;
	public $activate_user;
	public $admin_email;
	public $site_url;
	public $protocol;


	public function buildForm( FormBuilderInterface $builder , array $options )
	{

		$builder
			->add('title', TextType::class, [ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Заголовок главной страницы:'] )
			->add('keywords', TextType::class, [ 'required'=>false, 'label' => 'Ключевве слова для поисковиков:', 'attr' => ['class'=>'form-control']  ] )
			->add('enable_guest', CheckboxType::class, [ 'required'=>false, 'attr' => [], 'label'=>'Гостевая книга включена:'] )
			->add('subscribe_email', CheckboxType::class, [ 'required'=>false, 'attr' => [], 'label'=>'Возможнсть подписки на события включена:'] )
			->add('enable_register', CheckboxType::class, [  'required'=>false, 'attr' => [], 'label'=>'Регистрация включена:'] )
			->add('activate_user', CheckboxType::class, [  'required'=>false, 'attr' => [], 'label'=>'Активировать нового юзера автоматичски:'] )
			->add('site_url', TextType::class, [  'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Адрес сайта без http/https:'] )
			->add('protocol', TextType::class, [  'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Протокол сайта( http или https ):'] )
			->add('admin_email', EmailType::class, [  'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Email администратора:'] );

	}
}