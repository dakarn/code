<?php

namespace BlokBundle\Entity\FormBuild;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;


class EditProfile extends AbstractType {


	public $username;
	public $email;
	public $age;
	public $gender;
	public $city;
	public $country;

	public function buildForm( FormBuilderInterface $builder , array $options )
	{

		$builder
			->add('username', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Логин ( не более 20 букв): *'] )
			->add('email', EmailType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'E-mail: *'] )
			->add('email', TextType::class, [ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'E-mail: *'] )
			->add('country', TextType::class, [ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Страна: *'] )
			->add('city', TextType::class, [ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Город: *'] )
			->add('age', IntegerType::class, [  'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Сколько вам лет?: *'] )
			->add('gender', ChoiceType::class, [
					'choices'  => array(
						'Другое' => 'other',
						'Мужской' => 'man',
						'Женский' => 'woman' ),
					'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Ваш пол: *']
			);

	}
}