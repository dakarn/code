<?php

namespace BlokBundle\Entity\FormBuild;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Validator\Constraints\NotBlank;



class SendSMS extends AbstractType {


	public $keyCode;
	public $phone;
	public $message;
	public $theme;
	public $from;


	public function buildForm( FormBuilderInterface $builder , array $options )
	{
		$builder->add('keyCode', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Используемый ключ: *'] )
			->add('phone', NumberType::class,
			[ 'required'=>true, 'attr' => [ 'class'=>'form-control'], 'label'=>'Номер телефона: ( пример 89993332234 ) *'] )
			->add('theme', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Тема: *'] )
			->add('from', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'От кого: *'] )
			->add('message', TextareaType::class, [ 'required'=>true, 'attr' => [ 'rows' => '5', 'class'=>'form-control'], 'label'=>'Сообщение: *'] );

	}
}