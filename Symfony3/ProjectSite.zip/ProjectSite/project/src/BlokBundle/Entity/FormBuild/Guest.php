<?php

namespace BlokBundle\Entity\FormBuild;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Captcha\Bundle\CaptchaBundle\Form\Type\CaptchaType;



class Guest extends AbstractType {


	public $login;
	public $message;


	public function buildForm( FormBuilderInterface $builder , array $options )
	{
		$builder->add('login', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Имя: *'] )
			->add('message', TextareaType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Сообщение: *'] )
			->add('captchaCode', CaptchaType::class, [ 'captchaConfig' => 'ExampleCaptcha', 'attr' => ['class'=>'form-control', 'style'=>'width:260px;'], 'label' => 'Введите код с картинки: *' ] )
			->add('save', SubmitType::class, [ 'attr' => ['class'=>'btn btn-primary btn-lg'], 'label'=>'Отправить'] );

	}
}