<?php

namespace BlokBundle\Entity\FormBuild;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;


class Theme extends AbstractType {


	public $title;
	public $message;


	public function buildForm( FormBuilderInterface $builder , array $options )
	{
		$builder->add('title', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Заголовок темы: *'] )
			->add('message', TextareaType::class, [ 'required'=>true, 'attr' => [ 'rows' => '8', 'class'=>'form-control'], 'label'=>'Сообщение: *'] );

	}
}