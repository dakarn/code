<?php

namespace BlokBundle\Entity\FormBuild;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;


class Moneyback extends AbstractType {


	public $cause;
	public $service;


	public function buildForm( FormBuilderInterface $builder , array $options )
	{
		$builder->add('service', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Услуга, по которой хотите вернуть средства: *'] )
			->add('cause', TextareaType::class, [ 'required'=>true, 'attr' => [ 'class'=>'form-control'], 'label'=>'Причина MoneyBack: *'] );

	}
}