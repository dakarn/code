<?php

namespace BlokBundle\Entity\FormBuild;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Validator\Constraints\NotBlank;



class Login extends AbstractType {


	public $username;
	public $password;


	public function buildForm( FormBuilderInterface $builder , array $options )
	{
		$builder->add('username', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Логин: *'] )
			->add('password', PasswordType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Пароль: *'] )
			->add('save', SubmitType::class, [ 'attr' => ['class'=>'btn btn-primary btn-lg'], 'label'=>'Войти'] );

	}
}