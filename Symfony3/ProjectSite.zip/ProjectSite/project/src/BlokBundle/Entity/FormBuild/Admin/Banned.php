<?php

namespace BlokBundle\Entity\FormBuild\Admin;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;


class Banned extends AbstractType {


	public $cause;
	public $duration;
	public $level;

	public function buildForm( FormBuilderInterface $builder , array $options )
	{

		$builder
			->add('level', IntegerType::class,
				[ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Уровень бана: * ( полный-6, средний-5. частичный-4, слабый-3 )'] )
			->add('duration', TextType::class,
				[ 'label' => 'Длительность бана: * ( в часах - 1h, в минутах - 1m, в сутках - 1d, бесконечный - 0 )', 'attr' => ['class'=>'form-control']  ] )
			->add('cause', TextType::class,
				[ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Причина бана: *'] )
		;

	}
}