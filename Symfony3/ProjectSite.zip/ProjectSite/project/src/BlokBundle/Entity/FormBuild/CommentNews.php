<?php

namespace BlokBundle\Entity\FormBuild;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Validator\Constraints\NotBlank;



class CommentNews extends AbstractType {


	public $message;


	public function buildForm( FormBuilderInterface $builder , array $options )
	{
		$builder->add('message', TextareaType::class, [ 'required'=>false, 'attr' => [ 'rows' => '5', 'class'=>'form-control'], 'label'=>'Комментарий: *'] );

	}
}