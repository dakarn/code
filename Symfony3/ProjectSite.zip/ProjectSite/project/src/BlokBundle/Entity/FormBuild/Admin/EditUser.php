<?php

namespace BlokBundle\Entity\FormBuild\Admin;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Validator\Constraints\Choice;


class EditUser extends AbstractType {


	public $username;
	public $password;
	public $email;
	public $age;
	public $gender;
	public $balance;
	public $city;
	public $country;

	public function buildForm( FormBuilderInterface $builder , array $options )
	{

		$builder
			->add('username', TextType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Логин ( не более 20 букв): *'] )
			->add('password', PasswordType::class, [ 'required'=>true, 'label' => 'Введите пароль: *', 'attr' => ['class'=>'form-control']  ] )
			->add('email', EmailType::class, [ 'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'E-mail: *'] )
			->add('country', TextType::class, [ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Страна: *'] )
			->add('city', TextType::class, [ 'required'=>false, 'attr' => ['class'=>'form-control'], 'label'=>'Город: *'] )
			->add('age', IntegerType::class, [  'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Сколько вам лет?: *'] )
			->add('balance', TextType::class, [  'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Баланс лицевого счета: *'] )
			->add('gender', ChoiceType::class, [
				'choices'  => array(
					'Другое' => 'other',
					'Мужской' => 'man',
					'Женский' => 'woman' ),
				'required'=>true, 'attr' => ['class'=>'form-control'], 'label'=>'Ваш пол: *']
			);

	}
}