<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Support
 *
 * @ORM\Table(name="support")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\SupportRepository")
 */
class Support
{

    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $userId;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="files", type="string", length=1000)
	 */
	private $files;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="updated_at", type="integer")
	 */
    private $updatedAt;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="count", type="integer")
	 */
	private $count;
	/**
	 * @ORM\OneToOne(targetEntity="User")
	 * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
	 */
    private $userTable;

    /**
     * @var string
     *
     * @ORM\Column(name="type_cause", type="string", length=50)
     */
    private $typeCause;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="from_support", type="integer")
	 */
	private $fromSupport;

    /**
     * @var int
     *
     * @ORM\Column(name="isclose", type="integer")
     */
    private $isclose;

    /**
     * @var int
     *
     * @ORM\Column(name="created_at", type="integer")
     */
    private $createdAt;

    /**
     * @var string
     *
     * @ORM\Column(name="message", type="string", length=600)
     */
    private $message;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=70)
     */
    private $title;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return Support
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return int
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set typeCause
     *
     * @param string $typeCause
     *
     * @return Support
     */
    public function setTypeCause($typeCause)
    {
        $this->typeCause = $typeCause;

        return $this;
    }

    /**
     * Get typeCause
     *
     * @return string
     */
    public function getTypeCause()
    {
        return $this->typeCause;
    }

    /**
     * Set isclose
     *
     * @param integer $isclose
     *
     * @return Support
     */
    public function setIsclose($isclose)
    {
        $this->isclose = $isclose;

        return $this;
    }

    /**
     * Get isclose
     *
     * @return int
     */
    public function getIsclose()
    {
        return $this->isclose;
    }

    /**
     * Set createdAt
     *
     * @param integer $createdAt
     *
     * @return Support
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return int
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set message
     *
     * @param string $message
     *
     * @return Support
     */
    public function setMessage($message)
    {
        $this->message = $message;

        return $this;
    }

    /**
     * Get message
     *
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Support
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }


	public function getUserTable()
	{
		return $this->userTable;
	}


    /**
     * Set updatedAt
     *
     * @param integer $updatedAt
     *
     * @return Support
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return integer
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set count
     *
     * @param integer $count
     *
     * @return Support
     */
    public function setCount($count)
    {
        $this->count = $count;

        return $this;
    }

    /**
     * Get count
     *
     * @return integer
     */
    public function getCount()
    {
        return $this->count;
    }

    /**
     * Set userTable
     *
     * @param \BlokBundle\Entity\User $userTable
     *
     * @return Support
     */
    public function setUserTable(\BlokBundle\Entity\User $userTable = null)
    {
        $this->userTable = $userTable;

        return $this;
    }

    /**
     * Set fromSupport
     *
     * @param integer $fromSupport
     *
     * @return Support
     */
    public function setFromSupport($fromSupport)
    {
        $this->fromSupport = $fromSupport;

        return $this;
    }

    /**
     * Get fromSupport
     *
     * @return integer
     */
    public function getFromSupport()
    {
        return $this->fromSupport;
    }

    /**
     * Set files
     *
     * @param string $files
     *
     * @return Support
     */
    public function setFiles($files)
    {
        $this->files = $files;

        return $this;
    }

    /**
     * Get files
     *
     * @return string
     */
    public function getFiles()
    {
        return $this->files;
    }
}
