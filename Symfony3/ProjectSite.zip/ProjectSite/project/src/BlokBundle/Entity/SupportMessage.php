<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Message
 *
 * @ORM\Table(name="support_message")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\SupportMessageRepository")
 */
class SupportMessage
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

	/**
	 * @ORM\ManyToOne(targetEntity="User")
	 * @ORM\JoinColumn(name="user_id", referencedColumnName="id")
	 */
    //private $userTable;

    /**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $userId;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="files", type="string", length=1000)
	 */
	private $files;

    /**
     * @var string
     *
     * @ORM\Column(name="text", type="string", length=500)
     */
    private $text;

    /**
     * @var int
     *
     * @ORM\Column(name="created_at", type="integer")
     */
    private $createdAt;


	/**
	 * @var int
	 *
	 * @ORM\Column(name="answer_admin", type="integer")
	 */
	private $answerAdmin;

    /**
     * @var int
     *
     * @ORM\Column(name="support_id", type="integer")
     */
    private $supportId;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }


    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }


    public function getUserId()
    {
        return $this->userId;
    }


    public function setText($text)
    {
        $this->text = $text;

        return $this;
    }


    public function getText()
    {
        return $this->text;
    }


    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }


    public function getCreatedAt()
    {
        return $this->createdAt;
    }


    public function setSupportId($userIdCreated)
    {
        $this->supportId = $userIdCreated;

        return $this;
    }


    public function getSupportId()
    {
        return $this->supportId;
    }

	public function getUserTable()
	{
		return $this->userTable;
	}


    public function setAnswerAdmin($answerAdmin)
    {
        $this->answerAdmin = $answerAdmin;

        return $this;
    }


    public function getAnswerAdmin()
    {
        return $this->answerAdmin;
    }


    /**
     * Set files
     *
     * @param string $files
     *
     * @return SupportMessage
     */
    public function setFiles($files)
    {
        $this->files = $files;

        return $this;
    }

    /**
     * Get files
     *
     * @return string
     */
    public function getFiles()
    {
        return $this->files;
    }
}
