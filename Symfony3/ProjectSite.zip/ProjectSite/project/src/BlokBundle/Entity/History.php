<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * History
 *
 * @ORM\Table(name="history_operation")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\HistoryRepository")
 */
class History
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="created_at", type="integer")
     */
    private $createdAt;

    /**
     * @var string
     *
     * @ORM\Column(name="type_operation", type="string", length=255)
     */
    private $typeOperation;

    /**
     * @var string
     *
     * @ORM\Column(name="descript", type="string", length=300)
     */
    private $descript;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="user_id", type="integer")
	 */
	private $userid;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set createdAt
     *
     * @param integer $createdAt
     *
     * @return History
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return int
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set typeOperation
     *
     * @param string $typeOperation
     *
     * @return History
     */
    public function setTypeOperation($typeOperation)
    {
        $this->typeOperation = $typeOperation;

        return $this;
    }

    /**
     * Get typeOperation
     *
     * @return string
     */
    public function getTypeOperation()
    {
        return $this->typeOperation;
    }

    /**
     * Set descript
     *
     * @param string $descript
     *
     * @return History
     */
    public function setDescript($descript)
    {
        $this->descript = $descript;

        return $this;
    }

    /**
     * Get descript
     *
     * @return string
     */
    public function getDescript()
    {
        return $this->descript;
    }


    public function setUserId($userId)
    {
        $this->userid = $userId;

        return $this;
    }


    public function getUserId()
    {
        return $this->userid;
    }
}
