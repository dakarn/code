<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ThemeVote
 *
 * @ORM\Table(name="vote_theme")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\ThemeVoteRepository")
 */
class ThemeVote
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255)
     */
    private $title;

    /**
     * @var int
     *
     * @ORM\Column(name="theme_id", type="integer")
     */
    private $themeId;

    /**
     * @var int
     *
     * @ORM\Column(name="count_vote", type="integer")
     */
    private $countVote;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return ThemeVote
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set themeId
     *
     * @param integer $themeId
     *
     * @return ThemeVote
     */
    public function setThemeId($themeId)
    {
        $this->themeId = $themeId;

        return $this;
    }

    /**
     * Get themeId
     *
     * @return int
     */
    public function getThemeId()
    {
        return $this->themeId;
    }

    /**
     * Set countVote
     *
     * @param integer $countVote
     *
     * @return ThemeVote
     */
    public function setCountVote($countVote)
    {
        $this->countVote = $countVote;

        return $this;
    }

    /**
     * Get countVote
     *
     * @return int
     */
    public function getCountVote()
    {
        return $this->countVote;
    }
}

