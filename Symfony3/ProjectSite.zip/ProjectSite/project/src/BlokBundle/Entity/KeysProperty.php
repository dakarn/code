<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * KeysProperty
 *
 * @ORM\Table(name="keys_property")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\KeysPropertyRepository")
 */
class KeysProperty
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="key_id", type="integer")
     */
    private $keyId;

    /**
     * @var string
     *
     * @ORM\Column(name="property", type="string", length=300)
     */
    private $property;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set keyId
     *
     * @param integer $keyId
     *
     * @return KeysProperty
     */
    public function setKeyId($keyId)
    {
        $this->keyId = $keyId;

        return $this;
    }

    /**
     * Get keyId
     *
     * @return int
     */
    public function getKeyId()
    {
        return $this->keyId;
    }

    /**
     * Set property
     *
     * @param string $property
     *
     * @return KeysProperty
     */
    public function setProperty($property)
    {
        $this->property = $property;

        return $this;
    }

    /**
     * Get property
     *
     * @return string
     */
    public function getProperty()
    {
        return $this->property;
    }
}

