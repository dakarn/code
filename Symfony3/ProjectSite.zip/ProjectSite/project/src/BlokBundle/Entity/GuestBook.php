<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\GuestRepository")
 * @ORM\Table(name="guestbook")
 */
class GuestBook
{
	/**
	 * @ORM\Column(type="integer")
	 * @ORM\Id
	 * @ORM\GeneratedValue(strategy="AUTO")
	 */
	private $id;

	/**
	 * @ORM\Column(type="string", length=100)
	 */
	private $message;

	/**
	 * @ORM\Column(type="string")
	 */
	private $user_id;

	/**
	 * @ORM\Column(type="string")
	 */
	private $username;

	/**
	 * @ORM\Column(type="integer")
	 */
	private $created_at;

	/**
	 * @ORM\Column(type="integer")
	 */
	private $updated_at;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set message
     *
     * @param string $message
     *
     * @return GuestBook
     */
    public function setMessage($message)
    {
        $this->message = $message;

        return $this;
    }

    /**
     * Get message
     *
     * @return string
     */
    public function getMessage()
    {
        return $this->message;
    }


	/**
	 * Set username
	 *
	 * @param string $username
	 *
	 * @return GuestBook
	 */
	public function setUsername($username)
	{
		$this->username = $username;

		return $this;
	}

	/**
	 * Get message
	 *
	 * @return string
	 */
	public function getUsername()
	{
		return $this->username;
	}


    /**
     * Set userId
     *
     * @param string $userId
     *
     * @return GuestBook
     */
    public function setUserId($userId)
    {
        $this->user_id = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return string
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * Set createdAt
     *
     * @param integer $createdAt
     *
     * @return GuestBook
     */
    public function setCreatedAt($createdAt)
    {
        $this->created_at = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return integer
     */
    public function getCreatedAt()
    {
        return $this->created_at;
    }

    /**
     * Set updatedAt
     *
     * @param integer $updatedAt
     *
     * @return GuestBook
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updated_at = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return integer
     */
    public function getUpdatedAt()
    {
        return $this->updated_at;
    }
}
