<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Entity\Support;
use BlokBundle\Helper\UploadFile;


class SupportRepository extends \Doctrine\ORM\EntityRepository
{

	private $errors = [
		'Данный топик не найден.',
	];

	private function upload()
	{
		$upload = new UploadFile();
		return $upload->setUploader( new \BlokBundle\Helper\Upload\Upload_Bind_Picture( PATH_TO_PICTURE_SUPPORT ) );
	}

	public function addMessageToUser( $doct, $id, $user )
	{

		$upload = $this->upload();

		if( $upload[0] !== true ) { return $upload; }

		$message = new Support();

		$message->setUserId( $id )->setTitle( $_POST['theme'] )->setMessage( $_POST['message'] );
		$message->setCreatedAt( time() )->setIsclose( 0 );
		$message->setFromSupport( 1 )->setUpdatedAt( time() )->setCount( 0 );
		$message->setTypeCause( 'message_admin' )->setFiles('');

		if( isset( $upload[1] ) )
		{
			$message->setFiles( json_encode( $upload[1] ) );
		}

		$doct->persist($message);
		$doct->flush();

		return ( null != $message->getId() ) ? true : false;

	}

	public function createSupportTopic( $doct, $user )
	{

		$upload = $this->upload();

		if( $upload[0] !== true ) { return $upload; }

		$message = new Support();

		$message->setUserId( $user->getId() );
		$message->setTitle( $_POST['desc'] );
		$message->setMessage( $_POST['message'] );
		$message->setCreatedAt( time() );
		$message->setFromSupport( 0 );
		$message->setIsclose( 0 );
		$message->setUpdatedAt( time() );
		$message->setCount( 0 );
		$message->setFiles( '' );
		$message->setTypeCause( $_POST['type_cause'] );

		if( isset( $upload[1] ) )
		{
			$message->setFiles( json_encode( $upload[1] ) );
		}

		$doct->persist($message);
		$doct->flush();

		return ( null != $message->getId() ) ? true : false;
	}


	public function deleteTopic( $doct, $id, $repos, $repos_msg )
	{

		$support = $repos->findOneById( $id );

		if( null === $support )
		{
			return $this->errors[0];
		}

		$query = $doct->createQuery( 'DELETE BlokBundle:SupportMessage sm WHERE sm.supportId = :id' )->setParameter("id", $id);
		$query->execute();

		$doct->remove( $support );
		$doct->flush();

		return true;
	}

	public function closeTopic( $doct, $id )
	{

		$support = $doct->getRepository( 'BlokBundle:Support' )->findOneById( $id );

		if( null === $support )
		{
			return $this->errors[0];
		}

		$support->setIsclose( 1 );
		$doct->flush();

		return true;
	}

	public function openTopic( $doct, $id )
	{

		$support = $doct->getRepository( 'BlokBundle:Support' )->findOneById( $id );

		if( null === $support )
		{
			return $this->errors[0];
		}

		$support->setIsclose( 0 );
		$doct->flush();

		return true;
	}
}
