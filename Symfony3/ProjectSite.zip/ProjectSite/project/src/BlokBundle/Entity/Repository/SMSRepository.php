<?php

namespace BlokBundle\Entity\Repository;
use BlokBundle\Entity\SMS;


class SMSRepository extends \Doctrine\ORM\EntityRepository
{

	public function sendSMS( $form, $doct, $user )
	{

		$sms = new SMS();
		$sms->setMessage( $form->get( 'message' )->getData()  );
		$sms->setTheme( $form->get( 'theme' )->getData()  );
		$sms->setCreatedAt( time() );
		$sms->setUserId( $user->getId() );
		$sms->setKeycode( $form->get( 'keyCode' )->getData() );
		$sms->setFrom( $form->get( 'from' )->getData() );
		$sms->setPhoneNumber( $form->get( 'phone' )->getData()  );

		$doct->persist( $sms );
		$doct->flush();

		return ( null != $sms->getId() ) ? true : false;

	}

}
