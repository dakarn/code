<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Entity\Theme;
use BlokBundle\Entity\ThemeVote;
use BlokBundle\Helper\UploadFile;
use Symfony\Component\Config\Definition\Exception\Exception;

class ThemeRepository extends \Doctrine\ORM\EntityRepository
{

	private $errors = [
		'Такой темы не найдено.', 'Такой подфорум не найден.', 'Ошибка при выполнении операции.',
		'Не заполнена жалоба на тему.',
	];
	private $table = [ 'forum_theme', 'users' ];
	private $role = 'ROLE_MODER_FORUM';
	private $def_value = [ 0, 1 ];

	private function upload()
	{
		$upload = new UploadFile();
		return $upload->setUploader( new \BlokBundle\Helper\Upload\Upload_Bind_Picture( PATH_TO_PICTURE_FORUM ) );
	}

	private function setVote( $doct, $theme_id )
	{

		if( !isset( $_POST['is_vote'] ) || $_POST['is_vote'] == 0 ){ return false; }

		if( empty($_POST['title_vote']) ){ return false; }

		$vote = new ThemeVote();
		$vote->setThemeId($theme_id)->setTitle( $_POST['title_vote'] )->setCountVote( -1 );
		$doct->persist( $vote );

		for( $i = 0; $i < count( $_POST['vote_variant'] ); ++$i )
		{
			if( empty( $_POST['vote_variant'][$i] ) ) continue;

			$vote = new ThemeVote();
			$vote->setThemeId( $theme_id )->setTitle( $_POST['vote_variant'][$i] )->setCountVote( 0 );

			$doct->persist( $vote );
		}

		$doct->flush();
	}

	public function addTheme( $container, $doct, $form, $user, $forumid, $forum )
	{

		if( !$form->isValid() )
		{
			return $form->getErrors( true );
		}

		$upload = $this->upload();

		if( $upload[0] !== true )
		{
			return $upload;
		}

		$conn = $this->getEntityManager()->getConnection();
		$trans = $conn->beginTransaction();

		try {

			$forum->setCountTheme((int)$forum->getCountTheme() + 1);

			$theme = new Theme();

			$theme->setTitle($form->get('title')->getData())->setCreatedAt(time());
			$theme->setCountPost($this->def_value[0])->setUpdatedAt(time())->setCountviews($this->def_value[0]);
			$theme->setText($form->get('message')->getData())->setUserId($user->getId());
			$theme->setUsername($user->getUsername())->setUpdatedAtText('');
			$theme->setForumId($forumid)->setIsclose($this->def_value[0])->setFiles('');

			if ($container->get('security.authorization_checker')->isGranted($this->role, $user))
			{

				if (abs((int)$_POST['status_close_def']) > 1)
				{
					$_POST['status_close_def'] = $this->def_value[0];
				}

				if (abs((int)$_POST['public_theme']) > 2)
				{
					$_POST['public_theme'] = $this->def_value[1];
				}

				if (abs((int)$_POST['important_theme']) > 1)
				{
					$_POST['important_theme'] = $this->def_value[0];
				}

				$theme->setIsclose($_POST['status_close_def'])->setPublic($_POST['public_theme']);
				$theme->setImportant($_POST['important_theme']);
			}

			if (isset($upload[1]))
			{
				$theme->setFiles(json_encode($upload[1]));
			}

			$doct->persist($theme);
			$doct->flush();

			$this->setVote($doct, $theme->getId());

			$conn->commit(); return true;

		} catch( Exception $e)
		{
			$conn->rollBack();
			return false;
		}

	}


	public function editTheme( $container, $doct, $form, $theme )
	{

		if( !$form->isValid() )
		{
			return $form->getErrors( true );
		}

		if( $container->get('security.authorization_checker')->isGranted( $this->role ) )
		{

			if( abs( (int)$_POST['status_close_def'] ) > 1 ){ $_POST['status_close_def'] = $this->def_value[0]; }
			if( abs( (int)$_POST['public_theme'] ) > 2 ){ $_POST['public_theme'] = $this->def_value[1]; }
			if( abs( (int)$_POST['important_theme'] ) > 1 ){ $_POST['important_theme'] = $this->def_value[0]; }

			$theme->setIsclose( $_POST['status_close_def'] );
			$theme->setPublic( $_POST['public_theme'] );
			$theme->setImportant( $_POST['important_theme'] );
		}

		$theme->setTitle( $form->get( 'title' )->getData() );
		$theme->setUpdatedAt( time() );
		$theme->setText( $form->get( 'message' )->getData() );

		$doct->flush();

		return true;

	}


	public function moveTheme( $doct, $theme, $id, $repos, $forum_old )
	{

		$forum_new = $repos->findOneById( abs( (int)$_POST[ 'new_forum' ] ));

		if( $forum_new === null )
		{
			return $this->errors[1];
		}

		$conn = $this->getEntityManager()->getConnection();
		$trans = $conn->beginTransaction();

		try {

			$theme->setForumId($_POST['new_forum']);
			$doct->flush();

			$forum_new->setCountTheme($forum_new->getCountTheme() + $this->def_value[1]);
			$forum_new->setCountPosts($forum_new->getCountPosts() + $theme->getCountPost());
			$doct->flush();

			$forum_old->setCountTheme($forum_old->getCountTheme() - $this->def_value[1]);
			$forum_old->setCountPosts($forum_old->getCountPosts() - $theme->getCountPost());
			$doct->flush();

			$em = $this->getEntityManager();

			$move_post = $em->createQuery('UPDATE BlokBundle:Post p SET p.forumId = ' . $_POST['new_forum'] . ' WHERE p.themeId = :theme_id');
			$move_post->execute(['theme_id' => $id]);

			$conn->commit();

		} catch( Exception $e )
		{
			$conn->rollBack();
			return false;
		}

		return true;

	}


	public function mergeTheme( $doct, $csrf, $theme_id )
	{

		if( !$csrf )
		{
			return $this->errors[2];
		}

		if( empty( $_POST['select_theme_id'] ) || !is_numeric(  $_POST['select_theme_id'] ) )
		{
			return $this->errors[0];
		}

		$move_post = $this->getEntityManager()->createQuery( 'UPDATE BlokBundle:Post p SET p.themeId = '.$theme_id.' WHERE p.themeId = :theme_id' );
		$move_post->execute( [ 'theme_id' => (int)$_POST[ 'select_theme_id' ] ] );

		$del_post = $this->getEntityManager()->createQuery( 'DELETE BlokBundle:Theme t WHERE t.id = :id' );
		$del_post->execute( [ 'id' =>  $_POST['select_theme_id'] ] );

		$doct->flush();

		return true;

	}


	public function complainTheme( $doct, $theme, $theme_id )
	{

		if( empty( $_POST['text_complain'] ) )
		{
			return $this->errors[3];
		}

		return $doct->getRepository( 'BlokBundle:Complain' )->createThemeComplain( $doct, $theme_id );

	}

	public function closeTheme( $doct )
	{

		if( !is_numeric( $_GET['id']) )
		{
			return $this->errors[0];
		}

		$theme = $this->findOneById( $_GET['id'] );

		if( $theme === null )
		{
			return $this->errors[0];
		}

		$theme->setIsclose( $theme->getIsClose() == 1 ? 0:1 );
		$doct->flush();

		return true;
	}


	public function addViews( $doct, $id )
	{

		$theme = $this->findOneBy( [ 'id' => $id ] );
		$theme->setCountviews( $theme->getCountviews() + $this->def_value[1] );

		$doct->flush();
	}


	public function deleteTheme( $doct )
	{

		if( !is_numeric( $_GET['id']) )
		{
			return $this->errors[0];
		}

		$theme = $this->findOneById( $_GET['id'] );

		if( $theme === null )
		{
			return $this->errors[0];
		}

		$conn = $this->getEntityManager()->getConnection();
		$trans = $conn->beginTransaction();

		try {

			$forum = $doct->getRepository('BlokBundle:Forum')->findOneBy(['id' => $theme->getForumId()]);
			$forum->setCountTheme((int)$forum->getCountTheme() - $this->def_value[1]);

			$del_post = $this->getEntityManager()->createQuery('DELETE BlokBundle:Post p WHERE p.themeId = :id')->setParameter('id', $_GET['id']);
			$del_post->execute();

			$doct->remove($theme);
			$doct->flush();

			$conn->commit(); return true;

		} catch ( Exception $e )
		{
			$conn->rollBack();
			return false;
		}

	}


	public function clearTheme()
	{

		$doct = $this->getEntityManager();
		$id = (int)$_GET['id'];
		$conn = $this->getEntityManager()->getConnection();
		$trans = $conn->beginTransaction();

		try {

			$count_post = $doct->createQuery('SELECT COUNT(p.id) FROM BlokBundle:Post p WHERE p.themeId = :id')
				->setParameter(':id', $id)->getSingleScalarResult();

			$theme = $doct->getRepository('BlokBundle:Theme')->findOneBy(['id' => $id]);
			$theme->setCountPost($this->def_value[0]);
			$doct->flush();

			$forum = $doct->getRepository('BlokBundle:Forum')->findOneBy(['id' => $theme->getForumId()]);
			$forum->setCountPosts($forum->getCountPosts() - $count_post);
			$doct->flush();

			$clear_post = $doct->createQuery('DELETE BlokBundle:Post p WHERE p.themeId = :id');
			$clear_post->execute(['id' => $id]);

			$conn->commit(); return true;

		} catch (Exception $e)
		{
			$conn->rollBack(); return false;
		}

	}
	
	
	public function recountPostInTheme()
	{

		$em = $this->getEntityManager();
		$id = (int)$_GET['id'];

		$count_post = $em->createQuery('SELECT COUNT(p.id) FROM BlokBundle:Post p WHERE p.themeId = :id')
			->setParameter( ':id', $id )->getSingleScalarResult();

		$theme = $em->getRepository( 'BlokBundle:Theme' )->findOneBy( [ 'id' => $id ] );
		$theme->setCountPost( $count_post );
		$em->flush();

		return true;

	}
	
	public function ThemeJoinUser( $id )
	{

		$doct = $this->getEntityManager()->getConnection();

		$query = $doct->prepare('SELECT u.*, t.id AS tid, t.created_at AS time_create, t.updated_at AS time_edit, t.* 
		FROM '.$this->table[0].' AS t LEFT JOIN '.$this->table[1].' u
		ON t.user_id = u.id WHERE t.id = :id  ORDER BY t.created_at LIMIT 1');

		$query->execute( [ 'id' => $id ]);
		return $query->fetch(2 );
	}



}
