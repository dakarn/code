<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Entity\History;

class HistoryRepository extends \Doctrine\ORM\EntityRepository
{

	public function addInHistory( $doct, $user, $type, $text )
	{

		$history = new History();

		$history->setUserId( $user->getId() );
		$history->setCreatedAt( time() );
		$history->setTypeOperation( $type );
		$history->setDescript( $text );

		$doct->persist( $history );
		$doct->flush();

		return null !== $history->getId() ? $history->getId() : -1;
	}


	public function deleteFromHistory( $doct, $history )
	{
		$doct->remove( $history );
		$doct->flush();
	}

}
