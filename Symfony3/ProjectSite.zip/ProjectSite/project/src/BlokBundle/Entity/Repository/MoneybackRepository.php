<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Entity\Moneyback;

class MoneybackRepository extends \Doctrine\ORM\EntityRepository
{

	public function addApply( $doct, $form, $user )
	{

		$apply = new Moneyback();

		$apply->setUserID( $user->getId() );
		$apply->setCreatedAt( time() );
		$apply->setCause( $form->get('cause')->getData());
		$apply->setService( $form->get('service')->getData() );
		$apply->setAnswer( '' );

		$doct->persist( $apply );
		$doct->flush();

		return ( null !== $apply->getId() ) ? true : false;
	}

}
