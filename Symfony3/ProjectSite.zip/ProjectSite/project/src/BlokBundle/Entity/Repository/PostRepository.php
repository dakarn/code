<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Entity\Post;
use BlokBundle\Helper\UploadFile;
use Symfony\Component\Config\Definition\Exception\Exception;

class PostRepository extends \Doctrine\ORM\EntityRepository
{

	private $table = [ 'forum_posts', 'users' ];
	private $quote_html = '[quote-post-theme][br][b]Цитата: ( %s / %s )[/b][br]%s[/quote-post-theme][br][p]%s[/p]';
	private $last_post = 'Последнее сообщение от %s.<br>%s';

	private $last_for_forum = '%s.<br>Тема: <a href="">%s</a><br>Последнее сообщение от: %s';
	private $errors = [
		'Такая тема не существует.',
		'Не заполнено сообщение.',
		'Ошибка при добавлении сообщения.',
		'Ошибка при удалении поста.',
		'Ошибка при изменении поста.',
		'Такого поста не существует.',
		'Эта тема закрыта, писать в ней нельзя.',
		'Текст жалобы не заполнен.',
	];
	private $quote_class = ['\[quote-post-theme\]', '\[\/quote-post-theme\]'];
	private $save_edit_quote = '%s[br][p]%s[/p]';


	private function upload()
	{
		$upload = new UploadFile();
		return $upload->setUploader( new \BlokBundle\Helper\Upload\Upload_Bind_Picture( PATH_TO_PICTURE_FORUM ) );
	}

	private function setQuote()
	{

		if( isset( $_POST['post_id_quote'] ) && is_numeric( $_POST['post_id_quote'] ) && $_POST['type_post'] == 'quote' )
		{
			$quote_post = $this->findOneBy( [ 'id' => $_POST['post_id_quote'] ] );

			if( $quote_post !== null )
			{
				$_POST['message'] = sprintf( $this->quote_html,  $quote_post->getUserId(),
				date( 'H:i - d.m.Y', $quote_post->getCreatedAt() ), $quote_post->getText(), $_POST['message'] );
			}
		}

	}


	public function complainPost( $doct, $theme, $post_id )
	{

		if( empty( $_POST['text_complain'] ) )
		{
			return $this->errors[7];
		}

		return $doct->getRepository( 'BlokBundle:Complain' )->createPostComplain( $doct, $post_id );

	}

	public function addPostInTheme( $doct, $themeid, $user )
	{

		if( empty( $_POST['message'] ) ) { return $this->errors[1]; }

		if( !is_numeric( $_POST['public_post'] ) || $_POST['public_post'] > 1 ) { $_POST['public_post'] = 1; }


		$theme = $doct->getRepository( 'BlokBundle:Theme' )->findOneBy( [ 'id' => $themeid ] );

		if( $theme  === null ) { return $this->errors[0]; }

		if( $theme->getIsclose() == 1 ){ return $this->errors[6]; }


		$this->setQuote();

		$upload = $this->upload();

		if( $upload[0] !== true )
		{
			return $upload;
		}

		$conn = $this->getEntityManager()->getConnection();
		$trans = $conn->beginTransaction();

		try {

			$forum = $doct->getRepository('BlokBundle:Forum')->findOneBy(['id' => $theme->getForumId()]);
			$forum->setCountPosts($forum->getCountPosts() + 1);
			$forum->setUpdatedAtText(sprintf($this->last_for_forum, date('H:i - d.m.Y'), $theme->getTitle(), $user->getUsername()));
			$doct->flush();

			$theme->setCountPost($theme->getCountPost() + 1)->setUpdatedAt(time());
			$theme->setUpdatedAtText(sprintf($this->last_post, $user->getUsername(), date('H:i - d.m.Y')));
			$doct->flush();

			$post = new Post();

			$post->setUserId($user->getId())->setThemeId($themeid)->setCreatedAt(time());
			$post->setUpdatedAt(time())->setPublic($_POST['public_post'])->setForumId($forum->getId());
			$post->setText($_POST['message'])->setFiles('')->setUsefull(0);

			if (isset($upload[1])) {
				$post->setFiles(json_encode($upload[1]));
			}

			$doct->persist($post);
			$doct->flush();

			$notice = new NoticeNewRepository();
			$notice->addNoticeTheme($doct, $theme->getId(), $user->getId());

			$conn->commit(); return true;

		} catch (Exception $e)
		{
			$conn->rollBack(); return false;
		}

		return $this->errors[2];

	}

	public function addUsefull( $doct, $id )
	{

		$post = $this->findOneBy( [ 'id' => $id ] );

		if( $post === null )
		{
			return $this->errors[5];
		}

		$post->setUsefull( $post->getUsefull() + 1 );
		$doct->flush();

		return true;

	}

	public function editPostInTheme( $doct, $post_id, $post )
	{

		if( empty( $_POST['message-editpost'] ) )
		{
			return $this->errors[1];
		}

		if( $post === null )
		{
			return $this->errors[4];
		}

		if( preg_match( '/'.$this->quote_class[0].'/s', $post->getText() ) )
		{
			preg_match( '/'.$this->quote_class[0].'(.*)'.$this->quote_class[1].'/s', $post->getText(), $result );
			$_POST['message-editpost'] = sprintf( $this->save_edit_quote, $result[0], $_POST['message-editpost'] );
		}

		$post->setText( $_POST['message-editpost'] );
		$post->setUpdatedAt( time() );

		$doct->flush();

		return true;
	}

	public function deletePostFromTheme( $doct, $post_id, $post )
	{

		if( $post === null )
		{
			return $this->errors[3];
		}

		$theme = $doct->getRepository( 'BlokBundle:Theme' )->findOneBy( [ 'id' => $post->getThemeId() ] );
		$theme->setCountPost( $theme->getCountPost() - 1 );
		$doct->flush();

		$forum = $doct->getRepository( 'BlokBundle:Forum' )->findOneBy( [ 'id' => $post->getForumId() ] );
		$forum->setCountPosts( $forum->getCountPosts() - 1 );
		$doct->flush();

		$doct->remove( $post );
		$doct->flush();

		return true;

	}


	public function PostsJoinUser( $id )
	{

		$filter = '';
		$filter_arr = [ 'usefull' => 'AND usefull > 0' ];

		if( isset( $_GET['filter'] ) && key_exists( $_GET['filter'], $filter_arr ) )
		{
			$filter = $filter_arr[ $_GET['filter'] ];
		}

		$query = 'SELECT u.*, p.created_at AS time_create, p.updated_at AS time_edit, p.* 
		FROM '.$this->table[0].' AS p LEFT JOIN '.$this->table[1].' u
		ON p.user_id = u.id WHERE p.theme_id = '.$id.' '.$filter.' ORDER BY p.created_at';


		if( isset( $_GET['type_post'] ) && $_GET['type_post'] == 'search-in-theme' )
		{

			if( strlen( $_GET['text_search'] ) < 2 ) return $query;

			$text = $_GET['text_search'];

			$query = "SELECT u.*, p.created_at AS time_create, p.updated_at AS time_edit, p.* 
			FROM ".$this->table[0]." AS p LEFT JOIN ".$this->table[1]." u
			ON p.user_id = u.id 
			WHERE p.theme_id = ".$id." '.$filter.' AND p.text LIKE '%$text%' ORDER BY p.created_at";
		}

		return $query;

	}

}
