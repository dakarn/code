<?php
namespace BlokBundle\Entity\Repository;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\User;
use BlokBundle\Helper\FunctionHelper;
use Symfony\Bridge\Doctrine\Security\User\UserLoaderInterface;
use Doctrine\ORM\EntityRepository;
use Symfony\Component\Config\Definition\Exception\Exception;


class UserRepository extends EntityRepository implements UserLoaderInterface
{

	private $errors = [
		'Вы не заполнили нужные поля.',
		'Повторный пароль не совпадает с новым паролем.',
		'Старый пароль введен не верно.',
	];

	private $filter_str = [
		'b.user_id = u.id AND ',
		'u.is_active = 1 AND ',
		"WHERE (u.username LIKE '%%%1\$s%%' OR u.email LIKE '%%%1\$s%%') AND ",
		'u.balance = %%%d%% AND ',
		'u.role = "%s" AND '];

	public function loadUserByUsername($username)
	{
		return $this->createQueryBuilder('u')
			->where('u.username = :username OR u.email = :email')
			->setParameter('username', $username)
			->setParameter('email', $username)
			->getQuery()
			->getOneOrNullResult();
	}

	public function already_exist_user( $username )
	{
		return $this->createQueryBuilder('u')
			->where('u.username = :username')
			->setParameter('username', $username)
			->getQuery()
			->getOneOrNullResult();
	}

	public function already_exist_email( $email )
	{
		return $this->createQueryBuilder('u')
			->where('u.email = :email')
			->setParameter('email', $email)
			->getQuery()
			->getOneOrNullResult();
	}

	public function exists_data( $form )
	{

		$errors = [];

		$exist_user = $this->already_exist_user( $form->get('username')->getData() );
		$exist_email = $this->already_exist_email( $form->get('email')->getData() );

		if( $exist_email != null ) {
			$errors[] = 'Такая почта уже существует в системе.';
		}

		if( $exist_user != null ) {
			$errors[] = 'Пользователь с таким логином уже существует в системе.';
		}

		return $errors;

	}


	public function SavePassword( $doct, $user )
	{

		if( empty( $_POST['password_old'] ) || empty( $_POST['password_new'] ) )
		{
			throw new Exception( $this->errors[0] );
		}

		if( $_POST['password_new'] !=  $_POST['password_confirm'] )
		{
			throw new Exception( $this->errors[1] );
		}

		if( !$this->isLegalPassword( $_POST['password_old'], $user) )
		{
			throw new Exception( $this->errors[2] );
		}

		$user->setPassword( password_hash( $_POST['password_new'], PASSWORD_BCRYPT ) );
		$doct->flush();

		return true;

	}


	private function filter_currency( $currency )
	{

		if( strpos( $currency, '.' ) )
		{
			$currency = str_replace( '.', '', $currency );
		} else {
			$currency .= '00';
		}

		return $currency;
	}

	private function adminSaveProfile( $user, $form )
	{

		$user->setEmail( $form->get( 'email' )->getData() );
		$user->setUsername( $form->get( 'username' )->getData() );
		$user->setAge( $form->get( 'age' )->getData() );
		$user->setGender( $form->get( 'gender' )->getData() );
		$user->setPassword( password_hash( $form->get( 'password' )->getData(), PASSWORD_BCRYPT ) );
		$user->setBalance( $this->filter_currency( $form->get( 'balance' )->getData() ) );
		$user->setCity( $form->get( 'city' )->getData() );
		$user->setCountry( $form->get( 'country' )->getData() );

	}

	private function userSaveProfile( $users, $form )
	{
		$users->setEmail( $form->get( 'email' )->getData() );
		$users->setUsername( $form->get( 'username' )->getData() );
		$users->setAge( $form->get( 'age' )->getData() );
		$users->setGender( $form->get( 'gender' )->getData() );
		$users->setCity( $form->get( 'city' )->getData() );
		$users->setCountry( $form->get( 'country' )->getData() );

	}

	public function isLegalPassword( $passwordEnter, $user )
	{

		if( password_verify( $passwordEnter, $user->getPassword() ) )
		{
			return true;
		}

		return false;
	}

	public function SaveProfile( $em, $user, $form, $method )
	{
		$this->$method( $user, $form );
		$em->flush();
		return true;
	}


	public function createUserAdmin( $em, $form, $encode )
	{

		$user = new User();

		$user->setPassword( $encode->encodePassword( $user, $form->get('password')->getData() ) );
		$user->setEmail( $form->get('email')->getData() )->setGender( $form->get('gender')->getData() );
		$user->setIsActive( 1 )->setRoles( 'ROLE_USER' )->setBalanceFilter( $form->get('balance')->getData() );
		$user->setAvatar( 'no-avatar.jpg' );
		$user->setCountpost( 0 );
		$user->setCity( '' );
		$user->setCountry( '' );
		$user->setCreatedAt( time() )->setAge( $form->get('age')->getData() )->setUsername( $form->get('username')->getData() );
		$user->setActivationKey('')->setUpdatedAt( time() )->setLastEnter( '' );

		$em->persist( $user );
		$em->flush();

		if( null !== $user->getId() )
		{
			$cache = new FileSystemCache();
			$cache->counter('incr','user_count' )->flush();
			return true;
		}

		return false;

	}


	public function addUsersTested( $doct )
	{

		$count = 100000;
		$email = 'tested'.microtime( true ).'user'.rand( 11111,99999).'@mail.ru';
		$username = 'tested-username-'.microtime( true ).'user'.rand( 11111,99999).'@mail.ru';
		$password = $this->get('security.password_encoder')->encodePassword( microtime(), 'admin-test' );

		for( $i = 0; $i < $count; ++$i )
		{
			$user = new User();

			$user->setPassword( $password );
			$user->setEmail( $email )->setGender( 'man' );
			$user->setIsActive( 1 )->setRoles( 'ROLE_USER' )->setBalanceFilter( 0 );
			$user->setAvatar( '' );
			$user->setCreatedAt( time() )->setAge( 99 )->setUsername( $username );
			$user->setActivationKey('')->setUpdatedAt( time() )->setLastEnter( '' );

			$doct->persist( $user );
		}

		$doct->flush();
		$doct->clear();

		$cache = new FileSystemCache( 'guest' );
		$cache->counter( 'incr','user_count', $count )->flush();

		$this->get('notice')->add( 'success', sprintf( $this->result[2], $count ) );
		return $this->redirectToRoute('blok_admin_users' );

	}


	private function setFilterSearch()
	{

		$filter = '';

		if( isset( $_GET['login_search'] ) && strlen( $_GET['login_search'] ) >= 3 )
		{
			$login = FunctionHelper::escapeSql($_GET['login_search']);
			$filter .= sprintf( $this->filter_str[2], $login );
		}

		if( isset( $_GET['search_extend'] ) && $_GET['search_extend'] == 1 )
		{

			$filter = 'WHERE '.str_replace( 'WHERE ','',$filter).' ';

			if( isset( $_GET['ban_search'] ) )
			{
				$filter .= $this->filter_str[0];
			}

			if( isset( $_GET['active_search'] ) )
			{
				$filter .= $this->filter_str[1];
			}

			if( !empty( $_GET['role_search'] ) )
			{
				$role = FunctionHelper::escapeSql($_GET['role_search']);
				$filter .= sprintf( $this->filter_str[4], $role );
			}

			if( !empty( $_GET['balance_search'] ) )
			{
				$filter .= sprintf( $this->filter_str[3], abs((int)$_GET['balance_search']) );
			}
		}

		return substr( $filter, 0 , -4 );
	}

	public function getUserJoin()
	{

		$filter = $this->setFilterSearch();

		$query = 'SELECT u.*, b.created_at AS time_create, u.id AS uid, b.id AS bid, b.* 
		FROM users AS u LEFT JOIN  banned_users AS b
		ON u.id = b.user_id '.$filter.' ORDER BY u.'.$_GET['sort'].' DESC';

		return $query;
	}

}
