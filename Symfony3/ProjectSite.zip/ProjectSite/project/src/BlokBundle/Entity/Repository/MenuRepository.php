<?php

namespace BlokBundle\Entity\Repository;

use BlokBundle\Entity\Menu;
use Doctrine\ORM\EntityManager;
use Symfony\Component\Config\Definition\Exception\Exception;


class MenuRepository extends \Doctrine\ORM\EntityRepository
{

	private $path = ROOT.PATH_TO_MENU_ICON;


	private function loadIcon()
	{

		if( !empty( $_POST['icon_menu_css'] ) ) { return 'css::'.htmlspecialchars($_POST['icon_menu_css']); }

		if( empty( $_FILES['icon_menu']['tmp_name'] ) ) { return ''; }

		if ( move_uploaded_file( $_FILES['icon_menu']['tmp_name'], $this->path.basename( $_FILES['icon_menu']['name'] ) ) )
		{
			return basename( $_FILES['icon_menu']['name'] );
		}

		return '';
	}


	public function addMenu( $em, $rep, $type_menu )
	{
		try
		{

			$count_menu = 1;

			if( empty( $_POST['name_menu'] ) || empty( $_POST['parent_menu'] ) )
			{
				throw new Exception();
			}


			if( empty( $_POST['priority_menu'] ) ) $_POST['priority_menu'] = 'end';


			if( $_POST['priority_menu'] == 'end' )
			{
				$count_menu = $em->createQuery('SELECT COUNT(m.id) FROM BlokBundle:Menu m WHERE m.type= :type')
					->setParameter('type', $type_menu)->getSingleScalarResult() + 1;

			} else if( $_POST['priority_menu'] == 'start' )
			{
				$offset = $this->getEntityManager()
				->createQuery( 'UPDATE BlokBundle:Menu m SET m.priority = m.priority+1 WHERE m.type = :type' );
				$offset->execute( [ 'type' => $type_menu ] );
			}

			$menu = new Menu();

			$menu->setIcon($this->loadIcon())->setTitle($_POST['name_menu'])->setUrl($_POST['url_menu']);
			$menu->setParentId($_POST['parent_menu'] == -1 ? 0 : $_POST['parent_menu'])->setPriority( $count_menu );
			$menu->setType($type_menu)->setPublic( $_POST['public_menu'] );

			$em->persist($menu);
			$em->flush();

			return ( null != $menu->getId() ) ? true : false;

		} catch( Exception $e )
		{
			return false;
		}

	}

	public function editMenu( $em, $rep )
	{

		try
		{
			if( empty( $_POST['new_name'] ) || empty( $_POST['parent_menu'] ) )
			{
				throw new Exception();
			}

			$menu_item = $rep->findOneById( $_POST['item_edit'] );


			if( $menu_item == null )
			{
				throw new Exception();
			}

			$priority = $menu_item->getPriority();
			$count_menu = $em->createQuery('SELECT MAX(m.priority) FROM BlokBundle:Menu m WHERE m.type= :type')
			->setParameter('type', $menu_item->getType() )->getSingleScalarResult();

			if( $_POST['priority_menu'] === 'up' && $priority < $count_menu )
			{
				$priority = $menu_item->getPriority() + 1;
				$menu_up = $rep->findOneBy( [ 'priority' => $priority ] );
				$menu_up->setPriority( $priority-1 );
				$em->flush();
			}

			if( $_POST['priority_menu'] === 'down' && $priority > 1 )
			{
				$priority = $menu_item->getPriority() - 1;
				$menu_up = $rep->findOneBy( [ 'priority' => $priority ] );
				$menu_up->setPriority( $priority+1 );
				$em->flush();
			}

			$menu_item->setTitle( $_POST['new_name'] )->setUrl( $_POST['new_title'] );
			$menu_item->setPublic( $_POST['public_menu'] )->setPriority( $priority );
			$menu_item->setIcon( $this->loadIcon() )->setParentId( $_POST['parent_menu'] == -1 ? 0 : $_POST['parent_menu'] );
			$em->flush();

			return ( null != $menu_item->getId() ) ? true : false;

		} catch( Exception $e )
		{
			return false;
		}
	}

	public function deleteMenu( $em, $rep )
	{

		$menu_item = $rep->findOneById( $_POST['item_delete'] );

		if( $menu_item != null )
		{
			$em->remove( $menu_item );
			$em->flush();

			return true;
		}

		return false;
	}

}
