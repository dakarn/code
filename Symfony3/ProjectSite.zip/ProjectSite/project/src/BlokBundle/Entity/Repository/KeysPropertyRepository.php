<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Entity\KeysProperty;
use BlokBundle\Helper\FunctionHelper;
use Symfony\Component\Security\Csrf\CsrfToken;


class KeysPropertyRepository extends \Doctrine\ORM\EntityRepository
{

	private $ip_search = 's:2:"ip";s:%d:"%s";';
	private $errors = [ 'Такой IP адрес уже привязан к другому ключу, вы не можете привязать этот IP.',
						'Ошибка при выполнении опраеции.' ];
	private $result = [ 'IP адрес успешно перепривязан или откреплен. Изменения вступят в силу через 5-10 минут!' ];

	public function addPropertyKey( $key )
	{


		$doct = $this->getEntityManager();
		$property_arr = [ 'curr_traffic' => 0, 'max_traffic' => 1000000000, 'ip' => '',
			'max_sms' => 1000, 'curr_sms' => 0, 'ban' => 0,
			'max_minute' => 2000, 'long_one_call' => 2, 'break_minute' => 5, 'curr_minute' => 0];

		$prop = new KeysProperty();

		$prop->setKeyId( $key->getId() );

		if( $_POST['type_key'] == 'sms' )
		{
			$property_arr = [ 'max_sms' => 1000, 'curr_sms' => 0, 'ban' => 0 ];

		} else if( $_POST['type_key'] == 'proxy' )
		{
			$property_arr = [ 'max_traffic' => 1000000000, 'curr_traffic' => 0, 'ban' => 0, 'ip' => '' ];

		} else if( $_POST['type_key'] == 'api' )
		{
			$property_arr = [ 'ban' => 0 ];

		} else if( $_POST['type_key'] == 'telephone' )
		{
			$property_arr = [ 'max_minute' => 2000, 'long_one_call' => 2, 'break_minute' => 5, 'curr_minute' => 0, 'ban' => 0 ];
		}

		$prop->setProperty( serialize( $property_arr ) );

		$doct->persist( $prop );
		$doct->flush();

	}

	private function editSmsProp( $doct, $prop )
	{

	}

	private function editTelephoneProp( $doct, $prop )
	{

	}

	private function editApiProp( $doct, $prop )
	{

	}

	private function editFullProp( $doct, $prop )
	{

	}

	private function editProxyProp( $doct, $prop )
	{

		$ip_find = FunctionHelper::escapeSql( sprintf( $this->ip_search, strlen($_POST['ip_bind']), $_POST['ip_bind'] ) );

		$exist_ip = $doct->createQuery( "SELECT kp FROM BlokBundle:KeysProperty kp 
			WHERE kp.property LIKE '%$ip_find%' AND kp.id <> :key_id " )
			->setParameter( 'key_id', $prop->getId() )->setMaxResults(1)->getOneOrNullResult();

		if( $exist_ip !== null )
		{
			return [$this->errors[0], 'd'];
		}

		$prop_text = unserialize( $prop->getProperty() );
		$prop_text['ip'] = $_POST['ip_bind'];

		$prop->setProperty( serialize( $prop_text ) );
		$doct->flush();

		return [$this->result[0], 's'];
	}

	public function editProperty( $container, $doct, $key )
	{

		if( $_SERVER['REQUEST_METHOD'] !== 'POST' )
		{
			return [false];
		}

		$csrf = $container->get('security.csrf.token_manager');
		$csrf_has = $container->has('security.csrf.token_manager');

		if( $csrf_has && !$csrf->isTokenValid( new CsrfToken('authenticate', $_POST['_csrf_token'] ) ) )
		{
			return [$this->errors[1], 'd'];
		}

		$prop = $this->findOneBy( [ 'id' => $key->getId() ] );

		switch( $key->getKeyType() )
		{

			case 'proxy':   return $this->editProxyProp( $doct, $prop );
			case 'sms':   return $this->editSmsProp( $doct, $prop );
			case 'telephone':   return $this->editTelephoneProp( $doct, $prop );
			case 'api':   return $this->editApiProp( $doct, $prop );
			case 'full':   return $this->editFullProp( $doct, $prop );
		}

		return [false];
	}

}
