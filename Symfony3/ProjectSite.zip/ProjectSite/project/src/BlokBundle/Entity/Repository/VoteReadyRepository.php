<?php

namespace BlokBundle\Entity\Repository;


class VoteReadyRepository extends \Doctrine\ORM\EntityRepository
{
}
