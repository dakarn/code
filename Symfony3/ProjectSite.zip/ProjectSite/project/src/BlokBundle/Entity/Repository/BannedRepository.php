<?php

namespace BlokBundle\Entity\Repository;

use BlokBundle\Entity\Banned;


class BannedRepository extends \Doctrine\ORM\EntityRepository
{

	private $need_level = 5;

	private function banKey($doct, $level, $id, $isban )
	{

		if( $this->need_level <= $level )
		{
			$keys = $doct->createQuery( 'SELECT keys, kp 
				FROM BlokBundle:KeysAccess keys JOIN BlokBundle:KeysProperty kp
				WHERE keys.userId = '.$id.' AND kp.keyId = keys.id' )->getResult();

			foreach( $keys as $key=>$value )
			{
				if( ( $key%2 ) != 0 )
				{
					$prop = unserialize( $value->getProperty() );
					$prop['ban'] = $isban;
					$new_prop = serialize( $prop );

					$doct->createQuery( 'UPDATE BlokBundle:KeysProperty kp
					SET kp.property = :prop WHERE kp.id = '.$value->getId() )->setParameter('prop',$new_prop)->execute();
				}
			}

		}

	}


	public function addToBan( $doct, $id, $form )
	{

		$ban = new Banned();
		$time = 0;

		preg_match_all( '/([0-9]*)(d|h|m)/', $form->get('duration')->getData(), $duration );

		foreach( $duration[2] as $key=>$value )
		{
			if( $value == 'd' ){ $time += 3600 * 24 * (int)$duration[1][$key]; }
			if( $value == 'h' ){ $time += 3600 * (int)$duration[1][$key]; }
			if( $value == 'm' ){ $time += 60 * (int)$duration[1][$key]; }
		}

		$ban->setCause( $form->get('cause')->getData() );
		$ban->setDuration( $time );
		$ban->setLevel( (int)$form->get('level')->getData() );
		$ban->setCreatedAt( time() );
		$ban->setUserId( $id );

		$doct->persist( $ban );
		$doct->flush();


		if( null !== $ban->getId() )
		{
			$this->banKey($doct, (int)$form->get('level')->getData(), $id, 1 );
			return true;
		}

		return false;

	}

	public function deleteFromBan( $doct, $banned )
	{

		$doct->remove($banned);
		$doct->flush();

		if( $banned === null )
		{
			$this->banKey( $doct, $banned->getLevel(), $banned->getUserId(), 0 );
		}

		return true;

	}
}
