<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\GuestBook;

class GuestRepository extends \Doctrine\ORM\EntityRepository
{

	private $errors = [
		'Произошла ошибка при запросе.',
	];
	private $table = [ 'guestbook', 'users' ];

	public function answerGuest( $doct, $user )
	{

		$guest = new GuestBook();

		$guest->setUserID(  $user->getId() )
			->setCreatedAt(time())
			->setUpdatedAt(time())
			->setMessage($_POST['message'])
			->setUsername(  $user->getUsername() );

		$doct->persist($guest);
		$doct->flush();

		if( null !== $guest->getId() )
		{
			$cache = new FileSystemCache( 'guest' );
			$cache->counter( 'incr','guest_count' )->flush();

			return true;
		}

		return $this->errors[0];

	}


	public function addMessage( $doct, $isUser, $form, $user )
	{

		$user_id = 0;
		$username = $form->get('login')->getData();
		$guest = new GuestBook();

		if( $isUser )
		{
			$user_id = $user->getId();
			$username = $user->getUsername();
		}

		$guest->setUserID( $user_id );
		$guest->setCreatedAt( time() );
		$guest->setUpdatedAt( time() );
		$guest->setMessage( $form->get('message')->getData() );
		$guest->setUsername( $username );

		$doct->persist( $guest );
		$doct->flush();

		if( null !== $guest->getId() )
		{
			$cache = new FileSystemCache('guest');
			$cache->counter('incr', 'guest_count')->flush();

			return true;
		}

		return $this->errors[0];

	}

	public function GuestJoinUser()
	{

		return 'SELECT u.*,  g.id AS gid, u.id AS uid, g.created_at AS time, g.* FROM '.$this->table[0].' AS g JOIN '.$this->table[1].' u
		ON g.user_id = u.id ORDER BY time ASC';

	}

}