<?php

namespace BlokBundle\Entity\Repository;


class NoticeNewRepository
{

	private $value = ['support','theme'];
	private $text = ['Вы получили ответ от тех. поддержки.', 'В теме, которую вы отслеживаете написали сообщение(я).'];

	public function addNoticeSupport( $child_id, $user_id )
	{

		$date = date( 'H:i:s', time() );
		$notice = new \Redis();
		$notice->connect('127.0.0.1', 6379 );

		$all_notice = $notice->hgetAll( 'new_notice_'.$user_id );
		$for_json = json_encode( [ 'create' => $date, 'child_id' => $child_id, 'text' => $_POST['message'], 'type' => $this->value[0] ] );


		$all_notice[] = $for_json;
		$notice->hmset( 'new_notice_'.$user_id, $all_notice );

	}

	public function addNoticeTheme( $doct, $theme_id, $user_id )
	{

		$list_follow = $doct->getRepository('BlokBundle:ThemeFollow')->findBy( [ 'themeId' => $theme_id ] );

		$date = date( 'H:i:s', time() );
		$notice = new \Redis();
		$notice->connect('127.0.0.1', 6379 );

		foreach( $list_follow as $value )
		{

			if( $value->getUserId() == $user_id ) continue;

			$all_notice = $notice->hgetAll( 'new_notice_'.$value->getUserId() );
			$for_json = json_encode( [ 'create' => $date, 'child_id' => $theme_id,
				'text' => $_POST['message'], 'type' => $this->value[1] ] );

			$all_notice[] = $for_json;
			$notice->hmset( 'new_notice_'.$value->getUserId(), $all_notice );

		}

		$notice->close();

	}

}
