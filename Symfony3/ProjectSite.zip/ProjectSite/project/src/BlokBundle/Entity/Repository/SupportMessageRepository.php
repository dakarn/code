<?php

namespace BlokBundle\Entity\Repository;

use BlokBundle\Entity\SupportMessage;
use BlokBundle\Entity\User;
use BlokBundle\Helper\UploadFile;


class SupportMessageRepository extends \Doctrine\ORM\EntityRepository
{

	private $errors = [
		'Этот топик закрыт, поэтому писать в него нельзя.',
		'Данный топик не найден.',
		'Произошла ошибка при отправке сообщения.',
		'Такого сообщения не найдено.',
	];

	private function upload()
	{
		$upload = new UploadFile();
		return $upload->setUploader( new \BlokBundle\Helper\Upload\Upload_Bind_Picture( PATH_TO_PICTURE_SUPPORT ) );
	}

	public function answerUser( $doct, $id , $user )
	{

		$support = $doct->getRepository( 'BlokBundle:Support' )->findOneById( $id );

		if( $support === null )
		{
			return $this->errors[1];
		}

		if( $support->getIsclose() == 1 )
		{
			return $this->errors[0];
		}

		$upload = $this->upload();

		if( $upload[0] !== true ) { return $upload; }

		$support->setUpdatedAt( time() );
		$support->setCount( $support->getCount() + 1 );

		$message = new SupportMessage();

		$message->setText( $_POST['message'] );
		$message->setCreatedAt( time() );
		$message->setSupportId( (int)$id );
		$message->setAnswerAdmin( 0 );
		$message->setFiles( '' );
		$message->setUserId( $user->getId() );

		if( isset( $upload[1] ) )
		{
			$message->setFiles( json_encode( $upload[1] ) );
		}

		$doct->persist($message);
		$doct->flush();

		return ( null != $message->getId() ) ? true : $this->errors[2];

	}


	public function answerSupport( $doct, $id, $container )
	{

		$support = $doct->getRepository( 'BlokBundle:Support' )->findOneById( $id );

		if( $support === null )
		{
			return $this->errors[1];
		}

		if( $support->getIsclose() == 1 )
		{
			return $this->errors[0];
		}

		if( $support->getUserId() != $_POST['userId'] )
		{
			return $this->errors[2];
		}

		$upload = $this->upload();

		if( $upload[0] !== true ) { return $upload; }

		$support->setUpdatedAt( time() )->setCount( $support->getCount() + 1 );

		$message = new SupportMessage();

		$message->setText( $_POST['message'] )->setCreatedAt( time() );
		$message->setSupportId( $id )->setAnswerAdmin( 1 );
		$message->setFiles( '' )->setUserId( $_POST['userId'] );

		if( isset( $upload[1] ) )
		{
			$message->setFiles( json_encode( $upload[1] ) );
		}

		$doct->persist($message);
		$doct->flush();

		if( null !== $message->getId() )
		{
			$notice = new NoticeNewRepository();
			$notice->addNoticeSupport( $message->getId(), $_POST['userId'] );

			$this->sendMail( $support->getId(), $container ); return true;
		}

		return $this->errors[2];

	}


	public function deleteMessage( $doct, $id )
	{

		$support = $doct->getRepository( 'BlokBundle:Support' )->findOneById( $id );

		if( $support === null )
		{
			return $this->errors[1];
		}

		$message = $doct->getRepository( 'BlokBundle:SupportMessage' )->findOneById( (int)$_GET['msgid'] );

		if( $message === null )
		{
			return $this->errors[3];
		}

		$support->setUpdatedAt( time() );
		$support->setCount( $support->getCount() - 1 );

		$doct->remove( $message );
		$doct->flush();

		return true;
	}


	public function getCountMessages( $doct, $id )
	{

		$result = $doct->createQuery( 'SELECT COUNT(s.id) FROM BlokBundle:SupportMessage s
		WHERE s.supportId = :id' )->setParameter( ':id', $id );

		return $result->getSingleScalarResult();

	}

	public function getMessagesJoinUser( $id )
	{

		return 'SELECT u.*, s.*, s.created_at AS time FROM support_message AS s LEFT JOIN users u
		ON s.user_id = u.id WHERE s.support_id = '.$id.' ORDER BY time ASC';

	}

	private function sendMail( $support_id, $container )
	{
		$user = $this->getEntityManager()->getRepository('BlokBundle:User')
			->findOneBy( [ 'id' => $_POST['userId'] ] );

		return $container->get('email-notice')->EmailAnswerSupport(  $user, $support_id );
	}

}
