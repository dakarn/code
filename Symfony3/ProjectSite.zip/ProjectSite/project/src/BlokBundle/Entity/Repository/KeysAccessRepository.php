<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\KeysAccess;
use BlokBundle\Helper\FunctionHelper;
use Symfony\Component\Config\Definition\Exception\Exception;

class KeysAccessRepository extends \Doctrine\ORM\EntityRepository
{


	public function createKey( $doct, $request, $class, $user, $container, $type_key, $total_price )
	{

		$duration = FunctionHelper::exists_value_in_arr( $_POST['duration_key'], $class->duration, 'value' );

		$key = new  KeysAccess();
		$key->setUserId( $user->getId() )->setCreatedAt( time() )->setUpdatedAt( 0 )
			->setKeyCode( $container->get('generate')->generateKeyCode( 20 ) )
			->setExpiresAt( time() + $duration )->setKeyType( $request->request->get( 'type_key' ) );

		$doct->persist( $key );
		$doct->flush();

		if( null !== $key->getId() )
		{

			$user->setBalanceFilter( $user->getBalanceFilter() - $total_price );
			$doct->flush();

			$oper_id = $doct->getRepository( 'BlokBundle:History' )
			->addInHistory( $doct, $user,  'buy',
			sprintf( $class->message[0], $type_key[ $_POST['type_key'] ], $total_price ) );

			$doct->getRepository( 'BlokBundle:KeysProperty' )->addPropertyKey( $key );

			$cache = new FileSystemCache('guest');
			$cache->counter( 'incr','keys_count' );

			$this->sendMail( $oper_id, $total_price, $container, $user);

			return true;
		}

		throw new Exception( $class->result[3] );
	}


	public function deleteKey( $doct, $id )
	{

		$key = $doct->getRepository('BlokBundle:KeysAccess')->findOneById( $id );

		if ( $key !== null )
		{
			$doct->remove( $key );
			$doct->flush();

			$cache = new FileSystemCache('guest');
			$cache->counter('decr', 'keys_count')->flush();
		}

		return true;
	}

	public function deleteAll( $notice, $result )
	{

		$connection = $this->getEntityManager()->getConnection();

		if($connection->query( 'TRUNCATE TABLE guestbook' ) )
		{
			$notice->add( 'success', $result[1] );
			$cache = new FileSystemCache('guest');
			$cache->set( 'keys_count', 0 )->flush();

		} else {
			$notice->add( 'danger', $result[2] );
		}

		return true;

	}

	public function addKeyTests( $doct, $user )
	{

		$count = 10000;
		$userID = $user->getId();
		$username = $user->getUsername();

		for( $i = 0; $i < $count; ++$i )
		{

			$key = new KeysAccess();

			$key->setUserID( $userID );
			$key->setCreatedAt( time() );
			$key->setUpdatedAt( 0 );
			$key->setExpiresAt( time() + 2419200 );
			$key->setKeyCode( $this->get( 'generate' )->generateKeyCode( 40 ) );
			$key->setKeyType( 'full' );

			$doct->persist($key);

		}

		$doct->flush();

		$cache = new FileSystemCache('guest');
		$cache->set( 'keys_count', $cache->set( 'keys_count', $count ) + $count )->flush();

		return true;

	}

	private function sendMail( $oper_id, $count_money, $container, $user )
	{
		return $container->get('email-notice')->EmailBuy(  $user, $count_money, $oper_id );
	}

}
