<?php

namespace BlokBundle\Entity\Repository;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\Complain;


class ComplainRepository extends \Doctrine\ORM\EntityRepository
{

	private $errors = [ 'Ошибка при добавлении жалобы.' ];
	private $type = [ 'theme', 'post', 'user' ];

	public function createThemeComplain( $doct, $theme_id )
	{

		$complain = new Complain();

		$complain->setText( $_POST['text_complain'] );
		$complain->setType( $this->type[0] );
		$complain->setChildId( $theme_id );
		$complain->setCreatedAt( time() );

		$doct->persist( $complain);
		$doct->flush();

		if( null !== $complain->getId() )
		{
			$cache = new FileSystemCache('guest');
			$cache->counter('incr', 'complain_count')->flush();
			return true;
		}

		return $this->errors[0];
	}

	public function createPostComplain( $doct, $post_id )
	{

		$complain = new Complain();

		$complain->setText( $_POST['text_complain'] );
		$complain->setType( $this->type[1] );
		$complain->setChildId( $post_id );
		$complain->setCreatedAt( time() );

		$doct->persist( $complain);
		$doct->flush();

		if( null !== $complain->getId() )
		{
			$cache = new FileSystemCache('guest');
			$cache->counter('incr', 'complain_count')->flush();
			return true;
		}
	}

	public function createUserComplain( $doct, $post_id )
	{

		$complain = new Complain();

		$complain->setText( $_POST['text_complain'] );
		$complain->setType( $this->type[2] );
		$complain->setChildId( $post_id );
		$complain->setCreatedAt( time() );

		$doct->persist( $complain);
		$doct->flush();

		if( null !== $complain->getId() )
		{
			$cache = new FileSystemCache('guest');
			$cache->counter('incr', 'complain_count')->flush();
			return true;
		}
	}

}
