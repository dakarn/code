<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Entity\Telephone;
use Symfony\Bundle\FrameworkBundle\Console\Application;
use Symfony\Component\Console\Input\ArrayInput;
use Symfony\Component\Console\Output\BufferedOutput;

class TelephoneRepository extends \Doctrine\ORM\EntityRepository
{

	private $command = [ 'delete-phone-expired' ];
	private $price = 30;
	private $errors = [ 'Такого номера не существует.',
		'Это не ваш номерю Ошибка при удалении.', ];

	public function addTelephone( $doct, $user )
	{

		$number = new Telephone();
		$number->setUserId( $user->getId() );
		$number->setNumber($_POST['number_phone']);
		$number->setCreatedAt(time());
		$number->setPayment( 1 );

		$doct->persist($number);
		$doct->flush();

		$user->setBalanceFilter( $user->getBalanceFilter() - $this->price );
		$doct->flush();


		return ( null != $number->getId() ) ? true : false;

	}

	public function deleteExpirePhone( $container )
	{
		$application = new Application($container->get('kernel'));
		$application->setAutoExit(false);

		$input = new ArrayInput( array( $this->command[0] ) );
		$output = new BufferedOutput();

		$application->run($input, $output);
	}

	public function deleteTelephone( $doct, $id, $user )
	{

		$number = $this->findOneBy( [ 'id' => $id ] );

		if( $number === null )
		{
			return $this->errors[0];
		}

		if( $number->getUserId() !== $user->getId() )
		{
			return $this->errors[1];
		}

		$doct->remove( $number );
		$doct->flush();

		return true;

	}

}
