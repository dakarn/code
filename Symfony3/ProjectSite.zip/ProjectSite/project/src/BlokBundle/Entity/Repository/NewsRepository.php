<?php

namespace BlokBundle\Entity\Repository;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\Comments;
use BlokBundle\Entity\News;
use BlokBundle\Helper\UploadFile;


class NewsRepository extends \Doctrine\ORM\EntityRepository
{

	private $errors = [
		'Ошибка при добавлении новости.',
		'Ошибка при изменении новости.',
		'Такая новость не найдена.',
		'Ошибка при лобавлении комментария.',
	];
	private $offset_user = 0;

	private function upload()
	{
		$upload = new UploadFile();
		return $upload->setUploader( new \BlokBundle\Helper\Upload\Upload_Bind_Picture( PATH_TO_PICTURE_NEWS ) );
	}


	private function sendMailNews($doct, $form, $container)
	{

		$users = $doct->createQuery('SELECT u from BlokBundle:User u')
			->setMaxResults(2)->setFirstResult($this->offset_user)->getResult();

		if( count( $users ) == 0 ) return;

		$container->get('email-notice')->EmailNewNews($users, $form );


		$this->offset_user += 2;
		usleep(200);
		return $this->sendMailNews($doct, $form, $container);
	}

	public function addCommentNews( $doct, $user, $form, $news_id )
	{

		if( !$form->isValid() ) { return $form->getErrors( true ); }


		if( ($news = $this->findOneById(  $news_id )) === null )
		{
			return $this->errors[2];
		}

		$news->setCountComment( $news->getCountComment() + 1 );

		$comment = new Comments();
		$comment->setCreatedAt( time() );
		$comment->setText( $form->get('message')->getData() );
		$comment->setType( 'news' );
		$comment->setUserId( $user->getId() );

		$doct->persist( $comment );
		$doct->flush();

		return ( null != $comment->getId() ) ? true : $this->errors[3];

	}

	public function addViews( $doct, $news )
	{

		$news->setCountViews( $news->getCountViews() + 1 );
		$doct->flush();
	}

	public function createNews( $doct, $form, $container )
	{

		if( !$form->isValid() ) { return $form->getErrors( true ); }

		$upload = $this->upload();

		if( $upload[0] !== true )
		{
			return $upload;
		}

		$news = new News();
		
		$news->setCreatedAt( time() )->setText( $form->get( 'message' )->getData() );
		$news->setCountComment( 0 )->setCountViews( 0 )->setFiles( '' );
		$news->setTitle( $form->get( 'title' )->getData() )->setCloseComment( 0 );

		if( isset( $upload[1] ) )
		{
			$news->setFiles( json_encode( $upload[1] ) );
		}

		$doct->persist( $news );
		$doct->flush();

		if( null !== $news->getId() )
		{
			$cache = new FileSystemCache('guest');
			$cache->counter('incr', 'news_count')->flush();

			if( isset( $_POST['send_users'] ) ) $this->sendMailNews($doct, $form, $container);

			return true;
		}

		return $this->errors[0];

	}


	public function  editNews( $doct, $news, $form )
	{

		if( !$form->isValid() )
		{
			return $form->getErrors( true );
		}


		$news->setText( $form->get( 'message' )->getData() );
		$news->setTitle( $form->get( 'title' )->getData() );

		$doct->flush();

		return ( null != $news->getId() ) ? true : $this->errors[1];

	}


	public function  deleteNews( $doct )
	{

		$news = $this->findOneById(  abs( (int)$_GET['news_id'] ) );

		if( $news === null )
		{
			return $this->errors[2];
		}

		$doct->remove( $news );
		$doct->flush();

		$cache = new FileSystemCache('guest');
		$cache->counter('decr', 'news_count')->flush();

		return true;
	}


	public function  closeCommentNews( $doct )
	{

		$news = $this->findOneById(  abs( (int)$_GET['news_id'] ) );

		if( $news === null )
		{
			return $this->errors[2];
		}

		$news->setCloseComment( $news->getCloseComment() == 0 ? 1:0 );
		$doct->flush();

		return true;
	}


	public function  clearAllNews()
	{

		$pdo = $this->getEntityManager()->getConnection();
		$pdo->exec( 'TRUNCATE TABLE news' );

		$cache = new FileSystemCache('guest');
		$cache->set( 'news_count', 0 )->flush();

		return true;
	}


	public function  deleteAllComment( $doct )
	{

		return true;
	}

}
