<?php

namespace BlokBundle\Entity\Repository;

use BlokBundle\Entity\Privilegy;


class PrivilegyRepository extends \Doctrine\ORM\EntityRepository
{

	public function addPrivilegy( $em )
	{

		$priv = new Privilegy();
		$priv->setName( $_POST['name_privilegy'] );
		$priv->setDescription( $_POST['disc_privilegy'] );

		$em->persist($priv);
		$em->flush();

		return true;
	}
}
