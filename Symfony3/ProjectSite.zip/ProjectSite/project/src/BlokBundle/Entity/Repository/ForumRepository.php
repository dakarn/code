<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Entity\Forum;
use BlokBundle\Entity\Post;
use BlokBundle\Entity\Theme;
use BlokBundle\Helper\FunctionHelper;
use Symfony\Component\Config\Definition\Exception\Exception;

class ForumRepository extends \Doctrine\ORM\EntityRepository
{

	private $tb_search = ['BlokBundle:Theme t','BlokBundle:Post p', 'BlokBundle:Theme t', 'BlokBundle:Theme t'];
	private $tb_alias = ['t','p','t','t'];
	private $curr_table = 0;
	private $curr_alias_tb = 0;
	private $errors = [
		'Не заполнено название (под)форума.',
		'Не верно указан родительский форум.',
		'Не введено искомое слово.',
	];
	private $not_like = 'quote-post-theme';

	private function loadIcon()
	{

		if( !empty( $_POST['icon_menu_css'] ) ) { return 'css::'.htmlspecialchars($_POST['icon_menu_css']); }

		if( empty( $_FILES['icon_menu']['tmp_name'] ) ) { return ''; }

		if ( move_uploaded_file( $_FILES['icon_menu']['tmp_name'], $this->path.basename( $_FILES['icon_menu']['name'] ) ) )
		{
			return basename( $_FILES['icon_menu']['name'] );
		}

		return '';
	}

	public function createManyThemeTest( $doct )
	{

		$text = [ 'Тестовая тема для нагрузки. %s.',
			'This block makes use of several variables: compound, label_attr, required, label, name and translation_domain. These variables are made available by the form rendering system. But more importantly, these are the variables that you can override when calling form_label() (since in this example, you\'re rendering the label).' ];
		$count = 10000;
		$forum_id = 6;
		$rand_user = [ 11, 22, 24, 19 ];

		for( $i = 0; $i < $count; ++$i )
		{
			$theme = new Theme();
			$theme->setTitle( sprintf( $text[0], date( 'H:i - d.m.Y', time() ) ) )->setCreatedAt(time());
			$theme->setCountPost(0)->setUpdatedAt(time())->setCountviews(0)->setText($text[1]);
			$theme->setUserId(  $rand_user[ rand(0,3) ] )->setUsername( 'Dakarn' )->setUpdatedAtText('');
			$theme->setForumId( $forum_id )->setIsclose(0)->setFiles('');

			$doct->persist( $theme );
		}

		$doct->flush(); $doct->clear();

		$forum = $this->findOneById( $forum_id );
		$forum->setCountTheme( $forum->getCountTheme() + $count );
		$doct->flush();

		return true;

	}

	public function createManyPostTest( $doct )
	{

		$text = [ 'Тестовая пост темы для нагрузки. %s.' ];
		$count = 10000;
		$forum_id = 6;
		$rand_user = [ 11, 22, 24, 19 ];
		$rand_theme = [ 5, 7, 8, 18, 19, 20 , 21, 56 , 567 , 2666 ];

		for( $i = 0; $i < $count; ++$i )
		{
			$post = new Post();
			$post->setText( sprintf( $text[0], date( 'H:i - d.m.Y', time() ) ) )->setCreatedAt(time());
			$post->setUserId( $rand_user[ rand(0,3) ] )->setThemeId( $rand_theme[ rand(0,9) ] )->setCreatedAt( time() );
			$post->setUpdatedAt( time() )->setPublic( 1 )->setForumId( $forum_id );
			$post->setFiles( '' )->setUsefull( 0 );

			$doct->persist( $post );
		}

		$doct->flush(); $doct->clear();

		$forum = $this->findOneById( $forum_id );
		$forum->setCountPosts( $forum->getCountPosts() + $count );
		$doct->flush();

		return true;

	}


	private function setFilterSearch($text)
	{

		$filter = '';
		$table = 't.title';
		$curr_table ='Theme t';
		$table_arr = [ 0=>'t.title',1=>'p.text',2=>'t.text',3=>'t.username' ];

		if( key_exists( $_GET['filter_space'], $table_arr ) )
		{
			$table = $table_arr[$_GET['filter_space']];
			$this->curr_table = $_GET['filter_space'];

			$this->tb_alias[$this->curr_alias_tb];
			$this->curr_alias_tb = $_GET['filter_space'];
		}

		$filter .= $table." NOT LIKE '%$this->not_like%' AND ";

		if( $_GET['filter_word'] == 0 || $_GET['filter_word'] == 1 )
		{
			$filter .= $table." LIKE '%$text%'";

		} else if( $_GET['filter_word'] == 2 )
		{
			$str = explode( ' ', $text ); $filter .= '(';

			foreach( $str as $v )
			{
				if( strlen($v) >= 3 ) $filter .= $table." LIKE '%$v%' OR ";
			}

			$filter = substr($filter,0,-3); $filter .= ')';
		}

		return $filter;
	}


	private function setSortSearch()
	{

		$tb = $this->tb_alias[$this->curr_alias_tb];
		$sort_arr = [ 0 => 'createdAt', 1 => 'updatedAt' ];

		if( key_exists( $_GET['filter_sort'], $sort_arr ) )
		{
			return $tb.'.'.$sort_arr[$_GET['filter_sort']];
		}

		return $tb.'.id';
	}


	public function processSearch($doct)
	{

		if( strlen( $_GET['text_search'] ) <= 2 )
		{
			return $this->errors[2];
		}

		if( !isset($_GET['filter_space']) || !isset($_GET['filter_word']) )
		{
			$_GET['filter_space'] = 0; $_GET['filter_word'] = 0;
		}

		if( $_GET['filter_space'] > 4 || $_GET['filter_word'] > 2 )
		{
			$_GET['filter_space'] = 0; $_GET['filter_word'] = 0;
		}

		$text = FunctionHelper::escapeSql( $_GET['text_search'] );
		$filter = $this->setFilterSearch($text);

		$prepare = $doct->createQuery( "SELECT ".$this->tb_alias[$this->curr_alias_tb]." 
		FROM ".$this->tb_search[$this->curr_table]."
		WHERE ".$filter."
		ORDER BY ".$this->setSortSearch()." DESC" )->setMaxResults(50)->getResult();

		return $prepare;

	}


	public function closeForum( $doct, $forum )
	{
		$forum->setIsclose( $forum->getIsclose() == 0 ? 1 : 0 );
		$doct->flush();
	}


	public function removeForum( $doct, $forum )
	{

		$conn = $this->getEntityManager()->getConnection();
		$trans = $conn->beginTransaction();

		try {

			$del_post = $doct->createQuery('DELETE BlokBundle:Post p WHERE p.forumId = :id')->setParameter('id', $_GET['forumid']);
			$del_post->execute();

			$del_theme = $doct->createQuery('DELETE BlokBundle:Theme t WHERE t.forumId = :id')->setParameter('id', $_GET['forumid']);
			$del_theme->execute();

			$del_sub = $doct->createQuery('DELETE BlokBundle:Forum f WHERE f.parentId = :id')->setParameter('id', $_GET['forumid']);
			$del_sub->execute();

			$doct->remove($forum);
			$doct->flush();

			$conn->commit(); return true;

		} catch ( Exception $e )
		{
			$conn->rollBack();
			return false;
		}
	}

	public function createForum( $doct )
	{

		$forum = new Forum();

		$forum->setParentId( 0 );
		$forum->setLastMessageId( 0 );
		$forum->setLastAuthorId( 0 );
		$forum->setLastAuthor( '' );
		$forum->setIcon( $this->loadIcon() );
		$forum->setUpdatedAtText( '' );
		$forum->setTitle( $_POST['forum_title'] );
		$forum->setCountTheme( 0 );
		$forum->setCountPosts( 0 );
		$forum->setIsclose( 0 );

		$doct->persist( $forum );
		$doct->flush();
	}


	public function recountThemeInForum( $doct, $forum )
	{

		$id = (int)$_GET['forumid'];

		$count_post = $doct->createQuery('SELECT COUNT(p.id) FROM BlokBundle:Post p WHERE p.forumId = :id')
			->setParameter( ':id', $id )->getSingleScalarResult();

		$count_theme = $doct->createQuery('SELECT COUNT(t.id) FROM BlokBundle:Theme t WHERE t.forumId = :id')
			->setParameter( ':id', $id )->getSingleScalarResult();

		$forum->setCountPosts( $count_post );
		$forum->setCountTheme( $count_theme );
		$doct->flush();

		return true;

	}


	public function createSubForum( $doct )
	{

		$forum = new Forum();

		$forum->setParentId( $_POST['forum_parent'] );
		$forum->setLastMessageId( 0 );
		$forum->setLastAuthorId( 0 );
		$forum->setLastAuthor( '' );
		$forum->setUpdatedAtText( '' );
		$forum->setIcon( $this->loadIcon() );
		$forum->setTitle( $_POST['forum_title'] );
		$forum->setCountTheme( 0 );
		$forum->setCountPosts( 0 );
		$forum->setIsclose( 0 );

		$doct->persist( $forum );
		$doct->flush();
	}


	public function SaveEditForum( $doct, $forum )
	{

		if( empty( $_POST['forum_title']) )
		{
			return $this->errors[0];
		}

		if( isset( $_POST['forum_parent']) )
		{
			$parent_forum = $this->findOneById( abs( (int)$_POST['forum_parent'] ) );

			if( !is_numeric( $_POST['forum_parent'] ) || $parent_forum === null )
			{
				return $this->errors[1];
			}
		}

		$forum->setTitle( $_POST['forum_title'] );
		$forum->setIcon( $this->loadIcon() );
		$forum->setParentId( isset( $_POST['forum_parent'] ) ? (int)$_POST['forum_parent']:0  );

		$doct->flush();

		return true;

	}



}
