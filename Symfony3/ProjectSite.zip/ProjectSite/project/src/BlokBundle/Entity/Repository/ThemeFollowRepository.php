<?php

namespace BlokBundle\Entity\Repository;

use BlokBundle\Entity\ThemeFollow;


class ThemeFollowRepository extends \Doctrine\ORM\EntityRepository
{

	private $result = ['Тема теперь отслеживается. При новом сообщении в теме вы получите уведомление!',
					   'Вы больше не следите за этой темой!'];
	private $errors = ['Вы уже следите за этой темой.',
					   'Ошибка при добавлении темы в слежение',
					   'Ошибка при удалени темы из слежения.', ];

	public function addFollowTheme( $user_id, $theme_id )
	{

		$doct = $this->getEntityManager();

		if( null !== $this->findOneBy( [ 'userId' => $user_id, 'themeId' => $theme_id ] ) )
		{
			return $this->removeFollowTheme($user_id, $theme_id);
		}

		$follow = new ThemeFollow();
		$follow->setUserId( $user_id );
		$follow->setThemeId( $theme_id );

		$doct->persist($follow);
		$doct->flush();

		return ( null != $follow->getId() ) ? [ 's', $this->result[0] ] : [ 'd', $this->errors[1] ];

	}

	public function removeFollowTheme( $user_id, $theme_id )
	{

		$doct = $this->getEntityManager();

		$follow = $this->findOneBy( [ 'userId' => $user_id, 'themeId' => $theme_id ] );

		if( $follow !== null )
		{
			$doct->remove($follow);
			$doct->flush();
		}

		return ( null === $follow->getId() ) ? [ 's', $this->result[1] ] : [ 'd', $this->errors[1] ];

	}

}
