<?php

namespace BlokBundle\Entity\Repository;

use BlokBundle\Entity\Role;


class RoleRepository extends \Doctrine\ORM\EntityRepository
{


	private function parseFunPriv( $privilegy_role )
	{
		$parse_priv = [];
		$exp = explode( ';', $privilegy_role );
		$delim_fun = '--';

		if( !isset( $exp[1] ) ){ return false; }

		foreach( $exp as $key => $value )
		{

			$name = explode( ':', trim( $value ) );

			if( !isset( $name[1] ) ) continue;

			if( !isset( $parse_priv[$name[0]] ) )
			{
				$parse_priv[trim($name[0])] = [];
			}

			$fun = explode( $delim_fun, trim( $name[1] ) );

			foreach( $fun as $value_fun )
			{
				if( !isset( $parse_priv[$name[0]][$value_fun] ) )
				{
					$parse_priv[ $name[0] ][$value_fun] = $value_fun;
				}
			}

		}

		$privilegy_role = '';

		foreach( $parse_priv as $key=> $value )
		{
			$privilegy_role .= $key.':'.implode( $delim_fun, $value ).';';
		}

		return $privilegy_role;
	}

	public function editRole( $em, $role )
	{

		$privilegy_role = $this->parseFunPriv( $_POST['privilegy_role'] );

		$role->setName( $_POST['name_role'] );
		$role->setValue( $_POST['value_role'] );
		$role->setPrivilegy( $privilegy_role );

		$em->persist($role);
		$em->flush();

		return true;
	}


	public function addRole( $em )
	{

		$privilegy_role = $this->parseFunPriv( $_POST['privilegy_role'] );

		$role = new Role();
		$role->setName( $_POST['name_role'] );
		$role->setValue( $_POST['value_role'] );
		$role->setPrivilegy( $privilegy_role );

		$em->persist($role);
		$em->flush();

		return ( null != $role->getId() ) ? true : false;
	}
}
