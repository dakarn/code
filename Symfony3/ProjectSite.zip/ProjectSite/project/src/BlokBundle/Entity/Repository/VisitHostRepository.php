<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\VisitHost;

class VisitHostRepository extends \Doctrine\ORM\EntityRepository
{

	private $resuilt = ['Тестовые визиты созданы!'];

	public function createTestVisit( $doct )
	{

		$count = 50000;
		$ua = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36';

		for( $i = 0; $i < $count; ++$i )
		{
			$visit = new VisitHost();

			$ip = rand(0,255).'.'.rand(0,255).'.'.rand(0,255).'.'.rand(0,255);

			$visit->setCountVisit( 1 )->setVisitTime( new \DateTime );
			$visit->setUa( $ua )->setReferer( '' )->setIp( ip2long($ip) );

			$doct->persist( $visit );
		}

		$doct->flush();
		$doct->clear();

		$cache = new FileSystemCache( 'guest' );
		$cache->set( 'count_uniq_visit', (int)$cache->get('count_uniq_visit') + $count );
		$cache->set( 'count_visit', (int)$cache->get('count_visit') + $count )->flush();

		return $this->resuilt[0];

	}

	public function deleteAll( $doct )
	{

	}

}
