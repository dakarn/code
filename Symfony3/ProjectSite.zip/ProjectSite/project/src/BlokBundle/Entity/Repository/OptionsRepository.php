<?php

namespace BlokBundle\Entity\Repository;

use BlokBundle\Entity\Options;


class OptionsRepository extends \Doctrine\ORM\EntityRepository
{

	public function addOptions( $doct )
	{
		$options = new Options();
		$options->setName( $_POST['name_options'] );
		$options->setValue( $_POST['value_options'] );
		$options->setType( $_POST['type_options'] );
		$options->setAlias( $_POST['alias_options'] );
		$options->setTypeForm( $_POST['type_form_options'] );

		$doct->persist( $options );
		$doct->flush();

		return ( null != $options->getId() ) ? true : false;
	}


	public function SaveOptions( $em, $options )
	{

		foreach ( $options as $key => $option )
		{
			if( !isset( $_POST['common_setting'][$option->getName()] ) )
			{
				$value = 'off';

			} else {

				$value = $_POST['common_setting'][$option->getName()];
			}

			$option->setName( $option->getName() );
			$option->setValue( $value );
		}

		$em->flush();
		$em->clear();

	}


	public function SaveOptionsForum( $doct, $options )
	{

		foreach ( $options as $key => $option )
		{
			if( !isset( $_POST[$option->getName()] ) )
			{
				$value = 'off';

			} else {

				$value = $_POST[$option->getName()];
			}

			$option->setName( $option->getName() );
			$option->setValue( $value );
		}

		$doct->flush();
		$doct->clear();

	}

	public function SaveOptionsNotice( $doct, $options )
	{

		foreach ( $options as $key => $option )
		{
			if( !isset( $_POST[$option->getName()] ) )
			{
				$value = 'off';

			} else {

				$value = $_POST[$option->getName()];
			}

			$option->setName( $option->getName() );
			$option->setValue( $value );
		}

		$doct->flush();
		$doct->clear();

	}

}
