<?php

namespace BlokBundle\Entity\Repository;


use BlokBundle\Entity\VoteReady;
use Symfony\Component\Config\Definition\Exception\Exception;

class ThemeVoteRepository extends \Doctrine\ORM\EntityRepository
{

	private $type = 'theme';

	public function addVoteTheme( $doct, $user_id )
	{

		$theme_id = (int)$_POST['theme_id'];
		$vote_id = (int)$_POST['vote_id'];

		$ready = $doct->getRepository('BlokBundle:VoteReady');

		$vote = $this->findOneBy( ['id' => $vote_id ] );

		if( null === $vote ){ return 0; }

		if( $ready->findOneBy([ 'type' => $this->type, 'parentId' => $theme_id , 'userId' => $user_id ]) !== null )
		{
			return 1;
		}

		if( $theme_id != $vote->getThemeId() ){ return 0; }

		$conn = $this->getEntityManager()->getConnection();
		$trans = $conn->beginTransaction();

		try {

			$vote->setCountVote($vote->getCountVote() + 1);
			$doct->flush();

			$ready_vote = new VoteReady();
			$ready_vote->setUserId($user_id);
			$ready_vote->setType($this->type);
			$ready_vote->setParentId($theme_id);

			$doct->persist($ready_vote);
			$doct->flush();

			$conn->commit();

		} catch( Exception $e )
		{
			$conn->rollBack();
			return false;
		}

		return true;

	}
}
