<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Theme
 *
 * @ORM\Table(name="forum_theme")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\ThemeRepository")
 */
class Theme
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="title", type="string", length=255)
     */
    private $title;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="files", type="string", length=1000)
	 */
	private $files;

    /**
     * @var int
     *
     * @ORM\Column(name="user_id", type="integer")
     */
    private $userId;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="important", type="integer")
	 */
	private $important;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="countviews", type="integer")
	 */
	private $countviews;

    /**
     * @var int
     *
     * @ORM\Column(name="created_at", type="integer")
     */
    private $createdAt;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="public", type="integer")
	 */
	private $public;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="updated_at", type="integer")
     */
    private $updatedAt;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="updated_at_text", type="string", length=100)
	 */
	private $updatedAtText;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="username", type="string", length=100)
	 */
	private $username;
	
    /**
     * @var int
     *
     * @ORM\Column(name="forum_id", type="integer")
     */
    private $forumId;

    /**
     * @var int
     *
     * @ORM\Column(name="count_post", type="integer")
     */
    private $countPost;

    /**
     * @var int
     *
     * @ORM\Column(name="isclose", type="integer")
     */
    private $isclose;

    /**
     * @var string
     *
     * @ORM\Column(name="text", type="string", length=2000)
     */
    private $text;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Theme
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return Theme
     */
    public function setUserId($userId)
    {
        $this->userId = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return int
     */
    public function getUserId()
    {
        return $this->userId;
    }

    /**
     * Set createdAt
     *
     * @param integer $createdAt
     *
     * @return Theme
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return int
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Theme
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set forumId
     *
     * @param integer $forumId
     *
     * @return Theme
     */
    public function setForumId($forumId)
    {
        $this->forumId = $forumId;

        return $this;
    }

    /**
     * Get forumId
     *
     * @return int
     */
    public function getForumId()
    {
        return $this->forumId;
    }

    /**
     * Set countPost
     *
     * @param integer $countPost
     *
     * @return Theme
     */
    public function setCountPost($countPost)
    {
        $this->countPost = $countPost;

        return $this;
    }

    /**
     * Get countPost
     *
     * @return int
     */
    public function getCountPost()
    {
        return $this->countPost;
    }

    /**
     * Set isclose
     *
     * @param integer $isclose
     *
     * @return Theme
     */
    public function setIsclose($isclose)
    {
        $this->isclose = $isclose;

        return $this;
    }

    /**
     * Get isclose
     *
     * @return int
     */
    public function getIsclose()
    {
        return $this->isclose;
    }

    /**
     * Set text
     *
     * @param string $text
     *
     * @return Theme
     */
    public function setText($text)
    {
        $this->text = $text;

        return $this;
    }

    /**
     * Get text
     *
     * @return string
     */
    public function getText()
    {
        return $this->text;
    }

    /**
     * Set countviews
     *
     * @param integer $countviews
     *
     * @return Theme
     */
    public function setCountviews($countviews)
    {
        $this->countviews = $countviews;

        return $this;
    }

    /**
     * Get countviews
     *
     * @return integer
     */
    public function getCountviews()
    {
        return $this->countviews;
    }

    /**
     * Set updateAtText
     *
     * @param string $updateAtText
     *
     * @return Theme
     */
    public function setUpdatedAtText($updatedAtText)
    {
        $this->updatedAtText = $updatedAtText;

        return $this;
    }

    /**
     * Get updateAtText
     *
     * @return string
     */
    public function getUpdatedAtText()
    {
        return $this->updatedAtText;
    }

    /**
     * Set username
     *
     * @param string $username
     *
     * @return Theme
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set files
     *
     * @param string $files
     *
     * @return Theme
     */
    public function setFiles($files)
    {
        $this->files = $files;

        return $this;
    }

    /**
     * Get files
     *
     * @return string
     */
    public function getFiles()
    {
        return $this->files;
    }

    /**
     * Set public
     *
     * @param integer $public
     *
     * @return Theme
     */
    public function setPublic($public)
    {
        $this->public = $public;

        return $this;
    }

    /**
     * Get public
     *
     * @return integer
     */
    public function getPublic()
    {
        return $this->public;
    }

    /**
     * Set important
     *
     * @param integer $important
     *
     * @return Theme
     */
    public function setImportant($important)
    {
        $this->important = $important;

        return $this;
    }

    /**
     * Get important
     *
     * @return integer
     */
    public function getImportant()
    {
        return $this->important;
    }
}
