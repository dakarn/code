<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * VisitHost
 *
 * @ORM\Table(name="visit_host")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\VisitHostRepository")
 */
class VisitHost
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var int
     *
     * @ORM\Column(name="ip", type="integer")
     */
    private $ip;

	/**
	 * @var int
	 *
	 * @ORM\Column(name="count_visit", type="integer")
	 */
	private $countVisit;

    /**
     * @var string
     *
     * @ORM\Column(name="ua", type="string", length=255)
     */
    private $ua;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="visit_time", type="datetime")
     */
    private $visitTime;

    /**
     * @var string
     *
     * @ORM\Column(name="referer", type="string", length=255)
     */
    private $referer;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set ip
     *
     * @param integer $ip
     *
     * @return VisitHost
     */
    public function setIp($ip)
    {
        $this->ip = $ip;

        return $this;
    }

    /**
     * Get ip
     *
     * @return int
     */
    public function getIp()
    {
        return $this->ip;
    }

    /**
     * Set ua
     *
     * @param string $ua
     *
     * @return VisitHost
     */
    public function setUa($ua)
    {
        $this->ua = $ua;

        return $this;
    }

    /**
     * Get ua
     *
     * @return string
     */
    public function getUa()
    {
        return $this->ua;
    }

    /**
     * Set visitTime
     *
     * @param \DateTime $visitTime
     *
     * @return VisitHost
     */
    public function setVisitTime($visitTime)
    {
        $this->visitTime = $visitTime;

        return $this;
    }

    /**
     * Get visitTime
     *
     * @return \DateTime
     */
    public function getVisitTime()
    {
        return $this->visitTime;
    }

    /**
     * Set referer
     *
     * @param string $referer
     *
     * @return VisitHost
     */
    public function setReferer($referer)
    {
        $this->referer = $referer;

        return $this;
    }

    /**
     * Get referer
     *
     * @return string
     */
    public function getReferer()
    {
        return $this->referer;
    }


    public function setCountVisit($c)
    {
        $this->countVisit = $c;

        return $this;
    }


    public function getCountVisit()
    {
        return $this->countVisit;
    }
}
