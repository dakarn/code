<?php

namespace BlokBundle\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Options
 *
 * @ORM\Table(name="options")
 * @ORM\Entity(repositoryClass="BlokBundle\Entity\Repository\OptionsRepository")
 */
class Options
{
    /**
     * @var int
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=255)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="value", type="string", length=255)
     */
    private $value;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="type", type="string", length=50)
	 */
	private $type;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="alias", type="string", length=50)
	 */
	private $alias;

	/**
	 * @var string
	 *
	 * @ORM\Column(name="type_form", type="string", length=50)
	 */
	private $type_form;


    /**
     * Get id
     *
     * @return int
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return Options
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }


	/**
	 * Set name
	 *
	 * @param string $name
	 *
	 * @return Options
	 */
	public function setType($type)
	{
		$this->type = $type;

		return $this;
	}

	/**
	 * Get name
	 *
	 * @return string
	 */
	public function getType()
	{
		return $this->type;
	}

    /**
     * Set value
     *
     * @param string $value
     *
     * @return Options
     */
    public function setValue($value)
    {
        $this->value = $value;

        return $this;
    }

    /**
     * Get value
     *
     * @return string
     */
    public function getValue()
    {
        return $this->value;
    }

    /**
     * Set alias
     *
     * @param string $alias
     *
     * @return Options
     */
    public function setAlias($alias)
    {
        $this->alias = $alias;

        return $this;
    }

    /**
     * Get alias
     *
     * @return string
     */
    public function getAlias()
    {
        return $this->alias;
    }

    /**
     * Set typeForm
     *
     * @param string $typeForm
     *
     * @return Options
     */
    public function setTypeForm($typeForm)
    {
        $this->type_form = $typeForm;

        return $this;
    }

    /**
     * Get typeForm
     *
     * @return string
     */
    public function getTypeForm()
    {
        return $this->type_form;
    }
}
