<?php

return array(
	'Send message' => 'Отправить',
	'Username:' => 'Имя:',
	'Message:' => 'Сообщение:',
	'Enter the code from picture:' => 'Введите код с картинки:',
	'Author' => 'Автор',
	'Guestbook' => 'Гостевая книга',
);