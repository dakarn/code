<?php

namespace BlokBundle\Cache;

use BlokBundle\Cache\CacheInterface;


class MemCache extends \Memcache implements CacheInterface
{


	public function __construct( $connect_data )
	{
		$this->connect( $connect_data['host'], $connect_data['port'] );
	}


	public function count()
	{
		return $this->getStats()['total_items'];
	}


	public function replaceKey( $key, $new_key )
	{
		$value = $this->get( $key );
		$this->delete( $key );
		$this->add( $new_key, $value );

		return $this;
	}


	private function incrAndDecr( $key, $int )
	{

		$new_value = (int)$this->get( $key );

		if( is_numeric( $new_value ) )
		{
			$this->set($key, $new_value + $int );
		}

		return $this;
	}


	public function counter( $type, $key, $count = 1 )
	{

		$value = $type == 'incr' ? $count: ( $type == 'decr' ? -$count:0 );

		$this->incrAndDecr( $key, $value );

		return $this;
	}


	public function replace( $key, $item )
	{
		return parent::replace( $key, $item );
	}


	public function has( $element )
	{
		return true === $this->get( $element ) ? true : false;
	}


	public function remove( $key )
	{
		return $this->delete( $key );
	}


	public function clearAll()
	{
		return $this->flush();
	}


	public function __destruct()
	{
		return $this->close();
	}

}