<?php

namespace BlokBundle\Cache;

use BlokBundle\Cache\CacheInterface;


class RedisCache extends \Redis implements CacheInterface
{


	private function checkExists( $key )
	{
		return $this->exists( $key );
	}


	public function __construct( $connect_data )
	{
		$this->connect( $connect_data['host'], $connect_data['port'] );
	}


	public function count()
	{
	}


	public function counter( $type, $key, $count = 1 )
	{
		if( $type == 'incr' ){ $this->incr( $key ); }
		if( $type == 'decr' ){ $this->decr( $key ); }

		return $this;
	}


	public function close()
	{
		parent::close();
	}


	public function replaceKey($key, $new_key)
	{
		$value = $this->get( $key );
		$this->delete( $key );
		$this->set( $new_key, $value );

		return $this;
	}

	public function get( $key )
	{
		return $this->get( $key );
	}


	public function getArray( $key )
	{
		$this->hgetAll( $key );
	}


	public function has( $element )
	{
		return $this->checkExists( $element ) ? true : false;
	}


	public function remove( $key )
	{
		$this->delete( $key );
		return true;
	}


	public function removeArray( $key, $item = '' )
	{
		$this->hDel( $key, $item );
		return true;
	}


	public function clearAll()
	{
		$this->flushAll();
	}


	public function setArray( $key, array $items )
	{
		$this->hmset( $key, $items );
		return true;
	}


	public function __destruct()
	{
		$this->close();
	}

}