<?php

namespace BlokBundle\Cache;

use BlokBundle\Cache\CacheInterface;


class MongoCache implements CacheInterface
{

	private $redis;


	private function checkExists( $key )
	{
		return $this->redis->exists( $key );
	}


	public function __construct( $connect_data )
	{
		$this->redis = new \Redis;
		$this->redis->connect( $connect_data['host'], $connect_data['port'] );
	}


	public function get( $key )
	{
		return $this->redis->get( $key );
	}


	public function getArray( $key )
	{
		$this->redis->hgetAll( $key );
	}


	public function has( $element )
	{
		return $this->checkExists( $element ) ? true : false;
	}


	public function remove( $key )
	{
		$this->redis->delete( $key );
		return true;
	}


	public function removeArray( $key, $item = '' )
	{
		$this->redis->hDel( $key, $item );
		return true;
	}


	public function clearAll()
	{
		$this->redis->flushAll();
	}


	public function set($key, $item )
	{
		$this->redis->hmset( $key, $item );
	}


	public function setArray( $key, array $items )
	{
		$this->redis->hmset( $key, $items );
		return true;
	}


	public function __destruct()
	{
		$this->mem->close();
	}

}