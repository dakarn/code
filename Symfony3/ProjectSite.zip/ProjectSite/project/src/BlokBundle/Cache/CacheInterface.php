<?php

namespace BlokBundle\Cache;

interface CacheInterface {


	public function __construct( $connect_data );

	public function has( $element );

	public function remove( $key );

	public function replaceKey( $key, $new_key );

	public function close();

	public function count();

	public function counter( $type, $key, $count = 1);

}