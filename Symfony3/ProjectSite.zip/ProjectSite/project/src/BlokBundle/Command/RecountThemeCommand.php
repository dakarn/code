<?php

namespace BlokBundle\Command;

use BlokBundle\Cache\FileSystemCache;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;


class RecountThemeCommand extends ContainerAwareCommand {


	private $pop_time = 3600*24;

	protected function configure()
	{

		$this->setName( 'recount-theme-and-post' );
	}


	private function reCount($doct)
	{

		$cache = new FileSystemCache('guest');

		$count = $doct->createQuery( 'SELECT SUM(f.countPosts) FROM BlokBundle:Forum f' );
		$cache->set('count_post', $count);

		$count = $doct->createQuery( 'SELECT SUM(f.countTheme) FROM BlokBundle:Forum f' );
		$cache->set('count_theme', $count);

		$count = $doct->createQuery( 'SELECT COUNT(f.id) FROM BlokBundle:Forum f WHERE f.parentId > 0' );
		$cache->set('count_forum', $count);

		$best = $doct->createQuery( 'SELECT f.id, f.countTheme, f.countPosts, f.title 
			FROM BlokBundle:Forum f ORDER BY f.countPosts DESC' )->setMaxResults( 1 )->getOneOrNullResult();
		$cache->set('best_forum', $best);


		$query = $doct->createQuery( 'SELECT p.themeId, COUNT(p.themeId) AS cnt
			FROM BlokBundle:Post p WHERE p.createdAt > :pop_time 
			GROUP BY p.themeId ORDER BY cnt DESC' )
			->setParameter( 'pop_time', time()-$this->pop_time )->setMaxResults( 1 )->getOneOrNullResult();

		$popular_theme = $doct->createQuery( 'SELECT t.title, t.id, t.countPost, t.forumId
			FROM BlokBundle:Theme t WHERE t.id = '.$query['themeId'].'' )->setMaxResults( 1 )->getOneOrNullResult();
		$cache->set('populat_theme', $popular_theme )->flush();

	}
	
	protected function execute( InputInterface $input, OutputInterface $output )
	{

		$doct = $this->getContainer()->get('doctrine')->getManager();
		$this->reCount($doct);
	}


}
