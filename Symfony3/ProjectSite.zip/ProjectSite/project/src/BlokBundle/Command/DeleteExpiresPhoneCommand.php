<?php

namespace BlokBundle\Command;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;


class DeleteExpiresPhoneCommand extends ContainerAwareCommand {



	protected function configure()
	{
		$this->setName( 'delete-phone-expired' );
	}


	protected function execute( InputInterface $input, OutputInterface $output )
	{

		$em = $this->getContainer()->get('doctrine')->getManager();

		$query = $em->createQuery( 'DELETE BlokBundle:Telephone tel WHERE tel.payment = :payment' )
			->setParameter( 'payment', 0 );
		$query->execute();

	}


}