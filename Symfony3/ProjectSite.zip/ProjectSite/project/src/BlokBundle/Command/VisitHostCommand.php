<?php

namespace BlokBundle\Command;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;


class VisitHostCommand extends ContainerAwareCommand {



	protected function configure()
	{

		$this->setName( 'visit-host-history' );
	}


	protected function execute( InputInterface $input, OutputInterface $output )
	{

		$em = $this->getContainer()->get('doctrine')->getConnection();

		$query = $em->prepare( 'INSERT INTO visit_host_history SELECT * FROM visit_host' );
		$query->execute();

		$query = $em->prepare( 'TRUNCATE TABLE visit_host' );
		$query->execute();

	}


}
