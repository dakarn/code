<?php

namespace BlokBundle\Command;

use BlokBundle\Cache\FileSystemCache;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Symfony\Bundle\FrameworkBundle\Command\ContainerAwareCommand;


class RecountOnineCommand extends ContainerAwareCommand {



	protected function configure()
	{

		$this->setName( 'recount-online' );
	}


	protected function execute( InputInterface $input, OutputInterface $output )
	{

		$cache = new FileSystemCache();
		$doct = $this->getContainer()->get('doctrine')->getManager();
		$time = time() - 300;

		$count = $doct->createQuery( 'SELECT COUNT(vh.id) FROM BLOKBundle:VisitHost vh 
		WHERE vh.visitTime > :time' )->setParameter( 'time', $time )->getSingleScalarResult();

		$cache->set('count_online', $count )->flush();

	}


}
