<?php

namespace BlokBundle\Controller;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\FormBuild\CommentNews;
use BlokBundle\Entity\FormValidator\CommentNewsValidator;
use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\ErrorsForm;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;


class NewsController extends Controller {


	private $errors = [ 'Такой новости не найдено.' ];
	private $result = [ 'Комментарии добавлен!' ];

	private function getCacheCount( FileSystemCache $cache, $doct )
	{

		if( !$count = $cache->get( 'news_count' ) )
		{
			$count = $doct->createQuery('SELECT COUNT(n.id) FROM BlokBundle:News n')->getSingleScalarResult();
			$cache->set( 'news_count', $count )->flush();
		}

		return (int)$count;
	}

	public function indexAction( Request $request, $page = 1 )
	{

		$doct = $this->getDoctrine()->getManager();
		$news_repos = $doct->getRepository( 'BlokBundle:News' );

		$count = $this->getCacheCount( new FileSystemCache( 'guest' ), $doct );
		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( $this->generateUrl( 'blok_news' ) )->countOnPage($this->get('options')->news_on_page);

		$list_news = $paginate->setData( $news_repos, [], ['createdAt' => 'ASC'], $page );

		return $this->render('BlokBundle:Blok:news\index.html.twig', [ 'paginate' => $paginate, 'list_news' => $list_news ]  );
	}


	public function sidebarAction( Request $request )
	{

		$repos = $this->getDoctrine()->getManager();
		$list_news = $repos->getRepository( 'BlokBundle:News' )->findBy( [], [ 'createdAt' => 'ASC' ], 2, 0 );

		return $this->render('BlokBundle:Blok:news\sidebar.html.twig', [ 'list_news' => $list_news ] );
	}


	public function commentNewsAction( Request $request, $news_id )
	{

		if( ($text = BanExist::isBan(4, 0 )) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_news' );
		}

		$form = $this->createForm( CommentNews::class, new CommentNewsValidator() );
		$form->handleRequest( $request );

		if( $request->isMethod( 'POST' ) )
		{

			$doct = $this->getDoctrine()->getManager();
			$news_repos = $doct->getRepository( 'BlokBundle:News' );

			$result = $news_repos->addCommentNews( $doct, $this->getUser(), $form, $news_id );

			if( $result !== true )
			{
				$this->get('notice')->add('danger', ErrorsForm::get( $result ) );

			} else {

				$this->get('notice')->add('success', $this->result[0]);
			}

		}

		return $this->redirectToRoute( 'blok_news_item', [ 'news_id' => $news_id ] );
	}


	public function newsItemAction( Request $request, $news_id )
	{

		$doct = $this->getDoctrine()->getManager();
		$news_repos = $doct->getRepository( 'BlokBundle:News' );
		$news = $news_repos->findOneBy( [ 'id' => $news_id ] );

		if( $news === null )
		{
			return Flash::exec( $this->container,'d', $this->errors[0], 'blok_news' );
		}

		$form = $this->createForm( CommentNews::class );
		$news_repos->addViews( $doct, $news );

		return $this->render('BlokBundle:Blok:news\news_item.html.twig', [ 'form' => $form->createView(), 'news' => $news ]  );
	}


	public function ajaxGetCommentsAction( Request $request )
	{


		if( !$request->isXmlHttpRequest() )
		{
			return new JsonResponse( json_encode( [ 'success' => false ] ), 200, [], true );
		}

		if( ($text = BanExist::isBan(6, 8 )) !== false )
		{
			return new JsonResponse( json_encode( [ 'success' => false, 'text' => $text ] ), 200, [], true );
		}

		$resultJson = [];

		$doct = $this->getDoctrine()->getManager();
		$result = $doct->getRepository( 'BlokBundle:Comments' )->findBy( [ 'type' => 'news' ] );

		foreach( $result as $key => $value )
		{

			$resultJson[] = [ 'id' => $value->getId(), 'userId' => $value->getUserId(), 'text' => $value->getText(),
				'created' => date( $this->get('options')->date_format,  $value->getCreatedAt() ) ];
		}

		return new JsonResponse( json_encode( [ 'success' => true, 'list' => $resultJson ] ), 200, [], true );

	}

}
