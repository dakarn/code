<?

namespace BlokBundle\Controller;

use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;
use BlokBundle\Entity\FormBuild\Login;


class LoginController extends Controller {


	private $role = ['ROLE_USER'];


	public function loginAction( Request $request )
	{

		if( $this->isGranted( 'ROLE_USER', $this->getUser() ) )
		{
			return $this->redirectToRoute('blok_index');
		}

		$form = $this->createForm( Login::class );

		$authenticationUtils = $this->get('security.authentication_utils');
		$error = $authenticationUtils->getLastAuthenticationError();
		$lastUsername = $authenticationUtils->getLastUsername();

		return $this->render('BlokBundle:Blok:login.html.twig', [
			'form' => $form->createView(), 'error' => $error, 'last_username' => $lastUsername ] );

	}

	public function logoutAction( Request $request )
	{
		return $this->redirectToRoute('blok_index');
	}


	private function sendRecoveryMail( $result, $mail )
	{

		$doct = $this->getDoctrine()->getManager();
		$password = $this->get( 'generate' )->generatePassword( 10 );

		$result->setPassword( password_hash( $password, PASSWORD_BCRYPT ) );
		$doct->flush();

		return $this->get( 'email-notice' )->EmailRecovery( $result, $mail, $password );
	}


	public function recoveryAction( Request $request)
	{

		if( $this->isGranted( 'ROLE_USER', $this->getUser() ) )
		{
			return $this->redirectToRoute('blok_index');
		}

		$errors = [];
		$success = false;

		if( $request->isMethod( 'POST' ) )
		{
			try
			{

				if ( empty( $_POST['email'] ) )
				{
					$errors[] = 'Поле с E-mail оставлено пустым.';
					throw new Exception('');
				}

				if( !filter_var( $_POST['email'], FILTER_VALIDATE_EMAIL ) )
				{
					$errors[] = 'E-mail введен не правильно.';
					throw new Exception('');
				}

				if( !$this->isCsrfTokenValid( 'authenticate', $_POST['_csrf_token'] ) )
				{
					$errors[] = 'Ошибка при выполнений операции.';
					throw new Exception('');
				}

				$result = $this->getDoctrine()->getRepository( 'BlokBundle:User' )
					->findOneByEmail( $_POST['email'] );

				if( null == $result )
				{
					$errors[] = 'Такой E-mail не найден в системе. Провельте правлиьность ввода e-mail.';
					throw new Exception('');
				}

				$success = true;
				$this->sendRecoveryMail( $result, $_POST['email'] );

			} catch( Exception $e )
			{
				return $this->render('BlokBundle:Blok:recovery.html.twig', [ 'success' => $success, 'errors' => $errors ] );
			}
		}

		return $this->render('BlokBundle:Blok:recovery.html.twig', [ 'success' => $success, 'errors' => $errors ] );

	}


	public function activationAction()
	{

		$errors = [];

		if( isset( $_GET['token'] ) && is_numeric( $_GET['token'] ) )
		{

			$token = $_GET['token'];

			$em = $this->getDoctrine()->getManager();
			$result = $em->getRepository( 'BlokBundle:User' )
				->findOneBy( [ 'activation_key' => $token ] );

			if( isset( $result->activation_key ) ){

				$result->setIsActive( 1 );
				$result->setActivationKey( '' );
				$em->flush();

			} else {

				$errors[] = 'Ваш код активациии не верен. Проверьте правильность кода.';
				$errors[] = 'Возможно ваш код устарел.<br>Обратитесь к администрации сайта для решения проблемы.';
			}

		} else {

			$errors[] = 'Не верно введен адрес для активации аккуанта.';
		}

		return $this->render('BlokBundle:Blok:activation.html.twig', [ 'errors' => $errors ] );
	}
}