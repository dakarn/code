<?php

namespace BlokBundle\Controller;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\ErrorsForm;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use BlokBundle\Entity\FormBuild\Guest;
use BlokBundle\Entity\FormValidator\GuestValidator;


class GuestController extends Controller
{

	private $result = [
		'Сообщение успешно добавлено!',
	];

	private $errors = [
		'Гостевая книга выключена, вы не может в нее писать.',
	];

	private function getCacheCount( FileSystemCache $cache, $doct )
	{

		if( !$count = $cache->get( 'guest_count' ) )
		{
			$count = $doct->createQuery('SELECT COUNT(g.id) FROM BlokBundle:Guestbook g')->getSingleScalarResult();
			$cache->set( 'guest_count', $count )->flush();
		}

		return (int)$count;
	}

	public function indexAction(Request $request,  $page = 1 )
	{

		$form = $this->createForm( Guest::class, null, [ 'action' => $this->generateUrl('blok_guestbook_add')] );
		$doct = $this->getDoctrine()->getManager();
		$guest_repos = $doct->getRepository( 'BlokBundle:GuestBook' );

		$count = $this->getCacheCount( new FileSystemCache( 'guest' ), $doct );

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( '/guestbook/' )->countOnPage( $this->get( 'options' )->guest_on_page );

		$guests = $paginate->setPrepare( $this->getDoctrine(), $guest_repos->GuestJoinUser(), $page );

		return $this->render('BlokBundle:Blok:guest/index.html.twig',
								[ 'form' => $form->createView(), 'paginate' => $paginate, 'list_guest' => $guests ] );
	}


	public function addAction( Request $request )
	{

		$options = $this->get( 'options' )->key( 'enable_guest' );

		if( $options == 'off' )
		{
			$this->get('notice')->add( 'danger', $this->errors[0] );
			return $this->redirectToRoute( 'blok_guestbook' );
		}

		if( ($text = BanExist::isBan(3, 0 )) !== false )
		{
			$this->get('notice')->add( 'danger', $text );
			return $this->redirectToRoute( 'blok_guestbook' );
		}

		$form = $this->createForm( Guest::class, new GuestValidator() );
		$form->handleRequest($request);

		if( $request->isMethod( 'POST' ) && $form->isValid() )
		{

			$doct = $this->getDoctrine()->getManager();
			$repos = $doct->getRepository( 'BlokBundle:Guestbook' )->addMessage( $doct, $this->isGranted('ROLE_USER'), $form, $this->getUser() );

			$this->get('notice')->add( 'success', $this->result[0] );
			return $this->redirectToRoute( 'blok_guestbook' );

		}

		$this->get('notice')->add( 'danger', ErrorsForm::get( $form->getErrors( true ) ) );
		return $this->redirectToRoute( 'blok_guestbook' );
	}

}
