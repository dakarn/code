<?php

namespace BlokBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;


class VoteController extends Controller {


	private $role = ['ROLE_USER'];
	private $result = ['<span style="color: green;"><b>Спасибо! Ваш голос учтен!</b></span>'];
	private $errors = ['<span style="color: red;"><b>Ошибка! Не удалось сделать опрос!</b></span>',
					   '<span style="color: red;"><b>Ошибка! Вы уже участвовали в этом опросе!</b></span>'];


	private function jsonError( $num = 0 )
	{
		return new JsonResponse( json_encode( ['success' => false, 'text' => $this->errors[$num] ] ), 200, [], true );
	}

	public function ajaxAddVoteAction( Request $request )
	{

		if( !$this->isGranted( $this->role[0] ) ) { return $this->jsonError(); }

		if( !isset( $_POST['vote_id'] ) || !isset( $_POST['theme_id'] ) ){ return $this->jsonError(); }

		if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']) ){ return $this->jsonError(); }

		$doct = $this->getDoctrine()->getManager();
		$vote_repos = $doct->getRepository('BlokBundle:ThemeVote');

		if( ( $res = $vote_repos->addVoteTheme( $doct, $this->getUser()->getId() )) !== true )
		{
			return $this->jsonError( $res );
		}

		return new JsonResponse( json_encode( [ 'success'=>true, 'text' => $this->result[0] ] ), 200, [], true );

	}

}