<?php

namespace BlokBundle\Controller\Api\Options\Format;

class XML {

}