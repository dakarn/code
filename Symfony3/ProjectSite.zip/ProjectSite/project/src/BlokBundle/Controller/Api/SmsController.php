<?

namespace BlokBundle\Controller\Api;

use BlokBundle\Entity\FormValidator\SendSMSValidator;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;
use BlokBundle\Controller\Api\Options\AnswerApi;


class SmsController extends Controller
{

	private $answer_api;
	private $error = [ 'Не заполнены нужные данные POST запроса.', 'Возникла проблема при отправке.'  ];
	private $errpr_code = [10, 11];
	private $result = [
		'Ваше сообщение успешно отправлено!',
	];

	public function Answer()
	{
		if( $this->answer_api == null )
		{
			$this->answer_api = new AnswerApi( $this->get('options')->all() );
		}

		return $this->answer_api;
	}


	public function sendAction( Request $request )
	{

		if( ( $access = $this->get('access_control')->access_control_key( __METHOD__, ['sms','full'] ) ) !== true ){ return $access; }

		try
		{
			$valid = new SendSMSValidator(); $valid->setData();
			$validation = $this->get( 'validator' );
			$errors = [];//$validation->validate( $valid );

			if( count( $errors ) > 0 )
			{
				throw new Exception( $this->error[0], $this->errpr_code[0] );
			}

			$doct = $this->getDoctrine()->getConnection();

			$query = $doct->prepare( 'SELECT k.*, kp.* FROM keys_access k JOIN keys_property kp
				WHERE k.key_code = :code AND kp.id = k.id' );

			$query->execute(['code'=>$_GET['keyCode']]);
			$result = $query->fetch(5);

			$prop = unserialize( $result->property );
			$prop['curr_sms'] = (int)$prop['curr_sms'] + 1;

			$doct->prepare( 'UPDATE keys_property
			SET property = :prop WHERE id = '.$result->id )->execute(['prop' => serialize( $prop ) ]);

			$this->Answer()->add( ['success' => true ] );
			$this->Answer()->add( ['text' => $this->result[0] ] );
			return $this->Answer()->send();

		} catch( Exception $e ) {

			$this->Answer()->add( ['success' => false ] );
			$this->Answer()->add( [ 'error' => $e->getMessage() ] );
			$this->Answer()->add( [ 'errorCode' => $e->getCode() ] );

			return $this->Answer()->send();
		}

	}


	public function faqAction( Request $request )
	{

		if( ( $access = $this->get('access_control')->assess_control_key( __METHOD__, ['full','sms'] ) ) !== true ){ return $access; }

		try
		{
			$this->Answer()->add( ['success' => true ] );
			return $this->Answer()->send();

		} catch( Exception $e ) {

			$this->Answer()->add( ['success' => false ] );
			$this->Answer()->add( [ 'error' => $e->getMessage() ] );

			return $this->Answer()->send();
		}

	}

}


