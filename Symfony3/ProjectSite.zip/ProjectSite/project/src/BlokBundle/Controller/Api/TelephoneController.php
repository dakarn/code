<?

namespace BlokBundle\Controller\Api;

use BlokBundle\Entity\FormValidator\SendSMSValidator;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;
use BlokBundle\Controller\Api\Options\AnswerApi;


class TelephoneController extends Controller
{

	private $answer_api;
	private $error = [ 'Вы не указали номер телефона', 'Не правильно указан номер.', 'Возникла проблема при отправке.'  ];
	private $errpr_code = [ 12, 13, 14 ];
	private $result = [
		'Идет соединение с номером!',
		'Разговор завершен!',
	];

	public function Answer()
	{
		if( $this->answer_api == null )
		{
			$this->answer_api = new AnswerApi( $this->get('options')->all() );
		}

		return $this->answer_api;
	}


	public function putPhoneAction( Request $request )
	{

		if( ( $access = $this->get('access_control')->access_control_key( __METHOD__, ['telephone','full'] ) ) !== true ){ return $access; }

		try
		{
			$this->Answer()->add( ['success' => true ] );
			$this->Answer()->add( ['text' => $this->result[1] ] );
			return $this->Answer()->send();

		} catch( Exception $e ) {

			$this->Answer()->add( ['success' => false ] );
			$this->Answer()->add( [ 'error' => $e->getMessage() ] );
			$this->Answer()->add( [ 'errorCode' => $e->getCode() ] );

			return $this->Answer()->send();
		}
	}


	public function callAction( Request $request )
	{

		if( ( $access = $this->get('access_control')->access_control_key( __METHOD__, ['telephone','full'] ) ) !== true ){ return $access; }

		try
		{

			if( empty( $_POST['number'] ) )
			{
				throw new Exception( $this->error[0], $this->errpr_code[0] );
			}

			if( !preg_match( '/^8[0-9]{3}[0-9]{3}[0-9]{4}$/', $_POST['number'] ) )
			{
				throw new Exception($this->error[1], $this->error_code[1] );
			}

			$this->Answer()->add( ['success' => true ] );
			$this->Answer()->add( ['text' => $this->result[0] ] );
			return $this->Answer()->send();

		} catch( Exception $e ) {

			$this->Answer()->add( ['success' => false ] );
			$this->Answer()->add( [ 'error' => $e->getMessage() ] );
			$this->Answer()->add( [ 'errorCode' => $e->getCode() ] );

			return $this->Answer()->send();
		}

	}


	public function faqAction( Request $request )
	{

		if( ( $access = $this->get('access_control')->assess_control_key( __METHOD__, ['full','telephone'] ) ) !== true ){ return $access; }

		try
		{
			$this->Answer()->add( ['success' => true ] );
			return $this->Answer()->send();

		} catch( Exception $e ) {

			$this->Answer()->add( ['success' => false ] );
			$this->Answer()->add( [ 'error' => $e->getMessage() ] );

			return $this->Answer()->send();
		}

	}

}


