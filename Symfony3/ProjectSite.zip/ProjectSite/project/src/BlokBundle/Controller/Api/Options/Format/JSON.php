<?php

namespace BlokBundle\Controller\Api\Options\Format;

use BlokBundle\Controller\Api\Options\AnswerApiInterface;

class JSON implements \BlokBundle\Controller\Api\Options\Format\ApiFormatInterface {


	public function parse()
	{

	}

}