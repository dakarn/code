<?php

namespace BlokBundle\Controller\Api\Options;

use BlokBundle\Controller\Api\Options\Format\ApiFormatInterface;
use BlokBundle\Controller\Api\Options\Format\JSON;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;


interface AnswerApiInterface {

	public  function  add( array $text );
	public  function  get();
	public  function  edit( $item, $text );
	public  function  clear();
	public  function  send( $code );
	public  function  getItem( $key );
}

class AnswerApi implements AnswerApiInterface {


	private $sendArray = [];
	private $is_json = true;
	private $error = [ 'Возникла ошибка при запросе API.' ];
	private $error_code = [ 'Код ошибки: 300' ];
	private $sc;
	private $options;
	private $format;


	public function __construct( $options )
	{
		$this->options = $options;
	}

	private function enable_options()
	{
		$enable_api = $this->options['enable_api'];

		if( $enable_api != 1 ){ return false; }

		return true;
	}

	public function add( array $text )
	{
		$this->sendArray[] = $text;
		return $this;
	}

	public function edit( $item, $text )
	{
		$this->sendArray[ $item ] = $text;
	}

	public function get()
	{
		return $this->sendArray;
	}

	public function getItem( $key )
	{
		return $this->sendArray[$key];
	}

	public function  clear()
	{
		$this->sendArray = [];
	}

	public function send( $code = 200 )
	{

		/*if( !$this->enable_options() )
		{
			$this->clear();
			$this->add( [ 'success' => false ] )
			     ->add( [ 'error' => $this->error[0] ] )
				 ->add( [ 'error_code' => $this->error_code[0] ] );

			//return new JsonResponse( json_encode( $this->sendArray ), $code, [], true );
		}*/

		return new JsonResponse( json_encode( $this->sendArray ), $code, [], true );
	}



}