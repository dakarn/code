<?

namespace BlokBundle\Controller\Api;

use BlokBundle\Controller\Api\Options\AnswerApi;
use BlokBundle\Controller\Api\Options\Format\JSON;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use BlokBundle\Entity\GuestBook;
use Symfony\Component\Validator\Validation;
use Symfony\Component\Validator\Constraints\Length;
use Symfony\Component\Validator\Constraints\NotBlank;


class GuestController extends Controller
{

	private $sendArray;
	private $fieldsUser = 'g.id, g.username, g.message, g.user_id, g.created_at, g.updated_at';
	private $model = 'BlokBundle:GuestBook g';
	private $limit = 10;
	private $offset = 0;
	private $answer_api;
	private $error = [ 'Такого сообщения не найдено.', 'Не правильно заполнены данные POST запроса'  ];
	private $errpr_code = ['Код ошибки: 1', 'Код ошибки: 2', 'Код ошибки: 3'];


	public function Answer()
	{
		if( $this->answer_api == null )
		{
			$this->answer_api = new AnswerApi( $this->get('options')->all() );
		}

		return $this->answer_api;
	}

	private function getValidation()
	{
		$validator = Validation::createValidator();
		$errors[0] = $validator->validate( $_POST['username'], [ new NotBlank() ] );
		$errors[1] = $validator->validate( $_POST['message'], [ new Length(['min' => 2] ), new NotBlank() ] );

		return $errors;
	}




	public function getAction( Request $request, $id )
	{

		if( ( $access = $this->get('access_control')->access_control_key( __METHOD__, ['api','full'] ) ) !== true ){ return $access; }

		try {

			if( $id <= 0 )
			{
				throw new Exception( 0 );
			}

			$guest = $this->getDoctrine()->getManager()
				->createQuery( 'SELECT '.$this->fieldsUser.' FROM '.$this->model.' WHERE g.id='.$id )
				->setMaxResults( 1 )
				->getOneOrNullResult();


			$this->Answer()->add( ['success' => true, 'guest' => $guest ] );

			return $this->Answer()->send();

		} catch( Exception $e ) {

			$this->Answer()->add( ['success' => false ] )
						   ->add( [ 'error' => $this->error[$e->getMessage()] ] )
						   ->add( [ 'error_code' => $this->error_code[$e->getMessage()] ] );

			return $this->Answer()->send();
		}

	}


	public function getallAction( Request $request )
	{

		if( ( $access = $this->get('access_control')->access_control_key( __METHOD__, ['full','api'] ) ) !== true ){ return $access; }

		$limit = $request->query->get('limit');
		$offset = $request->query->get('offset');

		if( !is_numeric( $limit ) )
		{
			$limit = $this->limit;
		}

		if( !is_numeric( $offset ) )
		{
			$offset = $this->offset;
		}

		$em = $this->getDoctrine()->getManager();

		$list_guests[] = $em->createQuery( 'SELECT '.$this->fieldsUser.' FROM '.$this->model.' ORDER BY g.id ASC' )
			->setMaxResults( $limit )
			->setFirstResult( $offset )->getResult();

		$this->Answer()->add( ['success' => true, 'list_guests' => $list_guests ] );

		return $this->Answer()->send();
	}


	public function createAction( Request $request )
	{

		if( ( $access = $this->get('access_control')->access_control_key( __METHOD__, ['api','full'] ) ) !== true ){ return $access; }

		try {

			$errors = $this->getValidation();

			if ( count( $errors[0] ) > 0 || count( $errors[1] ) > 0 )
			{
				throw new Exception( 1 );
			}

			$user_id = 10;
			$guest = new GuestBook();

			$guest->setUserID( $user_id );
			$guest->setCreatedAt( time() );
			$guest->setUpdatedAt( time() );
			$guest->setMessage( $request->request->get('message') );
			$guest->setUsername( $request->request->get('username') );

			$doc = $this->getDoctrine()->getManager();
			$doc->persist( $guest );
			$doc->flush();

			$this->Answer()->add( ['success' => true,
								   'text' => 'The message was added successfully in guestbook!' ] );

			return $this->Answer()->send();


		} catch( Exception $e )
		{
			$this->Answer()->add( ['success' => false ] )
				->add( [ 'error' => $this->error[$e->getMessage()] ] )
				->add( [ 'error_code' => $this->error_code[$e->getMessage()] ] );

			return $this->Answer()->send();
		}
	}

}