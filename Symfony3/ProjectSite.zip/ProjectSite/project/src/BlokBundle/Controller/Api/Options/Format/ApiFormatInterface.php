<?php

namespace BlokBundle\Controller\Api\Options\Format;


interface ApiFormatInterface {


	public function parse();

}