<?

namespace BlokBundle\Controller\Api;

use BlokBundle\Service\Generate;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use BlokBundle\Controller\Api\Options\AnswerApi;


class UsersController extends Controller
{

	private $fieldsUser = 'u.id, u.username, u.email, u.gender, u.age, u.created_at AS date_registration, u.is_active';
	private $model = 'BlokBundle:User u';
	private $limit = 50;
	private $offset = 0;
	private $answer_api;
	private $errors = [
		'У вас нет доступа к API, так как у вас нет подходящего для этого ключа.',
		'The User with ID %d not found in system.',
	];

	public function Answer()
	{
		if( $this->answer_api == null )
		{
			$this->answer_api = new AnswerApi( $this->get('options')->all() );
		}

		return $this->answer_api;
	}


	public function getAction( $id )
	{

		if( ( $access = $this->get('access_control')->access_control_key( __METHOD__, ['api','full'] ) ) !== true ){ return $access; }

		try {


			$doct = $this->getDoctrine()->getManager();
			$result = $doct->getRepository( 'BlokBundle:KeysAccess' )->findOneBy( [ 'userId' => $this->getUser()->getId(), 'keyType' => ['full','api'] ] );

			if( null === $result )
			{
				throw new Exception( $this->errors[0] );
			}

			$list_user = $doct->createQuery( 'SELECT '.$this->fieldsUser.' FROM '.$this->model.' WHERE u.id='.$id )
				->setMaxResults( 1 )
				->getOneOrNullResult();

			if( $list_user == null )
			{
				throw new Exception( sprintf( $this->errors[1], $id ) );
			}

			$this->Answer()->add( ['success' => true ] );
			$this->Answer()->add( [ 'user' => [ $list_user ] ] );

			return $this->Answer()->send();

		} catch( Exception $e ) {

			$this->Answer()->add( ['success' => false ] );
			$this->Answer()->add( [ 'error' => $e->getMessage() ] );

			return $this->Answer()->send();
		}

	}


	public function getallAction( Request $request )
	{

		if( ( $access = $this->get('access_control')->access_control_key( __METHOD__, ['full','api'] ) ) !== true ){ return $access; }

		$em = $this->getDoctrine()->getManager();
		$result = $em->getRepository( 'BlokBundle:KeysAccess' )->findOneBy( [ 'userId' => $this->getUser()->getId(), 'keyType' => ['full','api'] ] );

		if( null === $result )
		{
			throw new Exception( $this->errors[0] );
		}

		$limit = $request->query->get('limit');
		$offset = $request->query->get('offset');

		if( !is_numeric( $limit ) )
		{
			$limit = $this->limit;
		}

		if( !is_numeric( $offset ) )
		{
			$offset = $this->offset;
		}



		$list_users = $em->createQuery( 'SELECT '.$this->fieldsUser.' FROM '.$this->model.' ORDER BY u.id ASC' )
			->setMaxResults( $limit )
			->setFirstResult( $offset )->getResult();

		$this->Answer()->add( ['success' => true ] );
		$this->Answer()->add( [ 'users' => [ $list_users ] ] );

		return $this->Answer()->send();

	}

}


