<?php

namespace BlokBundle\Controller\Forum;

use BlokBundle\Entity\FormBuild\Theme;
use BlokBundle\Entity\FormValidator\ThemeValidator;
use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\CheckPrivInRole;
use BlokBundle\Helper\ErrorsForm;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class ThemeController extends Controller
{

	private $result = [ 'Тема добавлена в форум!', 'Тема была изменена!', ];
	private $role = ['ROLE_USER','ROLE_MODER_FORUM'];
	private $role_priv = ['forum:edit'];
	private $errors = [ 'Такая тема не существует.', 'Такого форума не саществует.', 'В этом форуме нельзя создавать темы.',
						'Вы не можете создавать темы.', 'У вас нет прав для этого действия.' ];


	private function countFullVote( $votes )
	{
		$count = 0;

		foreach( $votes as $vote ) { $count += $vote->getCountVote(); }

		return $count+1;
	}

	public function createAction( Request $request, $forumid )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Forum' );
		$repos_theme = $doct->getRepository( 'BlokBundle:Theme' );
		$forum = $repos->findOneById( $forumid );

		if( !$this->isGranted( $this->role[0] ) )
		{
			return Flash::exec( $this->container,'d', $this->errors[3],'blok_forum_sub', [ 'id' => $forumid ] );
		}

		if( $forum === null ) { return Flash::exec( $this->container,'d', $this->errors[1],'blok_forum' ); }

		if( ($text = BanExist::isBan(4, 2 )) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_forum_sub', [ 'id' => $forum->getId() ] );
		}

		if( $forum->getParentId() === 0 ) { return Flash::exec( $this->container,'d', $this->errors[2],'blok_forum' ); }

		$form = $this->createForm( Theme::class, new ThemeValidator() );
		$form->handleRequest($request);

		if( $request->isMethod( 'POST' ) )
		{
			$result = $repos_theme->addTheme( $this->container, $doct, $form, $this->getUser(), $forumid, $forum );

			if( $result !== true )
			{
				return Flash::exec( $this->container,'d', $result,'blok_forum_sub', [ 'id'=>$forumid ] );
			}

			return Flash::exec( $this->container,'s', $this->result[0], 'blok_forum_sub', [ 'id'=>$forumid ] );

		}

		return $this->render('BlokBundle:Blok:forum\create-theme.html.twig', [ 'forum' => $forum, 'form' => $form->createView() ] );

	}

	public function indexAction( Request $request, $forumid, $id, $page = 1 )
	{

		$doct = $this->getDoctrine()->getManager();
		$theme_repos = $doct->getRepository( 'BlokBundle:Theme' );
		$theme = $theme_repos->ThemeJoinUser( $id );
		$forum = $doct->getRepository( 'BlokBundle:Forum' )->findOneBy( [ 'id' => $forumid ] );

		if( ($theme === null || $forum === null) || $forum->getId() != $theme['forum_id'] )
		{
			return Flash::exec( $this->container,'d', $this->errors[0],'blok_forum_sub', [ 'id'=>$forumid ] );
		}

		$follow = $doct->getRepository( 'BlokBundle:ThemeFollow' )
			->findOneBy( [ 'userId' => $this->getUser()->getId(),'themeId' => $theme['tid'] ] );
		$post_repos = $doct->getRepository( 'BlokBundle:Post' );

		$vote = $doct->getRepository( 'BlokBundle:ThemeVote' )->findBy( [ 'themeId' => $theme['tid'] ] );

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $theme['count_post'] )->setUrl( '/forum/'.$forumid.'/'.$theme['tid'].'/' )->countOnPage( $this->get('options')->count_post_on_page );

		$list_post = $paginate->setPrepare( $this->getDoctrine(), $post_repos->PostsJoinUser( $id ), $page );


		$theme_repos->addViews( $doct, $id );

		return $this->render('BlokBundle:Blok:forum\theme.html.twig',
		[ 'vote' => $vote, 'follow' => $follow, 'theme' => $theme, 'forum' => $forum,
		  'list_post' => $list_post, 'paginate' => $paginate, 'full_vote' => $this->countFullVote( $vote ) ] );

	}

	public function editThemeAction( Request $request, $theme_id )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos_theme = $doct->getRepository( 'BlokBundle:Theme' );
		$theme = $repos_theme->findOneById( $theme_id );

		if( $theme === null ) { return Flash::exec( $this->container,'d', $this->errors[0],'blok_forum' ); }

		$redirect = [ 'forumid' => $theme->getForumId(),  'id' => $theme->getId() ];
		$legal = CheckPrivInRole::legal( $this->container, $this->role[1],true, $this->role_priv[0], true );


		if( !$legal &&
		$theme->getCreatedAt() < time() - $this->get('options')->time_edit_theme &&
		$this->getUser()->getId() == $theme->getUserId() )
		{
			return Flash::exec( $this->container,'d', $this->errors[4],'blok_forum_theme', $redirect );
		}


		$form = $this->createForm( Theme::class, new ThemeValidator() );
		$form->handleRequest($request);

		if( $request->isMethod( 'POST' ) )
		{
			$result = $repos_theme->editTheme( $this->container, $doct, $form, $theme );

			if( $result !== true )
			{
				return Flash::exec( $this->container,'d', $result,'blok_forum_theme', $redirect );
			}

			return Flash::exec( $this->container,'s', $this->result[1],'blok_forum_theme', $redirect );

		}

		return $this->render('BlokBundle:Blok:forum\edit-theme.html.twig', [ 'theme' => $theme, 'form' => $form->createView() ] );

	}

	public function complainThemeAction( Request $request, $theme_id )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos_theme = $doct->getRepository( 'BlokBundle:Theme' );
		$theme = $repos_theme->findOneById( $theme_id );

		if( $theme === null ) { return Flash::exec( $this->container,'d', $this->errors[0],'blok_forum' ); }

		$redirect = [ 'forumid' => $theme->getForumId(),  'id' => $theme->getId() ];

		if( ($text = BanExist::isBan(4, 7 )) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_forum_theme', $redirect );
		}

		if( !$this->isGranted( $this->role[0] ) )
		{
			return Flash::exec( $this->container,'d', $this->errors[4],'blok_forum_theme', $redirect );
		}

		if( $request->isMethod( 'POST' ) )
		{

			if( ($result = $repos_theme->complainTheme( $doct, $theme, $theme_id )) !== true )
			{
				return Flash::exec( $this->container,'d', $result,'blok_forum_theme' );
			}

			return Flash::exec( $this->container,'s', $this->result[1],'blok_forum_theme' );

		}

		return $this->render('BlokBundle:Blok:forum\complain-theme.html.twig', [ 'theme' => $theme ] );

	}

	public function followThemeAction( Request$request, $theme_id )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos_theme = $doct->getRepository( 'BlokBundle:Theme' );
		$theme = $repos_theme->findOneById( $theme_id );

		if( $theme === null ) { return Flash::exec( $this->container,'d', $this->errors[0],'blok_forum' ); }

		$result_follow = $doct->getRepository( 'BlokBundle:ThemeFollow' )->addFollowTheme( $this->getUser()->getId(), $theme_id );

		return Flash::exec( $this->container, $result_follow[0], $result_follow[1],'blok_forum_theme',
			[ 'forumid' => $theme->getForumId(), 'id'=>$theme_id ] );

	}

}
