<?

namespace BlokBundle\Controller\Forum;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;


class ForumController extends Controller {


	private $errors = [ 'Такой подфорум не найден.', ];
	private $pop_time = 3600*24;


	private function setSort()
	{
		$sort = 'id';
		$sort_arr = [ 'id' => 'ASC', 'createdAt' => 'ASC', 'updatedAt' => 'DESC', 'countPost' => 'DESC', 'title' => 'DESC' ];

		if( !empty( $_GET['sort'] ) && key_exists( $_GET['sort'], $sort_arr ) )
		{
			$sort = $_GET['sort'];
		}

		return [ 'important' => 'DESC', $sort => $sort_arr[$sort] ];
	}

	private function getCache( FileSystemCache $cache, $doct, $stroka, $prepare  )
	{

		if( !$count = $cache->get( $stroka ) )
		{
			$count = $doct->createQuery( $prepare )->getSingleScalarResult();
			$cache->set( $stroka, $count )->flush();
		}

		return $count;
	}

	private function getStatForum($doct)
	{

		$data = [];
		$cache = new FileSystemCache('guest');

		$data['count_post'] = $this->getCache($cache, $doct, 'count_post',
			'SELECT SUM(f.countPosts) FROM BlokBundle:Forum f' );

		$data['count_theme'] = $this->getCache($cache, $doct, 'count_theme',
			'SELECT SUM(f.countTheme) FROM BlokBundle:Forum f');

		$data['count_forum'] = $this->getCache($cache, $doct, 'count_forum',
			'SELECT COUNT(f.id) FROM BlokBundle:Forum f WHERE f.parentId > 0');


		if( !$data['popular_theme'] = $cache->get( 'popular_theme', true ) )
		{
			$query = $doct->createQuery( 'SELECT p.themeId, COUNT(p.themeId) AS cnt
			FROM BlokBundle:Post p WHERE p.createdAt > :pop_time 
			GROUP BY p.themeId ORDER BY cnt DESC' )
			->setParameter( 'pop_time', time()-$this->pop_time )->setMaxResults( 1 )->getOneOrNullResult();

			$data['popular_theme'] = $doct->createQuery( 'SELECT t.title, t.id, t.countPost, t.forumId
			FROM BlokBundle:Theme t WHERE t.id = '.$query['themeId'].'' )->setMaxResults( 1 )->getOneOrNullResult();

			$data['popular_theme']['cnt'] = $query['cnt'];
			$cache->set( 'popular_theme', $data['popular_theme'] )->flush();
		}

		if( !$data['best_active'] = $cache->get( 'best_forum', true ) )
		{
			$data['best_active'] = $doct->createQuery( 'SELECT f.id, f.countTheme, f.countPosts, f.title 
			FROM BlokBundle:Forum f ORDER BY f.countPosts DESC' )->setMaxResults( 1 )->getOneOrNullResult();
			$cache->set( 'best_forum', $data['best_active'] )->flush();

		}

		return $data;

	}


	public function indexAction()
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository('BlokBundle:Forum');
		$list = $repos->findAll( 0 );

		if( isset( $_GET['search-process'] ) && $_GET['search-process'] == 'start' )
		{
			$result_search = $repos->processSearch($doct);
			return $this->render('BlokBundle:Blok:forum\search-page.html.twig', [ 'result_search' => $result_search ] );
		}

		foreach( $list as $key => $value )
		{
			$forums[ $value->getParentID() ][] = $value;
		}

		$stat = $this->getStatForum($doct);

		return $this->render('BlokBundle:Blok:forum\forum.html.twig', [ 'stat' => $stat, 'forums' => $forums ] );

	}


	public function subForumAction( $id, $page = 1 )
	{

		if( ($text = BanExist::isBan(6, 6 )) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_forum' );
		}

		$doct = $this->getDoctrine()->getManager();
		$subforums = $doct->getRepository('BlokBundle:Forum')->findByParentId( $id );
		$forum = $doct->getRepository('BlokBundle:Forum')->findOneById( $id );
		$theme_repos = $doct->getRepository('BlokBundle:Theme');

		if( $forum === null )
		{
			return Flash::exec( $this->container,'d', $this->errors[0],'blok_forum' );
		}

		$subforums_arr = [];

		foreach( $subforums as $key => $value )
		{
			$subforums_arr[ $value->getParentID() ][] = $value;
		}

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $forum->getCountTheme() )->setUrl( '/forum/'.$id.'/page-' )->countOnPage( $this->get('options')->count_theme_on_page );

		$themes = $paginate->setData( $theme_repos, [ 'forumId' => $id ], $this->setSort(), $page );

		return $this->render('BlokBundle:Blok:forum\subforum.html.twig',
			[ 'paginate' => $paginate, 'forum' => $forum, 'subforums' => $subforums_arr, 'themes' => $themes ] );
	}


}
