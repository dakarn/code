<?

namespace BlokBundle\Controller\Forum;

use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\CheckPrivInRole;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;


class PostController extends Controller {


	private $errors = [ 'Такая тема не существует.', 'Вы не имеете права для редактирования поста.',
		'Ошибка доступа.', 'Такой пост не существует.' ];
	private $result = [ 'Опреация с постом успешно завершена.', 'Сообщение добавлено!', 'Пост успешно изменен',
						'Ваша жалоба успешно отправлена.', ];
	private $need_role = [ 'ROLE_MODER_FORUM', 'ROLE_USER' ];
	private $need_priv = [ 'forum:delete', 'foru:edit' ];


	public function addPostAction( Request $request, $themeid )
	{

		if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
		{
			return $this->redirectToRoute('blok_forum' );
		}

		$doct = $this->getDoctrine()->getManager();
		$post_repos = $doct->getRepository( 'BlokBundle:Post' );
		$theme = $doct->getRepository( 'BlokBundle:Theme' )->findOneBy( [ 'id' => $themeid ] );

		$redirect = [ 'forumid' => $theme->getForumId(), 'id' => $theme->getId(),
			'page' => ceil( $theme->getCountPost()/$this->get('options')->count_post_on_page ) ];

		if($redirect['page'] == 0) $redirect['page'] = 1;

		if( !$this->isGranted( $this->need_role[1] ) )
		{
			return Flash::exec( $this->container,'d', $this->errors[2],'blok_forum_theme_page', $redirect );
		}

		if( ($text = BanExist::isBan(5, 3 )) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_forum_sub', [ 'id' => $theme->getForumId() ] );
		}

		$result = $post_repos->addPostInTheme( $doct, $themeid, $this->getUser() );

		if( $result !== true )
		{
			return Flash::exec( $this->container, 'd',$result,'blok_forum_theme_page',$redirect );
		}

		return Flash::exec( $this->container,'s', $this->result[1],'blok_forum_theme_page',$redirect );

	}


	public function complainPostAction( Request $request, $post_id )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos_post = $doct->getRepository( 'BlokBundle:Post' );
		$post = $repos_post->findOneById( $post_id );

		if( $post === null )
		{
			return Flash::exec( $this->get('notice'), 'danger', $this->errors[3], $this->redirectToRoute('blok_forum' ) );
		}


		$redirect = [ 'forumid' => $post->getForumId(), 'id' => $post->getThemeId() ];

		if( ($text = BanExist::isBan(4, 7 )) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_forum_theme', $redirect );
		}

		if( !$this->isGranted( $this->need_role[1] ) )
		{
			return Flash::exec( $this->container,'d', $this->errors[2],'blok_forum_theme', $redirect );
		}


		if( $request->isMethod( 'POST' ) )
		{

			if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
			{
				return $this->redirectToRoute('blok_forum_theme', $redirect );
			}

			$result = $repos_post->complainPost( $doct, $post, $post_id );

			if( $result !== true )
			{
				return Flash::exec( $this->container, 'd', $result,'blok_forum_theme', $redirect );
			}

			return Flash::exec( $this->container, 's', $this->result[3], 'blok_forum_theme', $redirect );

		}

		return $this->render('BlokBundle:Blok:forum\complain-post.html.twig', [ 'post' => $post ] );

	}

	public function ajaxUsefullPostAction( Request $request )
	{

		if( !$request->isXmlHttpRequest() || !$this->isGranted( $this->need_role[1] ) )
		{
			return new JsonResponse( json_encode( [ 'success' => false, 'text' => $this->errors[2] ] ), 200, [], true );
		}

		if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
		{
			return new JsonResponse( json_encode( [ 'success' => false, 'text' => $this->errors[2] ] ), 200, [], true );
		}

		$doct = $this->getDoctrine()->getManager();
		$post_repos = $doct->getRepository( 'BlokBundle:Post' );
		$post = $post_repos->findOneBy( [ 'id' => abs((int) $_POST['post_id'] ) ] );

		$result = $post_repos->addUsefull( $doct, abs((int) $_POST['post_id'] ) );

		if( $result !== true )
		{
			return new JsonResponse( json_encode( [ 'success' => false, 'text' => $result ] ), 200, [], true );
		}

		return new JsonResponse( json_encode( [ 'success' => true, 'usefull' => $post->getUsefull() ] ), 200, [], true );

	}


	public function actAction( Request $request, $act )
	{

		$success = 'success'; $result = '';

		$doct = $this->getDoctrine()->getManager();
		$post_repos = $doct->getRepository( 'BlokBundle:Post' );
		$post = $post_repos->findOneBy( [ 'id' => abs((int)$_GET['post_id']) ] );

		$redirect = [ 'forumid' => $post->getForumId(),  'id' => $post->getThemeId() ];
		$auth = $this->isGranted( $this->need_role[1] );

		if( $act == 'edit' )
		{

			if( ($text = BanExist::isBan(3, 9 )) !== false )
			{
				return Flash::exec( $this->container,'d', $text,'blok_forum' );
			}

			$legal = CheckPrivInRole::legal( $this->container, $this->need_role[0],true, $this->need_priv[1], true );

			if( !$legal && ( $auth && $this->getUser()->getId() !== $post->getUserId() ) )
			{
				$result = $this->errors[1];

			} else {

				$result = $post_repos->editPostInTheme($doct, abs((int)$_GET['post_id']), $post);
			}

		} else if( $act == 'delete' )
		{

			CheckPrivInRole::legal( $this->container, $this->need_role[0], false, $this->need_priv[0], true );
			$result = $post_repos->deletePostFromTheme( $doct, abs((int)$_GET['post_id'] ), $post );
		}

		if( $result !== true ){ $this->result[0] = $result; $success = 'danger'; }

		return Flash::exec( $this->container, $success, $this->result[0], 'blok_forum_theme', $redirect );

	}


}
