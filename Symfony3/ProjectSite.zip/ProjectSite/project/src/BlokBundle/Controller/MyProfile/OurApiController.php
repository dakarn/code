<?

namespace BlokBundle\Controller\MyProfile;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class OurApiController extends Controller
{


	public function indexAction(Request $request)
	{

		return $this->render('BlokBundle:Blok:myprofile\our_api\index.html.twig');
	}

}