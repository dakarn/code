<?

namespace BlokBundle\Controller\MyProfile;

use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\EmailNotice;
use BlokBundle\Helper\MenuLoader;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class MenuController extends Controller
{

	private $result = [
		'Ваш пароль успешно изменен.<br>Новый пароль: %s.',
		'Ошибка при выполнении запроса',
	];

	public function indexAction( Request $request )
	{

		return $this->render('BlokBundle:Blok:myprofile\myprofile.html.twig' );
	}


	public function menuAction( Request $request )
	{

		$menu = [];
		$repos = $this->getDoctrine()->getManager();

		$menuloader = MenuLoader::getInstance();
		$res = $menuloader->loader( $repos, 'user' );

		foreach( $res as $key => $value )
		{
			$menu[ $value->getParentID() ][] = $value;
		}

		return $this->render('BlokBundle:Blok:myprofile\menu.html.twig', [ 'menu' => $menu, 'url' => $_SERVER['REQUEST_URI'] ] );
	}


	public function passwordAction( Request $request )
	{

		if( ($text = BanExist::isBan(5, 1 )) !== false )
		{
			$this->get('notice')->add( 'danger', $text ); return $this->redirectToRoute( 'blok_myprofile' );
		}

		if( $request->isMethod( 'POST' ) )
		{

			try
			{

				if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
				{
					throw new Exception( $this->result[1] );
				}

				$doct = $this->getDoctrine()->getManager();
				$repos = $doct->getRepository( 'BlokBundle:User' );

				if( $repos->SavePassword( $doct, $this->getUser() ) )
				{
					$this->get('email-notice')->EmailChangePassword( $this->getUser(), $_POST['password_new'] );
				}

				$this->get('notice')->add('success', sprintf( $this->result[0], $_POST['password_new']) );
				return $this->redirectToRoute('blok_myprofile_password' );


			} catch( Exception $e )
			{
				$this->get('notice')->add( 'danger', $e->getMessage() );
				return $this->redirectToRoute('blok_myprofile_password' );
			}

		}

		return $this->render('BlokBundle:Blok:myprofile\password.html.twig' );
	}


}


