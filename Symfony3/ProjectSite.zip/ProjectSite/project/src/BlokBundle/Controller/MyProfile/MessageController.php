<?

namespace BlokBundle\Controller\MyProfile;

use BlokBundle\Entity\FormValidator\ApplySupportValidator;
use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\Flash;
use BlokBundle\Helper\ErrorsForm;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class MessageController extends Controller
{

	private $errors = [
		'Произошла ошибка при отпраке обращения.',
		'Такого обращения не найдено.',
		'Не заполнено сообщение.',
	];
	private $result = [
		'Ваше обращения успешно отправлено администрации. Ожидайте ответа!',
		'Ваш ответ отослан тех. поддержке!',
		'Топик был окончательно закрыт. Больше нельзя в него писать!',
	];


	public function itemMessageAction( Request $request, $id, $page = 1 )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Support' );
		$repos_msg = $doct->getRepository( 'BlokBundle:SupportMessage' );

		$support = $repos->findOneById( $id );

		if( null === $support )
		{
			return Flash::exec( $this->container,'d', $this->errors[1],'blok_myprofile_message_item', ['id'=>$id] );
		}

		$author_support = $support->getUserTable();

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $repos_msg->getCountMessages($doct, $id) )
			->setUrl( $this->generateUrl('blok_myprofile_message_item', [ 'id' => $id ] ) )
			->countOnPage( $this->get('options')->msg_tp_on_page );

		$list_message = $paginate->setPrepare( $this->getDoctrine(), $repos_msg->getMessagesJoinUser($id), $page );

		return $this->render('BlokBundle:Blok:myprofile\message\item-message.html.twig',
			[ 'paginate' => $paginate, 'list_message' => $list_message, 'author_support' => $author_support, 'support' => $support ] );

	}


	public function answerAction( Request $request, $id )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:SupportMessage' );

		if( ($text = BanExist::isBan(6, 7 )) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_myprofile_message' );
		}

		if( $request->isMethod( 'POST' ) )
		{

			if( empty( $_POST['message'] ) || !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
			{
				return Flash::exec($this->container,'d', $this->errors[2],'blok_myprofile_message_item', ['id'=>$id] );
			}

			if( ( $errors = $repos->answerUser( $doct, $id, $this->getUser() ) !== true ) )
			{
				return Flash::exec( $this->container,'d', $errors,'blok_myprofile_message_item', ['id'=>$id] );
			}

			return Flash::exec( $this->container,'s', $this->result[1],'blok_myprofile_message_item', ['id'=>$id] );

		}

		return $this->redirectToRoute('blok_myprofile_message_item', [ 'id' => $id ] );

	}


	public function closeTopicAction( Request $request, $id )
	{

		$doct = $this->getDoctrine()->getManager();
		$close = $doct->getRepository( 'BlokBundle:Support' )->closeTopic( $doct, $id );

		return Flash::exec( $this->container,'d', $this->result[2],'blok_myprofile_message_item', ['id'=>$id] );

	}


	private function addTopic($doct, $repos, $user)
	{

		try
		{
			$errors = $this->get('validator' )->validate( new ApplySupportValidator() );

			if( count( $errors ) > 0 )
			{
				throw new Exception( ErrorsForm::get( $errors ) );
			}

			if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
			{
				throw new Exception( $this->errors[0] );
			}

			if( !$repos->createSupportTopic( $doct, $user ) )
			{
				throw new Exception( $this->errors[0] );
			}

			return Flash::exec( $this->container, 's', $this->result[0],'blok_myprofile_message' );


		} catch( Exception $e )
		{
			return Flash::exec( $this->container, 'd', $e->getMessage(),'blok_myprofile_message' );
		}

	}

	public function indexAction( Request $request, $page = 1 )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Support' );
		$user = $this->getUser();

		if( $request->isMethod( 'POST' ) )
		{
			return $this->addTopic($doct, $repos, $user);
		}

		$sort = 'createdAt';
		if( !empty( $_GET['sort'] ) ) $sort = $_GET['sort'];

		$count = $doct->createQuery('SELECT COUNT(sup.id) FROM BlokBundle:Support sup WHERE sup.userId = '.$user->getId() )->getSingleScalarResult();

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( $this->generateUrl('blok_admin_support') )
			->countOnPage( $this->get( 'options' )->apply_on_page );

		$list_support = $paginate->setData( $repos, ['userId' => $user->getId()], [$sort => 'DESC' ], $page );
		return $this->render('BlokBundle:Blok:myprofile\message\index.html.twig', [ 'list_support' => $list_support ] );

	}

}

