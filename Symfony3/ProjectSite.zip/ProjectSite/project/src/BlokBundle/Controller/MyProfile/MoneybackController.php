<?

namespace BlokBundle\Controller\MyProfile;

use BlokBundle\Entity\FormBuild\Moneyback;
use BlokBundle\Entity\FormValidator\MoneybackValidator;
use BlokBundle\Helper\ErrorsForm;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class MoneybackController extends Controller
{

	private $result = [
		'Заявка успешно отправлена на обработку!',
	];
	private $errors = [
		'Возникла ошибка при отправке заявки',
	];

	public function indexAction(Request $request)
	{

		$form = $this->createForm( Moneyback::class, new MoneybackValidator() );
		$form->handleRequest( $request );

		if( $request->isMethod( 'POST' ) )
		{

			try
			{

				if( !$form->isValid() )
				{
				   throw new Exception( ErrorsForm::get( $form->getErrors( true ) ) );
				}

				$doct = $this->getDoctrine()->getManager();
				$repos = $doct->getRepository( 'BlokBundle:Moneyback' )->addApply( $doct, $form, $this->getUser() );

				if( !$repos )
				{
					throw new Exception( $this->errors[0] );
				}

				$this->get('notice')->add('success', $this->result[0] );
				return $this->redirectToRoute('blok_myprofile_moneyback' );

			} catch( Exception $e )
			{
				$this->get('notice')->add('danger', $e->getMessage() );
				return $this->redirectToRoute('blok_myprofile_moneyback' );
			}
		}

		return $this->render('BlokBundle:Blok:myprofile\key_access\moneyback.html.twig', [ 'form' => $form->createView() ] );

	}

}