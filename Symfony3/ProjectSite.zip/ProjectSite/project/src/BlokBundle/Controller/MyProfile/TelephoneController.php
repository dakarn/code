<?

namespace BlokBundle\Controller\MyProfile;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;


class TelephoneController extends Controller
{

	private $result = ['Номер успешно создан и подключен к вашему профилю!',
		'Возникли проблемы при подключении номера. Попробуйте позже.',
		'Вы не можете подключить номер, так как у вас нет подходящего для этого ключа.',
		'Такой номер уже есть в системе. Выберите другой.',
		'Не верный формат номера.',
		'На вас уже приобретен один номер. Вы не можете приобрести болле одного.' ];

	private $btn = '<button onclick="location_url(\'%s\')" class="btn btn-warning">Удалить номер</button>';


	public function indexAction( Request $request )
	{

		if ($request->isMethod('POST'))
		{
			try
			{

				if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']) ){throw new Exception($this->result[1]); }

				if( !preg_match( '/^8[0-9]{3}[0-9]{3}[0-9]{4}$/', $_POST['number_phone'] ) )
				{
					throw new Exception($this->result[4]);
				}

				$doct = $this->getDoctrine()->getManager();
				$tele_repos = $doct->getRepository( 'BlokBundle:Telephone' );
				$exists = $tele_repos->findOneByNumber( $_POST['number_phone'] );

				if( $exists !== null )
				{
					throw new Exception($this->result[3]);
				}

				if( $exists !== null && $exists->getUserId() === $this->getUser()->getId() )
				{
					throw new Exception($this->result[5]);
				}

				$tele_repos->addTelephone( $doct, $this->getUser() );

				$this->get('notice')->add('success', $this->result[0]);
				return $this->redirectToRoute('blok_myprofile_telephone');


			} catch (Exception $e) {

				$this->get('notice')->add('danger', $e->getMessage());
				return $this->redirectToRoute('blok_myprofile_telephone');
			}

		}

		return $this->render('BlokBundle:Blok:myprofile\telephone\index.html.twig' );

	}


	public function ajaxListNumberAction( Request $request )
	{


		if( !$request->isXmlHttpRequest() || !$this->isGranted('ROLE_USER') )
		{
			return new JsonResponse( json_encode( [ 'success' => false ] ), 200, [], true );
		}

		$resultJson = [];

		$doct = $this->getDoctrine()->getManager();
		$result = $doct->getRepository( 'BlokBundle:Telephone' )->findByUserId( $this->getUser()->getId() );

		foreach( $result as $key => $value )
		{

			$btn = sprintf( $this->btn, $this->generateUrl( 'blok_myprofile_telephone_delete', [ 'id' => $value->getId() ] ) );

			$resultJson[] = [ 'id' => $value->getId(), 'number' => $value->getNumber(), 'btn' => $btn,
							  'created' => date( $this->get('options')->date_format,  $value->getCreatedAt() ) ];
		}

		return new JsonResponse( json_encode( [ 'count' => count( $result ), 'list' => $resultJson ] ), 200, [], true );

	}


	public function deleteNumberAction( Request $request, $id )
	{

		if( !$this->isGranted('ROLE_USER') )
		{
			return $this->redirectToRoute('blok_login');
		}

		$doct = $this->getDoctrine()->getManager();
		$tele_repos = $doct->getRepository( 'BlokBundle:Telephone' );

		$result = $tele_repos->deleteTelephone( $doct, $id, $this->getUser() );

		if( $result !== true )
		{
			$this->get('notice')->add('danger', $result );
		}

		return $this->redirectToRoute('blok_myprofile_telephone');
	}

}

