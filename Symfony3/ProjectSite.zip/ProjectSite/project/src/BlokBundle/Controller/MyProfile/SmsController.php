<?

namespace BlokBundle\Controller\MyProfile;

use BlokBundle\Entity\FormBuild\SendSMS;
use BlokBundle\Entity\FormValidator\SendSMSValidator;
use BlokBundle\Helper\ErrorsForm;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class SmsController extends Controller
{

	private $countBreak = 10;
	private $result = ['Ваше SMS было успешно отправлено получателю!',
		'Возникли проблемы при отправке SMS. Попробуйте позже.',
		'Вы не можете отправлять сообщения, так как у вас нет подходящего для этого ключа.',
		'Слишком частая отпарвка СМС, не более одного СМС за 10 сукунд.',
		'У данного ключа истек срок годнсти.' ];


	public function indexAction( Request $request )
	{

		if( $request->query->has( 'send_sms' ) )
		{
			return $this->sendSMS( $request );
		}

		$doct = $this->getDoctrine()->getManager();
		$key_repos = $doct->getRepository( 'BlokBundle:KeysAccess' );
		$key_list = $key_repos->findBy( [ 'keyType' => ['full','sms'] ] );

		$form = $this->createForm( SendSMS::class, null );

		return $this->render('BlokBundle:Blok:myprofile\sms\index.html.twig', [ 'form' => $form->createView(), 'key_list' => $key_list ] );

	}


	public function sendSMS( Request $request )
	{

		$form = $this->createForm( SendSMS::class, new SendSMSValidator() );
		$form->handleRequest( $request );
		$user = $this->getUser();

		try
		{
			if( !$request->isMethod( 'POST' ) )
			{
				throw new Exception( $this->result[1] );
			}

			if( !$form->isValid() )
			{
				throw new Exception(  ErrorsForm::get( $form->getErrors( true ) ) );
			}

			$doct = $this->getDoctrine()->getManager();
			$key_repos = $doct->getRepository( 'BlokBundle:KeysAccess' );
			$key = $key_repos->findOneBy( [ 'userId' => $user->getId(), 'keyCode' => $form->get('keyCode')->getData(), 'keyType' => ['sms', 'full'] ] );

			if( $key === null )
			{
				throw new Exception( $this->result[2] );
			}

			if( $key->getUpdatedAt() !== 0 && $key->getUpdatedAt() > time()-$this->countBreak )
			{
				throw new Exception( $this->result[3] );
			}

			if( $key->getExpiresAt() < time() )
			{
				throw new Exception( $this->result[4] );
			}

			$result = $doct->getRepository( 'BlokBundle:SMS' )->sendSMS( $form, $doct, $user );

			if( !$result )
			{
				throw new Exception( $this->result[1] );
			}

			$key->setUpdatedAt( time() );
			$doct->flush();

			$this->get('notice')->add('success', $this->result[0]);
			return $this->redirectToRoute( 'blok_myprofile_sms' );

		} catch( Exception $e ){

			$this->get('notice')->add('danger', $e->getMessage() );
			return $this->redirectToRoute('blok_myprofile_sms' );
		}

	}


	private function setSort()
	{
		$sort = 'createdAt';
		$sort_arr = [ 'createdAt' => 'DESC', 'theme' => 'ASC', 'phoneNumber' => 'DESC' ];

		if( !empty( $_GET['sort'] ) && key_exists( $_GET['sort'], $sort_arr ) )
		{
			$sort = $_GET['sort'];
		}

		return [ $sort => $sort_arr[$sort] ];
	}

	public function historyAction( Request $request, $page = 1 )
	{

		$doct = $this->getDoctrine()->getManager();
		$sms_repos = $doct->getRepository( 'BlokBundle:Sms' );

		$count = $doct->createQuery('SELECT COUNT(s.id) FROM BlokBundle:Sms s WHERE s.user_id = '.$this->getUser()->getId().'')->getSingleScalarResult();

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( '/myprofile/sms/history/' )->countOnPage( $this->get('options')->sms_on_page );

		$list = $paginate->setData( $sms_repos, [ 'user_id' => $this->getUser()->getId() ], $this->setSort(), $page );

		return $this->render('BlokBundle:Blok:myprofile\sms\history.html.twig', [ 'list' => $list, 'paginate' => $paginate ] );

	}


}

