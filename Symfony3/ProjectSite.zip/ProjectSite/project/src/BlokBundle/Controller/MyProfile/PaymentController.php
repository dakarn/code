<?

namespace BlokBundle\Controller\MyProfile;

use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;


class PaymentController extends Controller
{

	private $pay_system = [
		 'webmoney' => 'WebMoney',
         'yandex' => 'Yandex.Деньги',
         'mail' => 'Mail.Деньги',
         'bitcoin' => 'Bitcoin',
         'visa' => 'Visa',
         'mastercard' => 'MasterCard',
         'robocassa' => 'Робокасса',
         'qiwi' => 'Visa QIWI Wallet',
         'paypal' => 'PayPal'
	];

	private $message = [
		'Пополнение личевого счета аккуанта на сумму $%s через платежную систему %s.',
	];
	private $result = [
		'Ваш баланс успешно поплнен. На ваш лицевой счет зачислено $%s.<br>Подробности можно посмотреть в истории платежей!
			<br>Данные о платеже отправлены на почту.',
		'Не верно введен баланс.',
		'Ошибка при выполнении запроса.',
	];

	public function indexAction( Request $request )
	{

		if( $request->isMethod( 'POST' ) )
		{
			return $this->pay();
		}

		return $this->render('BlokBundle:Blok:myprofile\payment\index.html.twig', [ 'pay_system' => $this->pay_system ] );

	}


	public function ajaxPaymentFormAction( Request $request )
	{

		if( $request->isXmlHttpRequest() )
		{

			$payment = $_POST['payment'];

			$content = $this->render( 'BlokBundle:Blok:myprofile\payment\\'.$payment.'.html.twig' );
			return new Response(  $content );
		}

		return new Response( $this->result[2] );
	}


	private function pay()
	{

		if( ($text = BanExist::isBan(4, 5 )) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_myprofile_payment' );
		}

		try
		{

			if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token'])){ throw new Exception( $this->result[2] ); }

			$count_money = preg_replace( '/[^0-9]/', '', $_POST['count_money'] );

			if( !is_numeric( $count_money ) )
			{
				throw new Exception( $this->result[1] );
			}

			$doct = $this->getDoctrine()->getManager();
			$conn = $this->getDoctrine()->getConnection(); $conn->beginTransaction();

			try {

				$user = $this->getUser();
				$user->setBalanceFilter( $user->getBalanceFilter() + (int)$count_money );
				$doct->flush();

				$id = $doct->getRepository( 'BlokBundle:History' )
					->addInHistory( $doct, $user,  'payment', sprintf( $this->message[0], $count_money,'WebMoney' ) );

				$this->sendMail( $user, $count_money, $id ); $conn->commit();

			} catch ( Exception $e )
			{
				$conn->rollBack();
				throw new Exception( $this->result[2] );
			}

			$this->get('notice')->add('success', sprintf( $this->result[0], $_POST['count_money'] ) );
			return $this->redirectToRoute('blok_myprofile_payment' );

		} catch( Exception $e ) {

			$this->get('notice')->add('danger', $e->getMessage() );
			return $this->redirectToRoute('blok_myprofile_payment' );
		}

	}

	private function sendMail( $user, $count_money, $id )
	{
		if( $id !== -1 )
		{
			return $this->get('email-notice')->EmailPayment(  $user, $count_money, $id );
		}

	}


}

