<?

namespace BlokBundle\Controller\MyProfile;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;


class HistoryController extends Controller
{


	private function operAliasFilter( $oper )
	{

		$oper = str_replace( 'buy', 'Покупка', $oper);
		$oper = str_replace( 'payment', 'Пополнение счета', $oper);

		return $oper;
	}

	public function indexAction( Request $request )
	{
		return $this->render('BlokBundle:Blok:myprofile\history-operation.html.twig' );
	}


	public function ajaxHistoryAction( Request $request )
	{

		if( !$this->isGranted('ROLE_USER') )
		{
			return new JsonResponse( json_encode( [ 'success' => false ] ), 200, [], true );
		}

		if( !$request->isXmlHttpRequest() )
		{
			return new JsonResponse( json_encode( [ 'success' => false ] ), 200, [], true );
		}

		$resultJson = [];

		switch( $_POST[ 'act' ] )
		{

			case 'buy': $result = $this->buyHistory(); break;
			case 'payment':  $result = $this->paymentHistory(); break;
		}

		foreach( $result as $key => $value )
		{
			$resultJson[] = [ 'type' => $this->operAliasFilter( $value->getTypeOperation() ),
						  'created' => date( $this->get('options')->date_format,  $value->getCreatedAt() ),
						  'descript' => $value->getDescript() ];
		}

		return new JsonResponse( json_encode( [ 'count' => count( $result ), 'list' => $resultJson ] ), 200, [], true );

	}

	private function buyHistory()
	{

		$em = $this->getDoctrine()->getManager();
		return $em->getRepository( 'BlokBundle:History' )->findByTypeOperation( 'buy' );
	}


	private function paymentHistory()
	{

		$em = $this->getDoctrine()->getManager();
		return $em->getRepository( 'BlokBundle:History' )->findByTypeOperation( 'payment' );
	}

}
