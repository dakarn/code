<?php

namespace BlokBundle\Controller\MyProfile;

use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\Flash;
use BlokBundle\Helper\FunctionHelper;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class KeyAccessController extends Controller
{

	public $message = [
		'Покупка ключа доступа (%s) на сумму $%s.', 'Продление ключа доступа (%s) на сумму $%s.', ];
	public $result = [
		'Поздравляем! Вы успешно купили ключ. Теперь вы можете использвать его.',
		'На вашем личевом счету не хавтает средств для осществления покупки. Пополните его.',
		'На такой период времени нельзя закзать услугу.', 'Такая услуга не существует.',
		'Проблемы при выполнении операции. Повторите попытку.', 'Не удалось продлить ключ. Повторите попытку.',
		'Поздравляем! Вы успешно продлили ключ.',  'Ошибка! Такого ключа не найдено.' ];
	private $type_key = [
		[ 'full' => 'Полный', 'price' => 20, 'update' => 17 ],
		[ 'api' => 'Ключ для API', 'price' => 3, 'update' => 2 ],
		[ 'internet' => 'Ключ для доступа к интернету', 'price' => 4, 'update' => 3 ],
		[ 'telephone' => 'Ключ для доступа к телефону', 'price' => 4, 'update' => 3 ],
		[ 'sms' => 'Ключ для СМС агрегатора', 'price' => 5, 'update' => 4 ],
		[ 'proxy' => 'Ключ для выделенного прокси сервера', 'price' => 10, 'update' => 8 ] ];
	public $duration = [
		['hour' => 3600, 'name' => 'Час', 'discount' => 0, 'ration' => 0.041 ],
		['hour_3' => 10800, 'name' => '3 Часа', 'discount' => 0, 'ration' => 0.123 ],
		['day' => 86400,  'name' => 'Сутки', 'discount' => 0, 'ration' => 1 ],
		['day_3' => 259200,  'name' => '3-e Суток', 'discount' => 0, 'ration' => 3 ],
		['week' => 604800,  'name' => 'Неделя', 'discount' => 0, 'ration' => 7 ],
		['week_2' => 1209600,  'name' => '2 Недели', 'discount' => 0, 'ration' => 14 ],
		['week_3'=> 1814399,  'name' => '3 Недели', 'discount' => 0, 'ration' => 21 ],
		['month'=> 2419200,  'name' => 'Месяц', 'discount' => 3, 'ration' => 30 ],
		['month_2'=> 5184000,  'name' => '2 Месяца', 'discount' => 6, 'ration' => 60 ],
		['month_3'=> 7776000,  'name' => '3 Месяца', 'discount' => 8, 'ration' => 90 ],
		['month_6'=> 15552000,  'name' => '6 Месяцев', 'discount' => 10, 'ration' => 180 ],
		['year'=> 31536000,  'name' => 'Год', 'discount' => 18, 'ration' => 365 ],
		['year_2'=> 63072000,  'name' => '2 Года', 'discount' => 30, 'ration' => 730 ],
		['year_3'=> 94672800,  'name' => '3 Года', 'discount' => 45, 'ration' => 1095 ] ];

	public function indexAction( $page = 1 )
	{

		$doct = $this->getDoctrine()->getManager();
		$key_repos = $doct->getRepository( 'BlokBundle:KeysAccess' );

		$count = $doct->createQuery('SELECT COUNT(key.id) FROM BlokBundle:KeysAccess key')->getSingleScalarResult();

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( '/myprofile/key_access/' )->countOnPage( $this->get( 'options' )->key_on_page );

		$keys = $paginate->setData( $key_repos, [ 'userId' => $this->getUser()->getId() ], ['createdAt' => 'DESC' ], $page );

		return $this->render('BlokBundle:Blok:myprofile\key_access\index.html.twig', [ 'keys' => $keys, 'paginate' => $paginate ] );
	}


	private function checkBalance( $balance, $price )
	{
		if( $balance < $price ){ return false; } else { return true; }
	}


	public function updateAction( Request $request, $key )
	{

		if( ($text = BanExist::isBan(5, 5)) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_myprofile_key_access' );
		}

		$doct = $this->getDoctrine()->getManager();
		$keys = $doct->getRepository( 'BlokBundle:KeysAccess' )->findOneByKeyCode( $key );

		if( $keys === null )
		{
			$this->get('notice')->add('danger', $this->result[7] ); return $this->redirectToRoute('blok_myprofile_key_access' );
		}

		$user = $this->getUser();

		$year = floor( ( $keys->getExpiresAt() - time() )/31536000 );
		$day = floor( ( $keys->getExpiresAt() - time() )/86400 ) - $year * 365;
		$hours = floor( ( ($keys->getExpiresAt() - time())%86400)/3600 );
		$minutes = floor( ( ( ($keys->getExpiresAt() - time() )%86400 )%3600/60) );

		$expires_to_time = [ 'year' => $year, 'day' => $day, 'hours' => $hours, 'minutes' => $minutes ];

		$key_type = FunctionHelper::exists_value_in_arr( $keys->getKeyType(), $this->type_key, 'array' );

		if( $request->isMethod( 'POST' ) )
		{

			try
			{
				if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']) )
				{
					$this->get('notice')->add('danger', $this->result[4] );
				}

				if( ! $duration = FunctionHelper::exists_value_in_arr( $_POST['duration_key'], $this->duration, 'array' ) )
				{
					throw new Exception( $this->result[2] );
				}

				$full_price = $duration['ration'] * $key_type['update'];
				$total_price = round( $full_price - ( ( $full_price / 100 ) * $duration['discount'] ), 2 );

				if( !$this->checkBalance( $user->getBalanceFilter(), $total_price ) )
				{
					throw new Exception( $this->result[1] );
				}

				$keys->setExpiresAt( $keys->getExpiresAt() + $duration[ $_POST['duration_key'] ] );
				$doct->flush();

				$user->setBalanceFilter($user->getBalanceFilter() - $total_price);
				$doct->flush();

				$doct->getRepository( 'BlokBundle:History' )
					->addInHistory( $doct, $user,  'buy', sprintf( $this->message[1], $key_type[$keys->getKeyType()], $total_price ) );

				$this->get('notice')->add('success', $this->result[6] );
				return $this->redirectToRoute('blok_myprofile_key_access_update', [ 'key' => $key ] );


			} catch( Exception $e ){

				$this->get('notice')->add('danger', $e->getMessage() );
				return $this->redirectToRoute('blok_myprofile_key_access_update',  [ 'key' => $key ] );

			}

		}

		return $this->render('BlokBundle:Blok:myprofile\key_access\update.html.twig',
			[ 'selected_dur' => 'day', 'key' => $keys, 'to_time' => $expires_to_time, 'key_type' => $key_type,
			  'durations' => $this->duration, 'type_key' => $this->type_key ] );
	}


	public function buyKeyAction( Request $request )
	{

		if( ($text = BanExist::isBan(5, 5)) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_myprofile_key_access' );
		}

		if( $request->isMethod( 'POST' ) )
		{

			try
			{
				if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']) )
				{
					throw new Exception( $this->result[4] );
				}

				if( ! $duration = FunctionHelper::exists_value_in_arr( $_POST['duration_key'], $this->duration, 'array' ) )
				{
					throw new Exception( $this->result[2] );
				}

				if( ! $type_key = FunctionHelper::exists_value_in_arr( $_POST['type_key'], $this->type_key, 'array' ) )
				{
					throw new Exception( $this->result[3] );
				}

				$user = $this->getUser(); $full_price = $duration['ration'] * $type_key['price'];
				$total_price = round( $full_price - ( ( $full_price / 100 ) * $duration['discount'] ), 2 );

				if( !$this->checkBalance( $user->getBalanceFilter(), $total_price ) )
				{
					throw new Exception( $this->result[1] );
				}

				$doct = $this->getDoctrine();
				$keys_repos = $doct->getRepository( 'BlokBundle:KeysAccess' );
				$doct->getConnection()->beginTransaction();

				try
				{
					$keys_repos->createKey( $doct->getManager(), $request,
						$this, $user, $this->container, $type_key, $total_price );

					$doct->getConnection()->commit();

				} catch( Exception $e )
				{
					$doct->getConnection()->rollBack();
					$this->get('notice')->add('danger', $this->result[4] );
					throw $e;
				}

				$this->get('notice')->add('success', $this->result[0] ); return $this->redirectToRoute('blok_myprofile_key_access' );


			} catch( Exception $e ){

				$this->get('notice')->add('danger', $e->getMessage() ); return $this->redirectToRoute('blok_myprofile_key_access' );

			}

		}

		return $this->render('BlokBundle:Blok:myprofile\key_access\buy.html.twig',
			[ 'default_price' => 12, 'selected_dur' => 'day', 'selected_type' => 'full', 'durations' => $this->duration, 'type_key' => $this->type_key ] );

	}

}