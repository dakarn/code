<?

namespace BlokBundle\Controller\MyProfile;

use BlokBundle\Entity\FormBuild\EditProfile;
use BlokBundle\Entity\FormValidator\EditProfileValidator;
use BlokBundle\Helper\BanExist;
use BlokBundle\Helper\ErrorsForm;
use BlokBundle\Helper\Flash;
use BlokBundle\Helper\Upload\UpdateAvatar;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class EditProfileController extends Controller
{


	private $default_avatar = 'no-avatar.jpg';
	private $result = ['Ваша учетная запись успешно изменена!',
					   'Возникли проблемы при сохранении данных',
					   'Ваш аватар успешно изменен!',
					   'Ваш аватар удален и заменен на стандартный!',
					   ];


	public function updateAvatarAction( Request $request )
	{

		try
		{
			if( $request->isMethod( 'POST' ) )
			{

				$doct = $this->getDoctrine()->getManager();

				if( isset( $_POST['type_avatar'] ) && $_POST['type_avatar'] == 'delete_avatar' )
				{

					$this->get('notice')->add('success', $this->result[3] );
					$user = $this->getUser();

					unlink( ROOT.$this->get('options')->path_to_avatar.$user->getAvatar() );

					$user->setAvatar( $this->default_avatar );
					$doct->flush();

				} else {

					$upload = new UpdateAvatar($doct, $this->getUser());
					$upload->validate($this->get('generate'), $this->get('options'));
					$this->get('notice')->add('success', $this->result[2] );
				}

			}

			return $this->redirectToRoute('blok_myprofile' );


		} catch( Exception $e ){

			$this->get('notice')->add('danger', $e->getMessage() ); return $this->redirectToRoute('blok_myprofile' );

		}

	}


	public function optionsKeyAction( Request $request, $key_id )
	{

		if( ($text = BanExist::isBan(5, 5)) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_myprofile_key_access' );
		}

		$user = $this->getUser();
		$doct = $this->getDoctrine()->getManager();
		$key = $doct->getRepository( 'BlokBundle:KeysAccess' )
			->findOneBy( [ 'id' => $key_id, 'userId' => $user->getId()  ] );

		if( $key === null )
		{
			return Flash::exec( $this->container,'d', $this->result[7],'blok_myprofile_key_access' );
		}

		$result = $doct->getRepository( 'BlokBundle:KeysProperty' )->editProperty( $this->container, $doct, $key );

		if( $result[0] !== false )
		{
			return Flash::exec( $this->container, $result[1], $result,'blok_myprofile_key_options', ['key_id'=>$key->getId()] );
		}

		return $this->render('BlokBundle:Blok:myprofile\key_access\options\index.html.twig', [ 'key' => $key ] );

	}

	public function editProfileAction( Request $request )
	{

		if( ($text = BanExist::isBan(5, 4 )) !== false )
		{
			return Flash::exec( $this->container,'d', $text,'blok_myprofile' );
		}

		$form = $this->createForm( EditProfile::class,  new EditProfileValidator() );
		$form->handleRequest( $request );

		if( $request->isMethod( 'POST' ) )
		{

			try
			{
				if( !$form->isValid() )
				{
					throw new Exception( ErrorsForm::get( $form->getErrors( true ) ) );
				}

				$em = $this->getDoctrine()->getManager();
				$save = $em->getRepository('BlokBundle:User');

				if (!$save->SaveProfile($em, $this->getUser(), $form, 'userSaveProfile'))
				{
					throw new Exception($this->result[2]);
				}

				$this->sendMail( $this->getUser() );
				$this->get('notice')->add('success', $this->result[0]); return $this->redirectToRoute('blok_myprofile_edit');


			} catch (Exception $e) {

				$this->get('notice')->add('danger', $e->getMessage());
				return $this->redirectToRoute('blok_myprofile_edit');
			}

		}

		return $this->render('BlokBundle:Blok:myprofile\edit.html.twig', [ 'form' => $form->createView() ] );
	}

	private function sendMail( $user )
	{
		return $this->get('email-notice')->EmailChangeProfile(  $user );
	}

}


