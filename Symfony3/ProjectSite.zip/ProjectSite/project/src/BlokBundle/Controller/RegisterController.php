<?

namespace BlokBundle\Controller;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\FormBuild\Registration;
use BlokBundle\Helper\EmailNotice;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use BlokBundle\Entity\User;
use Symfony\Component\Security\Core\User\UserInterface;


class RegisterController extends Controller {


	private $errors = [];
	private $activate_key;
	private $avatar = 'no-avatar.jpg';
	private $default_role = 'ROLE_USER';


	public function indexAction( Request $request )
	{

		$form = $this->createForm( Registration::class, new User() );
		$form->handleRequest($request);

		if( $request->isMethod( 'POST' ) && $form->isValid() )
		{

			if( $this->get( 'options' )->enable_register == 'off' )
			{
				return $this->redirectToRoute( 'blok_register' );
			}

			$exists_data  = $this->getDoctrine()->getRepository( 'BlokBundle:User' )->exists_data( $form );

			if( count( $exists_data ) > 0 )
			{
				return $this->render('BlokBundle:Blok:register.html.twig', [ 'errors' => $exists_data, 'form' => $form->createView() ] );
			}

			$this->activate_key = $this->get( 'generate' )->generateKeyCode( 20 );

			$this->addUser( new User(), $form );
			$this->sendMail( $form );

			return  $this->render('BlokBundle:Blok:success-register.html.twig', [ 'data' => $form->getData() ] );
		}

		return  $this->render('BlokBundle:Blok:register.html.twig', [ 'form' => $form->createView() ] );
	}


	private function addUser( UserInterface $user, $form )
	{

		$em = $this->getDoctrine()->getManager();

		$password = $this->get('security.password_encoder')->encodePassword($user, $form->get('password')->getData() );
		$user->setPassword($password);

		$user->setEmail( $form->get('email')->getData() );
		$user->setGender( $form->get('gender')->getData() );
		$user->setIsActive( 0 );
		$user->setAvatar( $this->avatar )->setRoles( $this->default_role );
		$user->setCreatedAt( time() );
		$user->setBalance( 0 )->setCountpost( 0 );
		$user->setCity( $form->get('city')->getData() );
		$user->setCountry( $form->get('country')->getData() );
		$user->setAge( $form->get('age')->getData() );
		$user->setUsername( $form->get('username')->getData() );
		$user->setActivationKey( $this->activate_key );
		$user->setUpdatedAt( time() )->setLastEnter( '' );
		$em->persist( $user );
		$em->flush();

		$cache = new FileSystemCache('guest');
		$cache->counter('incr', 'user_count')->flush();

		return true;

	}

	private function sendMail( $form )
	{
		$email = $this->get('email-notice');
		return $email->EmailRegister(  $form, $this->activate_key );
	}

}