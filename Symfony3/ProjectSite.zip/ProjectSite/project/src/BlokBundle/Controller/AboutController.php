<?

namespace BlokBundle\Controller;

use BlokBundle\Entity\Chmodfile;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class AboutController extends Controller {


   public function contactAction()
   {

	   return $this->render('BlokBundle:Blok:contact.html.twig' );
   }

   public function aboutAction()
   {


     return $this->render('BlokBundle:Blok:about.html.twig' );

   }
 
}
