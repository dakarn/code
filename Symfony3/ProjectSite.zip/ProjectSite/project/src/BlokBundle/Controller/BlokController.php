<?php

namespace BlokBundle\Controller;

use BlokBundle\Helper\Flash;
use BlokBundle\Helper\MenuLoader;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;


class BlokController extends Controller {
 

	private $role = ['ROLE_USER'];
	private $result =['Ваш аккуант не активированю.<br>Для получения доступа вам надо активировать аккуант.'];

    public function indexAction()
    {

    	if( $this->isGranted( $this->role[0]) && $this->getUser()->getIsActive() == 0 )
	    {
		    return $this->redirectToRoute('blok_logout');
	    }

        return $this->render('BlokBundle:Blok:index.html.twig' );
    }


    public function faqAction()
    {
	    return $this->render('BlokBundle:Blok:faq\index.html.twig' );
    }

    public function ajaxLoadNoticeAction()
    {

    	if( !$this->isGranted( $this->role[0] ) )
	    {
		    return new JsonResponse( json_encode(['success' => false]), 403, [], true );
	    }

		$user = $this->getUser();

	    $notice = new \Redis;
	    $notice->connect('127.0.0.1', 6379 );

	    $result = $notice->hgetAll( 'new_notice_'.$user->getId() );

	    $notice->delete( 'new_notice_'.$user->getId() );
		$notice->close();

	    return new JsonResponse( json_encode( [ 'count' => count($result), 'success'=>true, 'list'=>$result ] ), 200, [], true );

    }

	public function menuHeaderAction()
	{

		$menu = [];
		$repos = $this->getDoctrine()->getManager();
		$user = $this->getUser();

		$menuloader = MenuLoader::getInstance();
		$res = $menuloader->loader( $repos, 'header' );

		foreach( $res as $key => $value )
		{
			if( $this->isGranted( 'ROLE_USER', $user ) && $value->getPublic() == 2 ) continue;
			if( !$this->isGranted( 'ROLE_USER', $user ) && $value->getPublic() == 1 ) continue;

			$menu[ $value->getParentID() ][] = $value;
		}

		return $this->render('BlokBundle:Blok:header-menu.html.twig', [ 'path_icon' => PATH_TO_MENU_ICON, 'menu' => $menu, 'url' => $_SERVER['REQUEST_URI'] ] );
	}

}
