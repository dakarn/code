<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Helper\CheckPrivInRole;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use BlokBundle\Entity\KeysAccess;
use Symfony\Component\HttpFoundation\Request;


class KeysManagerController extends  Controller
{

	private $need_role = ['ROLE_ADMIN_HELPER','ROLE_ADMIN'];
	private $result = [ 'Ключ успешно удален!',
		                'Все ключи удалены!',
		                'Ошибка при удалении ключей', 'Неактивные ключи удалены!','Неоплаченые номера удалены!' ];


	private function getCacheCount( FileSystemCache $cache, $doct )
	{

		if( !$count = $cache->get( 'keys_count' ) )
		{
			$count = $doct->createQuery('SELECT COUNT(key.id) FROM BlokBundle:KeysAccess key')->getSingleScalarResult();
			$cache->set( 'keys_count', $count )->flush();
		}

		return $count;
	}

	public function deleteExpiresKeyAction()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$doct = $this->getDoctrine()->getManager();

		$query = $doct->createQuery( 'DELETE  BlokBundle:KeysAccess key WHERE key.expiresAt < :expires' );
		$query->execute( [ 'expires' => time() ] );

		$this->get('notice')->add('success', $this->result[3] );
		return $this->redirectToRoute( 'blok_admin_key_manager' );

	}

	public function indexAction( Request $request, $page = 1 )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$doct = $this->getDoctrine()->getManager();

		if( isset(  $_GET['delete_id'] ) && is_numeric( $_GET['delete_id'] )  )
		{
			$result= $doct->getRepository('BlokBundle:KeysAccess')->deleteKey( $doct, $_GET['delete_id']);
			return Flash::exec( $this->container,'s', $this->result[0],'blok_admin_key_manager' );
		}

		if( isset(  $_GET['act'] ) && $_GET['act'] == 'deleteall' )
		{
			$result= $doct->getRepository('BlokBundle:KeysAccess')->deleteAll( $this->get( 'notice' ), $this->result );
			return $this->redirectToRoute( 'blok_admin_key_manager' );
		}

		if( isset(  $_GET['act'] ) && $_GET['act'] == 'expire_phone' )
		{
			$result= $doct->getRepository('BlokBundle:Telephone')->deleteExpirePhone( $this->container );
			return Flash::exec( $this->container,'s', $this->result[4],'blok_admin_key_manager' );
		}

		$key_repos = $doct->getRepository('BlokBundle:KeysAccess');

		$count = $this->getCacheCount( new FileSystemCache( 'guest' ), $doct );

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( '/admin-panel/keys_manager/' )->countOnPage($this->get( 'options' )->key_on_page );

		$keys = $paginate->setData( $key_repos, [], ['createdAt' => 'ASC' ], $page );

		return $this->render('BlokBundle:Blok:admin\keys\index.html.twig', ['keys' => $keys, 'paginate' => $paginate, ] );
	}


	public function addKeyTestsAction()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[1], false, '' );

		$doct = $this->getDoctrine()->getManager();
		$doct->getRepository( 'BlokBundle:KeysAccess' )->addKeyTests( $doct, $this->getUser() );

		return $this->redirectToRoute('blok_admin_key_manager');

	}

}