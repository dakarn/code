<?php

namespace BlokBundle\Controller\Admin;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class ApiController extends Controller
{

	private $need_role = [ 'ROLE_ADMIN_HELPER' ];
	private $result = [
		'Настройки успешно обновлены!',
		'Ошибка при сохранении настроек!',
	];

	public function indexAction( Request $request )
	{
		$em = $this->getDoctrine()->getManager();
		$options = $em->getRepository( 'BlokBundle:Options' )->findByType( 'api', array('type_form' => 'DESC') );


		if( $request->isMethod('POST') )
		{

			foreach ( $options as $key => $option )
			{

				if( !isset( $_POST[$option->getName()] ) )
				{
					$value = 'off';
				} else {
					$value = $_POST[$option->getName()];
				}

				$option->setName( $option->getName() );
				$option->setValue( $value );
			}

			$em->flush();
			$em->clear();

			$this->get('options')->clearMemory();
			$this->get('notice')->add( 'success', $this->result[0] );

			return $this->redirectToRoute( 'blok_admin_setting_api' );

		}

		return $this->render('BlokBundle:Blok:admin\api\index.html.twig', [ 'options' => $options ] );
	}

}