<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;


class StatVisitController extends Controller
{


	private function setSort()
	{
		$sort = 'ip';
		$sort_arr = [ 'visitTime' => 'ASC', 'ip' => 'ASC', 'countVisit' => 'DESC' ];

		if( !empty( $_GET['sort'] ) && key_exists( $_GET['sort'], $sort_arr ) )
		{
			$sort = $_GET['sort'];
		}

		return [ $sort => $sort_arr[$sort] ];
	}

	public function indexAction( $page = 1 )
	{

		$result = '';
		$doct = $this->getDoctrine()->getManager();
		$visit_repos = $doct->getRepository( 'BlokBundle:VisitHost' );

		if( isset( $_GET['act'] ) )
		{

			if( $_GET['act'] == 'test' )
			{
				$result = $visit_repos->createTestVisit($doct);
			}

			if ($_GET['act'] == 'deleteall')
			{
				$result = $visit_repos->deleteAll($doct);
			}

			return Flash::exec( $this->container, 's', $result,'blok_admin_stat_visit' );

		}

		$cache = new FileSystemCache( 'guest' );

		$count = $cache->get('count_uniq_visit');
		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( $this->generateUrl( 'blok_admin_stat_visit' ).'page-' )->countOnPage(50);

		$list_visit = $paginate->setData( $visit_repos, [], $this->setSort(), $page );

		return $this->render('BlokBundle:Blok:admin\stat-visit.html.twig',
			[ 'count' => $count, 'count_visit' => $cache->get('count_visit'), 'paginate' => $paginate,
				'count_online' => $cache->get('count_online'), 'list_visit' => $list_visit ] );
	}

}