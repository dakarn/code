<?php

namespace BlokBundle\Controller\Admin\Forum;

use BlokBundle\Entity\FormBuild\Theme;
use BlokBundle\Entity\FormValidator\ThemeValidator;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class ThemeController extends Controller
{

	private $result = [
		'Тема, а также ее посты были полность удалены!',
		'Тема была закрыта для написания, ее можно только читать!',
		'Тема добавлена в форум!',
		'Тема была перемещена в другой подфорум!',
		'Темы были успешно слиты в одну!',
		'Темы была очищена!',
		'Темы была удалена!',
		'Был произведен пересчет постов в теме!',
	];
	private $errors = [
		'Такой форум не найден.',
		'В данном форуме нельзя создавать темы.',
		'Такой темы не найдено.'
	];


	public function createAction( Request $request, $forumid )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Forum' );
		$repos_theme = $doct->getRepository( 'BlokBundle:Theme' );
		$forum = $repos->findOneById( $forumid );

		if( $forum === null )
		{
			return Flash::exec( $this->container,'d', $this->errors[0],'blok_forum' );
		}

		if( $forum->getParentId() === 0 )
		{
			return Flash::exec( $this->container,'d', $this->errors[1],'blok_forum' );
		}

		$form = $this->createForm( Theme::class, new ThemeValidator() );
		$form->handleRequest($request);

		if( $request->isMethod( 'POST' ) )
		{
			$result = $repos_theme->addTheme( $doct, $form, $this->getUser(), $forumid, $forum );

			if( $result !== true )
			{
				return Flash::exec( $this->container,'d',$result,'blok_admin_forum_sub', [ 'id'=>$forumid ] );
			}

			return Flash::exec( $this->container,'s', $this->result[2],'blok_admin_forum_sub', [ 'id'=>$forumid ] );

		}

		return $this->render('BlokBundle:Blok:forum\create-theme.html.twig', [ 'forum' => $forum, 'form' => $form->createView() ] );

	}


	public function moveThemeAction( Request $request, $id )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository('BlokBundle:Forum');
		$theme_repos = $doct->getRepository('BlokBundle:Theme');
		$theme = $theme_repos->findOneBy( [ 'id' => $id ] );

		if( $theme === null )
		{
			return Flash::exec( $this->container,'d', $this->errors[2],'blok_admin_forum' );
		}


		$current_forum = $repos->findOneBy( [ 'id' => $theme->getForumId() ] );

		if( $request->isMethod( 'POST' ) )
		{

			if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
			{
				return $this->redirectToRoute('blok_admin_forum' );
			}

			$result = $theme_repos->moveTheme( $doct, $theme, $id, $repos, $current_forum );

			if( $result !== true )
			{
				return Flash::exec( $this->container,'d', $result,'blok_forum_theme', [ 'id'=>$id ] );
			}

			return Flash::exec( $this->container,'s', $this->result[3],'blok_forum_theme', [ 'id'=>$id ] );

		}

		return $this->render('BlokBundle:Blok:admin\forum\move-theme.html.twig',
			[ 'current_forum' => $current_forum, 'theme' => $theme, 'forums' => $repos->findAll() ] );

	}


	public function mergeThemeAction( Request $request, $theme_id )
	{

		$doct = $this->getDoctrine()->getManager();
		$theme_repos = $doct->getRepository( 'BlokBundle:Theme' );
		$theme = $theme_repos->findOneBy( [ 'id' => $theme_id ] );

		if( $theme === null )
		{
			return Flash::exec( $this->container,'d', $this->errors[2],'blok_admin_forum' );
		}

		if( $request->isMethod( 'POST' ) )
		{
			$result = $theme_repos->mergeTheme( $doct, $this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']), $theme_id );

			if( $result !== true )
			{
				$this->result[4] = $result;
			}

			return Flash::exec( $this->get('notice'),'s', $this->result[4],'blok_forum_theme', [ 'id'=>$theme_id ] );
		}

		return $this->render('BlokBundle:Blok:admin\forum\merge-theme.html.twig', [ 'theme' => $theme ] );
	}


	public function actAction( Request $request, $act )
	{

		$doct = $this->getDoctrine()->getManager();
		$theme_repos = $doct->getRepository( 'BlokBundle:Theme' );
		$theme = $theme_repos->findOneBy( [ 'id' => (int)$_GET['id'] ] );

		if( $theme_repos === null )
		{
			return Flash::exec( $this->container,'s', $this->result[1],'blok_admin_forum' );
		}

		$redirect = [ 'forumid' => $theme->getForumId(), 'id'=>$theme->getId() ];

		if( $act == 'close' )
		{
			$theme_repos->closeTheme( $doct );
			return Flash::exec( $this->container,'s', $this->result[1],'blok_forum_theme', $redirect );

		} else if( $act == 're-count' )
		{
			$theme_repos->recountPostInTheme( $doct );
			return Flash::exec( $this->container,'s', $this->result[7],'blok_forum_theme', $redirect );

		} else if( $act == 'clear-all' )
		{
			$theme_repos->clearTheme();
			return Flash::exec( $this->container,'s', $this->result[5],'blok_forum_theme', $redirect );

		} else if( $act == 'delete' )
		{
			$theme_repos->deleteTheme( $doct );
			return Flash::exec( $this->container,'s', $this->result[0],'blok_admin_forum_sub', [ 'id'=>$theme_repos->getForumId() ] );

		}

	}


}