<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\FormBuild\Admin\EditUser;
use BlokBundle\Entity\FormValidator\Admin\EditUserValidator;
use BlokBundle\Helper\CheckPrivInRole;
use BlokBundle\Helper\ErrorsForm;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\File\File;
use Symfony\Component\HttpFoundation\Request;


class UsersHelperController extends Controller
{

	private $role = ['ROLE_ADMIN_HELPER', 'ROLE_MODER', 'ROLE_ADMIN'];
	private $priv = ['user:create', 'user:delete'];
	private $result = [
		'Пользоваткль был успешно создан!',
		'База пользователей была очищена!',
		'Пользователи в количестве %d для теста сгенерированы!',
		'Все неактивные баны удалены!',
		'База пользователей была очищена!', ];
	private $error_text = [
		'Пользователь с такими логином или почтой уже существует.',
		'Произошла системная ошибка при создании юзера.'];


	private function getCountComplain( FileSystemCache $cache, $doct )
	{

		if( !$count = $cache->get( 'complain_count' ) )
		{
			$count = $doct->createQuery('SELECT COUNT(c.id) FROM BlokBundle:Complain c')->getSingleScalarResult();
			$cache->set( 'complain_count', $count )->flush();
		}

		return $count;
	}

	public function addUserAction( Request $request )
	{

		CheckPrivInRole::legal( $this->container, $this->role[0], false, '' );

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:User' );

		if( isset( $_GET['add_user_tested']) )
		{
			$repos->addUsersTested( $doct );
			return $this->redirectToRoute( 'blok_admin_users' );
		}

		$form = $this->createForm( EditUser::class, new EditUserValidator() );
		$form->handleRequest( $request );

		if( $request->isMethod( 'POST' ))
		{

			try
			{
				if( !$form->isValid() )
				{
					throw new Exception( ErrorsForm::get( $form->getErrors( true ) ) );
				}

				$exists_data = $repos->exists_data( $form );

				if( count( $exists_data ) > 0 )
				{
					throw new Exception( $this->error_text[0] );
				}

				if( !$repos->createUserAdmin( $doct, $form, $this->get('security.password_encoder') ) )
				{
					throw new Exception( $this->error_text[1] );
				}

				$this->get('notice')->add('success', $this->result[0] );
				return $this->redirectToRoute( 'blok_admin_users' );

			} catch ( Exception $e ) {

				$this->get('notice')->add('danger', $e->getMessage() );
				return $this->redirectToRoute( 'blok_admin_user_add' );
			}
		}

		return $this->render('BlokBundle:Blok:admin\users\add-user.html.twig', [ 'form' => $form->createView() ] );
	}


	public function listMoneybackAction( Request $request, $page = 1)
	{

		$doct = $this->getDoctrine()->getManager();
		$moneyback_repos = $doct->getRepository( 'BlokBundle:Moneyback' );

		$count = $this->getCountComplain( new FileSystemCache('guest'), $doct );

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( $this->generateUrl('blok_admin_apply_moneyback') )->countOnPage( $this->get( 'options' )->complain_on_page );

		$list_moneyback = $paginate->setData( $moneyback_repos, [], [], $page );

		return $this->render('BlokBundle:Blok:admin\moneyback.html.twig', [ 'paginate' => $paginate, 'list_moneyback' => $list_moneyback ] );

	}

	public function deleteAction( $id )
	{

		CheckPrivInRole::legal( $this->container, $this->role[1], false, $this->priv[1], true );

		$em = $this->getDoctrine()->getManager();
		$user = $em->getRepository('BlokBundle:User')->findOntById( $id );

		if( $user !== null )
		{
			$em->remove($user);
			$em->flush();

			$cache = new FileSystemCache('guest');
			$cache->counter('incr', 'user_count')->flush();
		}

		return $this->redirectToRoute('blok_admin_users' );

	}

	public function bindRolesAction( Request $request, $id )
	{

		CheckPrivInRole::legal( $this->container, $this->role[2], false, '' );

		$em = $this->getDoctrine()->getManager();
		$users = $em->getRepository('BlokBundle:User')->findOneBy( [ 'id' => $id ] );
		$roles = $em->getRepository('BlokBundle:Role')->findAll();

		if( $users === null )
		{
			$this->get('notice')->add( 'danger', $this->error_text[0] );
			return $this->redirectToRoute('blok_admin_users' );
		}

		if( $request->isMethod( 'POST' ) )
		{

			if ( $this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
			{

				if ($users !== null)
				{
					$users->setRole( $_POST['select_role'] );
					$em->flush();
					$this->success = true;
				}
			}

		}

		return $this->render('BlokBundle:Blok:admin\users\roles.html.twig', [ 'roles' => $roles, 'users' => $users ] );

	}

	public function clearAllAction()
	{

		CheckPrivInRole::legal( $this->container, $this->role[2], false, '' );

		$cache = new FileSystemCache('guest');
		$cache->set( 'user_count', 0 )->flush();

		$this->get('notice')->add( 'success', $this->result[4] );
		return $this->redirectToRoute('blok_admin_users' );
	}

	public function deleteClearBanAction()
	{

		$doct = $this->getDoctrine()->getManager();

		$query = $doct->createQuery( 'DELETE BlokBundle:Banned ban WHERE ban.created_at+ban.duration < :expires' );
		$query->execute( [ 'expires' => time() ] );

		$this->get('notice')->add('success', $this->result[3] );
		return $this->redirectToRoute( 'blok_admin_users' );

	}

}