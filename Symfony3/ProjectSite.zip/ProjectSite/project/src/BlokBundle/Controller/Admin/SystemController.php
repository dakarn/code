<?php

namespace BlokBundle\Controller\Admin;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;


class SystemController extends Controller
{


	public function indexAction()
	{

		$systems = [
			'Версия PHP:' => PHP_VERSION,
			'Сервер:' => $_SERVER['SERVER_SOFTWARE'],
			'Путь до Simfony 3:' => $_SERVER['DOCUMENT_ROOT'],
			'Домен:' => $_SERVER['HTTP_HOST'],
			'Использумая база:' => 'MySQL',
			'IP адрес сайта:' => $_SERVER['SERVER_ADDR'],
			'Максимльное время выполнения скрипта:' => ini_get("max_execution_time").' секунд',
		];

		return $this->render('BlokBundle:Blok:admin\system.html.twig', [ 'systems' => $systems ] );
	}

}