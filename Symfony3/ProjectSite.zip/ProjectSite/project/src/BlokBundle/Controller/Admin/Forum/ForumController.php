<?php

namespace BlokBundle\Controller\Admin\Forum;

use BlokBundle\Entity\FormValidator\Admin\AddForumValidator;
use BlokBundle\Helper\ErrorsForm;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class ForumController extends Controller
{

	private $result = [
		'Поздравляем! Форум успешно создан!', 'Поздравляем! Раздел для форума успешно создан!', 'Настройки форума успешно изменеы!',
		'Форума был успешно удален, также подфорумы или/и темы с постами', 'Данный форум был закрыт от написания.',
		'Форум был успешно изменен!', 'Темы пересчитаны в этом форуме.',
	];

	private $error = [
		'Ошибка при создании форума.', 'Ошибка при создании раздела форума.', 'Настройки форума не изменеы!',
		'Форума с таким ID не найдено.',
	];

	public function indexAction()
	{

		$doct = $this->getDoctrine()->getManager();
		$list = $doct->getRepository('BlokBundle:Forum')->findAll();

		foreach( $list as $key => $value )
		{
			$forums[ $value->getParentID() ][] = $value;
		}

		return $this->render('BlokBundle:Blok:admin\forum\forum.html.twig', [ 'forums' => $forums ] );
	}

	private function setSort()
	{
		$sort = 'id';
		$sort_arr = [ 'id' => 'ASC', 'createdAt' => 'ASC', 'updatedAt' => 'DESC', 'countPost' => 'DESC', 'title' => 'DESC' ];

		if( !empty( $_GET['sort'] ) && key_exists( $_GET['sort'], $sort_arr ) )
		{
			$sort = $_GET['sort'];
		}

		return [ 'important' => 'DESC', $sort => $sort_arr[$sort] ];
	}

	public function subForumAction( $id, $page = 1 )
	{

		$doct = $this->getDoctrine()->getManager();
		$subforums = $doct->getRepository('BlokBundle:Forum')->findByParentId( $id );
		$forum = $doct->getRepository('BlokBundle:Forum')->findOneById( $id );
		$subforums_arr = [];

		if( $forum === null )
		{
			return Flash::exec( $this->container, 'd', $this->error[3],'blok_forum' );
		}

		$theme_repos = $doct->getRepository('BlokBundle:Theme');

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $forum->getCountTheme() )->setUrl( '/admin-panel/forum/'.$id.'/page-' )->countOnPage( $this->get('options')->count_theme_on_page );

		$themes = $paginate->setData( $theme_repos, [ 'forumId' => $id ], $this->setSort(), $page );

		foreach( $subforums as $key => $value )
		{
			$subforums_arr[ $value->getParentID() ][] = $value;
		}

		return $this->render('BlokBundle:Blok:admin\forum\subforum.html.twig', [
			'paginate' => $paginate, 'forum' => $forum, 'subforums' => $subforums_arr, 'themes' => $themes ] );
	}


	public function addSectionAction( Request $request )
	{

		if( $request->isMethod( 'POST' ) )
		{

			try
			{
				$validator = $this->get( 'validator' );
				$errors = $validator->validate( new AddForumValidator() );

				if( count( $errors ) > 0 ) { throw new Exception( ErrorsForm::get( $errors ) ); }

				$doct = $this->getDoctrine()->getManager();
				$repos = $doct->getRepository( 'BlokBundle:Forum' );

				$repos->createForum( $doct );

				$this->get('notice')->add('success', $this->result[0] );
				return $this->redirectToRoute('blok_admin_forum' );

			} catch( Exception $e ){

				$this->get('notice')->add('danger', $e->getMessage() );
				return $this->redirectToRoute('blok_admin_forum_section' );
			}

		}

		return $this->render('BlokBundle:Blok:admin\forum\add-forum.html.twig');
	}


	public function addSubsectionAction( Request $request, $id )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository('BlokBundle:Forum');
		$forum = $repos->findOneBy( [ 'id' => $id ] );

		if( $forum === null )
		{
			return Flash::exec( $this->container, 'd', $this->error[3],'blok_admin_forum' );
		}

		$forums = $repos->findByParentId( $forum->getParentId() );

		if( $request->isMethod( 'POST' ) )
		{

			try
			{
				$validator = $this->get( 'validator' );
				$errors = $validator->validate( new AddForumValidator() );

				if( count( $errors ) > 0 ) { throw new Exception( $this->error[1] ); }

				$repos->createSubForum( $doct );

				return Flash::exec( $this->container, 's', $this->result[0],'blok_admin_forum_sub', [ 'id' => $id ]  );

			} catch( Exception $e ){

				return Flash::exec( $this->container, 'd', $e->getMessage(),'blok_admin_forum_subsection', [ 'id' => $id ] );
			}

		}

		return $this->render('BlokBundle:Blok:admin\forum\add-subsection.html.twig', [ 'id' => $id, 'forums' => $forums ] );
	}


	public function optionsAction( Request $request )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Options' );

		$options = $repos->findByType( 'forum', array('type_form' => 'DESC') );

		if( $request->isMethod( 'POST' ) )
		{
			$repos->SaveOptionsForum( $doct, $options );
			$this->get('options')->clearMemory();

			$this->get('notice')->add('success', $this->result[2] ); return $this->redirectToRoute('blok_admin_forum_options' );
		}

		return $this->render('BlokBundle:Blok:admin\forum\options.html.twig', [ 'options' => $options ] );
	}


	public function actAction( Request $request, $act )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Forum' );
		$forum = $repos->findOneById( (int)$_GET['forumid'] );

		if( null === $forum )
		{
			$this->get('notice')->add('danger', $this->error[3] );
			return $this->redirectToRoute('blok_admin_forum' );
		}

		if( $act == 're-count-theme' )
		{
			$this->get('notice')->add('success', $this->result[6] );
			$repos->recountThemeInForum( $doct, $forum );

		} else if( $act == 'closeForum' )
		{
			$this->get('notice')->add('success', $this->result[4] );
			$repos->closeForum( $doct, $forum );

		} else if( $act == 'removeForum' )
		{
			$this->get('notice')->add('success', $this->result[3] );
			$repos->removeForum( $doct, $forum );
		}

		return $this->redirectToRoute('blok_admin_forum' );
	}


	public function testAction( Request $request, $act )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Forum' );

		if( $act == 'create-theme' )
		{
			$repos->createManyThemeTest( $doct );

		} else if( $act == 'create-post' )
		{
			$repos->createManyPostTest( $doct );
		}

		return $this->redirectToRoute('blok_admin_forum' );
	}


	public function editForumAction( Request $request, $forumid )
	{

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Forum' );
		$forum = $repos->findOneById( $forumid );
		$forums = $repos->findByParentId( 0 );
		$success = 's';

		if( null === $forum )
		{
			$this->get('notice')->add('danger', $this->error[3] );
			return $this->redirectToRoute('blok_admin_forum' );
		}

		if( $request->isMethod( 'POST' ) )
		{

			if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
			{
				return $this->redirectToRoute('blok_admin_forum' );
			}

			$result = $repos->SaveEditForum( $doct, $forum );

			if( $result !== true )
			{
				$this->result[5] = $result; $success = 'd';
			}

			return Flash::exec( $this->container,$success, $this->result[5],'blok_admin_forum' );

		}

		$reder_data = ['forum' => $forum, 'forums' => $forums, 'forumid' => $forumid ];

		if( $forum->getParentID() == 0 )
		{
			return $this->render('BlokBundle:Blok:admin\forum\edit-forum.html.twig', $reder_data );
		}

		return $this->render('BlokBundle:Blok:admin\forum\edit-subforum.html.twig', $reder_data );

	}

}