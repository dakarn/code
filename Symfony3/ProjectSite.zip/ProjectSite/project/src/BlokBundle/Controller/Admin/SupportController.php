<?

namespace BlokBundle\Controller\Admin;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\FormValidator\ApplySupportValidator;
use BlokBundle\Helper\CheckPrivInRole;
use BlokBundle\Helper\Flash;
use BlokBundle\Helper\ErrorsForm;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class SupportController extends Controller
{

	private $need_role = [  'ROLE_SUPPORT' ];
	private $errors = [
		'Произошла ошибка при отпраке обращения.',
		'Такого обращения не найдено.',
		'Не заполнено сообщение.',
	];
	private $result = [
		'Ваше обращения успешно отправлено администрации. Ожидайте ответа!',
		'Ваш ответ отослан тех. поддержке!',
		'Топик был окончательно закрыт. Больше нельзя в него писать!',
		'Ваше сообщение отправлено пользователю!',
		'Топик был удален из системы!',
		'Топик снова открыт, теперь писать в него можно!',
		'Сообщение удалено из топика!',
	];


	public function indexAction( Request $request, $page = 1 )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$filter = [];
		$sort = 'createdAt';

		if( !empty( $_GET['filter'] ) )
		{
			switch( $_GET['filter'] )
			{
				case 'open': $filter = [ 'isclose' => 0 ]; break;
				case 'close': $filter = [ 'isclose' => 1 ]; break;
			}
		}

		if( !empty( $_GET['sort'] ) ) $sort = $_GET['sort'];

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Support' );
		$cache = new FileSystemCache('guest');

		if( !$count = $cache->get( 'count_sup_apply' ) )
		{
			$count = $doct->createQuery('SELECT COUNT(sup.id) FROM BlokBundle:Support sup')->getSingleScalarResult();
			$cache->set( 'count_sup_apply', $count )->flush();
		}

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( $this->generateUrl('blok_admin_support') )
			->countOnPage( $this->get( 'options' )->apply_on_page );

		$list_support = $paginate->setData( $repos, [], [$sort => 'DESC' ], $page );


		return $this->render('BlokBundle:Blok:admin\support\index.html.twig',
			[ 'paginate' => $paginate, 'list_support' => $list_support ] );

	}


	public function itemMessageAction( Request $request, $id, $page = 1 )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Support' );
		$repos_msg = $doct->getRepository( 'BlokBundle:SupportMessage' );

		$support = $repos->findOneById( $id );

		if( null === $support )
		{
			return Flash::exec( $this->container,'d', $this->errors[1],'blok_myprofile_message_item', ['id'=>$id] );
		}

		$author_support = $support->getUserTable();

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $repos_msg->getCountMessages($doct, $id) )
			->setUrl( $this->generateUrl('blok_admin_support_item', [ 'id' => $id ] ) )
			->countOnPage( $this->get('options')->msg_tp_on_page  );

		$list_message = $paginate->setPrepare( $this->getDoctrine(), $repos_msg->getMessagesJoinUser($id), $page );

		return $this->render('BlokBundle:Blok:admin\support\item-message.html.twig',
			[ 'paginate' => $paginate, 'list_message' => $list_message, 'author_support' => $author_support, 'support' => $support ] );

	}


	public function actAction( Request $request, $act, $id )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Support' );
		$repos_msg = $doct->getRepository( 'BlokBundle:SupportMessage' );

		if( $act === 'write' )
		{
			$result = $repos_msg->answerSupport( $doct, $id, $this->container );
			$notice= 's';

			if( $result !== true )
			{
				$notice = 'd'; $this->result[3] = $result;
			}

			return Flash::exec( $this->container,$notice, $this->result[3],'blok_admin_support_item', ['id'=>$id] );

		} else if( $act === 'delMsg' )
		{
			$result = $repos_msg->deleteMessage( $doct, $id );
			$notice= 's';

			if( $result !== true )
			{
				$notice = 'd'; $this->result[6] = $result;
			}

			return Flash::exec( $this->container,$notice, $this->result[6],'blok_admin_support_item', ['id'=>$id] );

		} else if( $act === 'delete' )
		{
			$result = $repos->deleteTopic( $doct, $id, $repos, $repos_msg );
			$notice= 's';

			if( $result !== true )
			{
				$notice = 'd'; $this->result[6] = $result;
			}

			return Flash::exec( $this->container,$notice, $this->result[6],'blok_admin_support' );

		}  else if( $act === 'close' )
		{
			$result = $repos->closeTopic( $doct, $id );
			$notice= 's';

			if( $result !== true )
			{
				$notice = 'd'; $this->result[2] = $result;
			}

			return Flash::exec( $this->container,$notice, $this->result[2],'blok_admin_support' );

		}  else if( $act === 'open' )
		{
			$result = $repos->openTopic( $doct, $id );
			$notice= 's';

			if( $result !== true )
			{
				$notice = 'd'; $this->result[5] = $result;
			}

			return Flash::exec( $this->container,$notice, $this->result[5], 'blok_admin_support' );
		}

	}

}

