<?

namespace BlokBundle\Controller\Admin;

use BlokBundle\Helper\MenuLoader;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class PanelController extends Controller {


    public function menuAction()
    {
    	$menu = [];
	    $repos = $this->getDoctrine()->getManager();

	    $menuloader = MenuLoader::getInstance();
	    $res = $menuloader->loader( $repos, 'admin' );

	    foreach( $res as $key => $value )
	    {
	    	$menu[ $value->getParentID() ][] = $value;
	    }

	    return $this->render('BlokBundle:Blok:admin\menu.html.twig', [ 'path_icon' => PATH_TO_MENU_ICON, 'menu' => $menu, 'url' => $_SERVER['REQUEST_URI'] ] );
    }

	public function indexAction( Request $request )
	{

		$menu = $this->getDoctrine()->getRepository('BlokBundle:Menu')->findByType( 'admin' );

		return $this->render('BlokBundle:Blok:admin\index.html.twig', [
			'menu' => $menu ] );

	}


}