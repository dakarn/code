<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\User;
use BlokBundle\Helper\CheckPrivInRole;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use BlokBundle\Entity\GuestBook;
use Symfony\Component\Config\Definition\Exception\Exception;


class GuestController extends Controller {


	private $need_role = [ 'ROLE_MODER_GUEST', 'ROLE_ADMIN' ];
	private $need_priv = [ 'guest:delete', 'guest:answer', 'guest:edit', 'guest:deleteall' ];
	private $result = [ 'Гостевая книга успешно очищена!',
	                    'Системная ошибка при очистке гостевой!',
	                    'Сообщения в количестве %d для теста сгенерированы!',
	                    'Ответ успешно добавлен!',
						'Ошибка при операции!'];

	private function deleteAll()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, $this->need_priv[3], true );


		$connection = $this->getDoctrine()->getConnection();

		if($connection->query( 'TRUNCATE TABLE guestbook' ) )
		{
					$this->get('notice')->add( 'success', $this->result[0] );
					$cache = new FileSystemCache( 'guest' );
					$cache->set( 'guest_count', 0 )->flush()->close();
		} else {
					$this->get('notice')->add( 'danger', $this->result[1] );
		}

		return $this->redirectToRoute('blok_admin_guest');
	}


	private function getCacheCount( FileSystemCache $cache, $doct )
	{

		if( !$count = $cache->get( 'guest_count' ) )
		{
			$count = $doct->createQuery('SELECT COUNT(g.id) FROM BlokBundle:Guestbook g')->getSingleScalarResult();
			$cache->set( 'guest_count', $count )->flush();
		}

		return $count;
	}


	public function indexAction()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );


		if( isset(  $_GET['act'] ) && $_GET['act'] == 'deleteall' )
		{
			$this->get('notice')->add( 'success', $this->result[0] );
			return $this->deleteAll();
		}

		$doct = $this->getDoctrine()->getManager();
		$count = $this->getCacheCount( new FileSystemCache( 'guest' ), $doct );

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->countOnPage(50)->setUrl( $this->generateUrl( 'blok_admin_guest' ) );

		$list_guest = $paginate->setData( $doct->getRepository( 'BlokBundle:GuestBook' ), [], [ 'created_at' => 'DESC' ], 1 );

		return $this->render('BlokBundle:Blok:admin\guest\guest.html.twig', [ 'list_guest' => $list_guest,  'paginate' => $paginate ] );
	}


	public function deleteAction( $id )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, $this->need_priv[0], true );


		$em = $this->getDoctrine()->getManager();
		$message = $em->getRepository('BlokBundle:GuestBook')->find( $id );

		if( $message != null )
		{
			$em->remove($message);
			$em->flush();

			$cache = new FileSystemCache( 'guest' );
			$cache->counter( 'decr','guest_count' )->flush()->close();
		}

		return $this->redirectToRoute('blok_admin_guest' );
	}


	public function editAction( $id = 0 )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, $this->need_priv[2], true );

		if ( $this->isCsrfTokenValid('authenticate', $_POST['_csrf_token'] ) )
		{

			$em = $this->getDoctrine()->getManager();
			$message = $em->getRepository('BlokBundle:GuestBook')->find($id);

			if ($message != null)
			{
				$message->setMessage($_POST['message']);
				$em->flush();
			}

	    }

		return $this->redirectToRoute('blok_admin_guest' );
	}


	public function answerAction()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, $this->need_priv[1], true );


		if ( $this->isCsrfTokenValid('authenticate', $_POST['_csrf_token'] ) )
		{
			$doct = $this->getDoctrine()->getManager();
			$repos = $doct->getRepository( 'BlokBundle:GuestBook' );

			if( $repos->answerGuest( $doct, $this->getUser() ) )
			{
				$this->get('notice')->add('success', $this->result[3]);

			} else {

				$this->get('notice')->add('danger', $this->result[5]);
			}
		}

		return $this->redirectToRoute('blok_admin_guest' );

	}


	public function newTestedAction()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[1], false, '' );

		$message = 'This message is for the high-loaded tests';
		$count = 100000;
		$userID = $this->getUser()->getId();
		$username = $this->getUser()->getUsername();

		$em = $this->getDoctrine()->getManager();

		for( $i = 0; $i < $count; ++$i )
		{
			$guest = new GuestBook();

			$guest->setUserID( $userID )->setCreatedAt( time() )->setUpdatedAt( time() );
			$guest->setMessage( $message )->setUsername( $username );

			$em->persist($guest);
		}

		$em->flush();
		$em->clear();

		$cache = new FileSystemCache( 'guest' );
		$cache->counter( 'incr','guest_count', $count )->flush()->close();

		$this->get('notice')->add( 'success', sprintf( $this->result[2], $count ) );
		return $this->redirectToRoute('blok_admin_guest' );

	}
}