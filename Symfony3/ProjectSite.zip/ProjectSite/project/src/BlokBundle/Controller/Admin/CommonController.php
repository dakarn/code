<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Entity\FormValidator\Admin\AddOptionsValidator;
use BlokBundle\Entity\FormValidator\Admin\CommonValidator;
use BlokBundle\Helper\CheckPrivInRole;
use BlokBundle\Helper\ErrorsForm;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class CommonController extends Controller
{

	private $need_role = [ 'ROLE_ADMIN', 'ROLE_ADMIN_HELPER' ];
	private $result = [
		'Настройки успешно обновлены!',
		'Кеш настроек успешно очищен!',
		'Меню успешно удалено!',
		'Меню добавлено в систему!',
		'Меню успешно изменено!',
		'Новая опция успешно добавлена!'
	];

	private function SaveOptions( $em, $options )
	{

		foreach ( $options as $key => $option )
		{
			if( !isset( $_POST['common_setting'][$option->getName()] ) )
			{
				$value = 'off';
			} else {
				$value = $_POST['common_setting'][$option->getName()];
			}

			$option->setName( $option->getName() );
			$option->setValue( $_POST['common_setting'][$option->getName() ] );
		}

		$em->flush();
		$em->clear();

	}

	public function addOptionsAction( Request $request )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		if( $request->isMethod('POST') )
		{

			$validator = $this->get( 'validator' );
			$errors = $validator->validate( new AddOptionsValidator() );

			if( count( $errors ) == 0 )
			{
				$doct = $this->getDoctrine()->getManager();

				if( $doct->getRepository( 'BlokBundle:Options' )->addOptions( $doct ) )
				{
					$this->get('notice')->add('success', $this->result[5]);
					$this->get('options')->clearMemory();
				}

			} else {

				$this->get('notice')->add('danger', ErrorsForm::get( $errors ) );
			}

		}

		return $this->redirectToRoute( 'blok_admin_common_setting' );
	}

	public function indexAction( Request $request )
	{

		$em = $this->getDoctrine()->getManager();
		$options = $em->getRepository( 'BlokBundle:Options' )->findByType( 'major', array('type_form' => 'DESC') );

		if( $request->isMethod('POST') )
		{

			if( $request->query->has( 'clear_cache' ) )
			{
				$this->get('notice')->add( 'success', $this->result[1] );
				$this->get('options')->clearMemory();
				return $this->redirectToRoute( 'blok_admin_common_setting' );
			}

			$validator = $this->get('validator');
			$errors = $validator->validate( new CommonValidator() );

			if( count( $errors ) > 0 )
			{
				$this->SaveOptions( $em, $options );

				$this->get( 'options' )->clearMemory();
				$this->get('notice')->add( 'success', $this->result[0] );

			} else {

				$this->get('notice')->add('danger', ErrorsForm::get( $errors ) );

			}

			return $this->redirectToRoute( 'blok_admin_common_setting' );

		}

		return $this->render('BlokBundle:Blok:admin\common.html.twig', [ 'options' => $options ] );
	}


	private function runExecute( $rep, $em, $type, $route )
	{

		if ( $this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
		{
			if( $_POST['type'] == 'delete' )
			{
				$this->get('notice')->add( 'success', $this->result[2] );
				$rep->deleteMenu( $em, $rep );
			}

			if( $_POST['type'] == 'add' )
			{
				if( $rep->addMenu( $em, $rep, $type ) )
				{
					$this->get('notice')->add( 'success', $this->result[3] );
				}
			}

			if( $_POST['type'] == 'edit' )
			{
				if( $rep->editMenu( $em, $rep ) )
				{
					$this->get('notice')->add( 'success', $this->result[4] );
				}
			}

			return $this->redirectToRoute( $route );
		}

	}

	public function menuAdminAction( Request $request )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$em = $this->getDoctrine()->getManager();
		$rep = $em->getRepository('BlokBundle:Menu');

		if( $request->isMethod( 'POST' ) )
		{
			return $this->runExecute( $rep, $em, 'admin', 'blok_admin_setting_menu' );
		}

		return $this->render('BlokBundle:Blok:admin\menu\admin.html.twig', [ 'path_icon' => PATH_TO_MENU_ICON, 'menu' => $rep->findByType('admin') ]);

	}


	public function menuUserAction( Request $request )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[1], false, '' );

		$em = $this->getDoctrine()->getManager();
		$rep = $em->getRepository('BlokBundle:Menu');

		if( $request->isMethod( 'POST' ) )
		{
			return $this->runExecute( $rep, $em, 'user', 'blok_admin_users_menu' );
		}

		return $this->render('BlokBundle:Blok:admin\menu\users.html.twig', [ 'path_icon' => PATH_TO_MENU_ICON, 'menu' => $rep->findByType('user') ]);
	}


	public function menuHeaderAction( Request $request )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[1], false, '' );

		$em = $this->getDoctrine()->getManager();
		$rep = $em->getRepository('BlokBundle:Menu');
		$menu = $rep->findByType('header');

		if( $request->isMethod( 'POST' ) )
		{
			return $this->runExecute( $rep, $em, 'header', 'blok_admin_header_menu' );
		}

		return $this->render('BlokBundle:Blok:admin\menu\header.html.twig', [ 'path_icon' => PATH_TO_MENU_ICON, 'menu' => $menu ] );
	}

}