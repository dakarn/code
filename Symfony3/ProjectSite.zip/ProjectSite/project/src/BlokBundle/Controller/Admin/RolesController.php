<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Entity\Privilegy;
use BlokBundle\Helper\CheckPrivInRole;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Validator\Constraints\NotBlank;

class RolesController extends Controller {


	private $need_role = [  'ROLE_ADMIN' ];
	private $errors = [];
	private $result = [
		'Привилегия добавлена успешно!',
		'Не введено название или описание привилегий',
		'Роль успешно добавлена!',
		'Такая роль не найдена в системе.',
		'Роль была удалена.<br>Все пользователи, которые имели эту роль, были ее лишены!',
		'Такая роль была не найдена.',
		'Роль "%s" успешно изменена!',
		'Ошибка при добавлении новой роли.'
	];


	public function indexAction()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$em = $this->getDoctrine()->getManager();
		$roles = $em->getRepository( 'BlokBundle:Role' )->findAll();

		return $this->render('BlokBundle:Blok:admin\roles\roles.html.twig', [ 'roles' => $roles ] );
	}


	public function addPrivAction()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
		{
			return $this->redirectToRoute('blok_admin_roles' );
		}

		if( !empty( $_POST['name_privilegy']) && !empty( $_POST['disc_privilegy']) )
		{
			$em = $this->getDoctrine()->getManager();
			$em->getRepository( 'BlokBundle:Privilegy' )->addPrivilegy( $em );

			$this->get('notice')->add('success', $this->result[0] );

		} else {

			$this->get('notice')->add('danger',  $this->result[1] );
		}

		return $this->redirectToRoute('blok_admin_roles' );
	}


	public function addAction( Request $request )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		if( $request->isMethod( 'POST' ))
		{

			if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
			{
				return $this->redirectToRoute('blok_admin_roles' );
			}

			$validator = $this->get('validator');
			$this->errors[0] = $validator->validate( $_POST['value_role'], new NotBlank(['message' => 'Имя не введено.'] ));
			$this->errors[1] = $validator->validate( $_POST['name_role'], new NotBlank(['message' => 'Псевдоним не введен.'] ));

			if ( count($this->errors[0] ) == 0 && count( $this->errors[1] ) == 0 )
			{
				$em = $this->getDoctrine()->getManager();

				if( $em->getRepository( 'BlokBundle:Role' )->addRole( $em ) )
				{
					$this->get('notice')->add('success', $this->result[2] );

				} else {

					$this->get('notice')->add('danger', $this->result[7] );
				}

			} else {

				foreach( $this->errors as $value )
				{
					if( !isset( $value[0] ) ) continue;
					$this->get('notice')->add('danger', $value[0]->getMessage() );
				}

			}

		}

		return $this->redirectToRoute('blok_admin_roles' );

	}


	public function deleteAction( $id )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$em = $this->getDoctrine()->getManager();
		$role = $em->getRepository( 'BlokBundle:Role' )->findOneById( $id );

		if( $role == null )
		{
			$this->get('notice')->add( 'danger', 'Такая роль не найдена в системе.' );
		} else {
			$this->get('notice')->add( 'success', 'Роль была удалена.<br>Все пользователи, которые имели эту роль, были ее лишены!' );
		}

		$em->remove( $role );
		$em->flush();

		return $this->redirectToRoute('blok_admin_roles' );

	}


	public function editAction( Request $request, $id )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$em = $this->getDoctrine()->getManager();
		$repos = $em->getRepository( 'BlokBundle:Role' );
		$role = $repos->findOneById( $id );

		try
		{
			if( $role == null )
			{
				$this->get('notice')->add( 'danger', 'Такая роль была не найдена.' );
				throw new Exception( 'blok_admin_roles' );
			}

			if( $request->isMethod( 'POST' ) )
			{

				if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
				{
					return $this->redirectToRoute('blok_admin_roles' );
				}

				$validator = $this->get('validator');
				$this->errors[0] = $validator->validate( $_POST['value_role'], new NotBlank(['message' => 'Имя не введено.'] ));
				$this->errors[1] = $validator->validate( $_POST['name_role'], new NotBlank(['message' => 'Псевдоним не введен.'] ));

				if ( count($this->errors[0] ) == 0 && count( $this->errors[1] ) == 0 )
				{
					$repos->editRole( $em, $role );

					$this->get('notice')->add('success', sprintf( $this->result[6], $role->getName() ) );
					return $this->redirectToRoute('blok_admin_roles');

				}  else {

					foreach( $this->errors as $value )
					{
						if( !isset( $value[0] ) ) continue;
						$this->get('notice')->add('danger', $value[0]->getMessage() );
					}

					throw new Exception( 'blok_admin_roles_edit' );
				}
			}

		} catch ( Exception $e ) {

			return $this->redirectToRoute( $e->getMessage(), [ 'id' => $id ] );
		}

		return $this->render('BlokBundle:Blok:admin\roles\edit.html.twig', [ 'role' => $role ] );

	}


	public function listPrivilegyAction()
	{

		$privilegy = $this->getDoctrine()->getManager()->getRepository( 'BlokBundle:Privilegy' )->findAll();
		return $this->render('BlokBundle:Blok:admin\roles\list-privilegy.html.twig', [ 'privilegy' => $privilegy ] );
	}


}