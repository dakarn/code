<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Helper\CheckPrivInRole;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;


class NotificationController extends Controller
{

	private $result = [
		'Настройки успешно обновлены!',
		'Ошибка при сохранении настроек!',
	];
	private $type = 'notice';


	public function indexAction( Request $request )
	{

		CheckPrivInRole::legal( $this->container, 'ROLE_ADMIN', false, '' );

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:Options' );

		$options = $repos->findByType( $this->type, ['type_form' => 'DESC'] );

		if( $request->isMethod( 'POST' ) )
		{

			if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
			{
				return $this->redirectToRoute('blok_admin_notice' );
			}

			$repos->SaveOptionsNotice( $doct, $options );
			$this->get('options')->clearMemory();

			$this->get('notice')->add('success', $this->result[0] ); return $this->redirectToRoute('blok_admin_notice' );
		}

		return $this->render('BlokBundle:Blok:admin\notification\index.html.twig', [ 'options' => $options ] );
	}

}