<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\FormBuild\Admin\Banned;
use BlokBundle\Entity\FormValidator\Admin\BannedValidator;
use BlokBundle\Entity\FormValidator\Admin\EditUserValidator;
use BlokBundle\Helper\CheckPrivInRole;
use BlokBundle\Helper\ErrorsForm;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;
use BlokBundle\Entity\FormBuild\Admin\EditUser;

class UsersController extends Controller {


	private $need_role = [  'ROLE_MODER', 'ROLE_MODER', 'ROLE_ADMIN', 'ROLE_SUPPORT' ];
	private $need_priv = [ 'user:ban', 'user:delete', 'user:edit', 'user:deleteall', 'user:testcreate' ];
	private $result = [
		'Сообщение было успшено отправлено!',
		'База пользователей была очищена!',
		'Пользователь был забанен!',
		'Пользователь был разбанен!',
		'Данные аккуанта были успешно изменены', ];
	private $error_text = ['Пользователь с такими данными не найден.',
		'Данный пользователь уже есть в бан-листе.',
		'Возникли технические проблемы при операции.',
		'Сообщение не было отправлено.',
		'Вы не заполнили поле "Сообщение" и/или поле "Тема".'];

	private function getCountUser( FileSystemCache $cache, $doct )
	{

		if( !$count = $cache->get( 'user_count' ) )
		{
			$count = $doct->createQuery('SELECT COUNT(u.id) FROM BlokBundle:User u')->getSingleScalarResult();
			$cache->set( 'user_count', $count )->flush();
		}

		return $count;
	}

	public function indexAction( $page = 1 )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$sort_arr = ['username', 'email', 'balance', 'createdAt'];

		if( !isset( $_GET['sort'] ) || !in_array( $_GET['sort'], $sort_arr ) ){ $_GET['sort'] = 'id'; }


		$doct = $this->getDoctrine()->getManager();
		$user_repos = $doct->getRepository( 'BlokBundle:User' );
		$count = $this->getCountUser( new FileSystemCache( 'guest' ), $doct );

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( $this->generateUrl( 'blok_admin_users' ) );

		$users = $paginate->setPrepare( $this->getDoctrine(), $user_repos->getUserJoin(), $page );

		return $this->render('BlokBundle:Blok:admin\users\users.html.twig', [ 'users' => $users, 'paginate' => $paginate ] );

	}

	public function banAction( Request $request, $id )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, $this->need_priv[0], true );

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository('BlokBundle:Banned');
		$ban = $repos->findOneByUserId( $id );
		$users = $doct->getRepository('BlokBundle:User')->findOneById( $id );

		if ( $users === null )
		{
			return Flash::exec( $this->container,'d', $this->error_text[0],'blok_admin_users' );
		}

		if ( $ban !== null )
		{
			if( $text = $repos->deleteFromBan( $doct, $ban ) !== true )
			{
				return Flash::exec( $this->container,'d', $text,'blok_admin_users' );
			}

			return Flash::exec( $this->container,'s', $this->result[3],'blok_admin_users' );
		}

		$form = $this->createForm(Banned::class, new BannedValidator());
		$form->handleRequest($request);

		if ( $request->isMethod('POST') )
		{
			try
			{
				if ( !$form->isValid() )
				{
					throw new Exception( ErrorsForm::get( $form->getErrors( true ) ) );
				}

				if (!$repos->addToBan($doct, $id, $form))
				{
					throw new Exception($this->error_text[2]);
				}

				return Flash::exec( $this->container,'s', $this->result[2],'blok_admin_users' );


			} catch( Exception $e)
			{
				return Flash::exec( $this->container,'d', $e->getMessage(),'blok_admin_users' );
			}

		}

		return $this->render('BlokBundle:Blok:admin\users\ban.html.twig', [ 'users' => $users, 'form' => $form->createView() ] );

	}

	public function messageAction( Request $request, $id )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[3], false, '' );

		$user = $this->getDoctrine()->getRepository('BlokBundle:User')->findOneById( $id );

		if( $user === null )
		{
			$this->get('notice')->add( 'danger', $this->error_text[0] );
			return $this->redirectToRoute('blok_admin_users' );
		}

		if( $request->isMethod( 'POST' ) )
		{

			try
			{
				if ( !$this->isCsrfTokenValid('authenticate', $_POST['_csrf_token']))
				{
					throw new Exception( $this->error_text[3] );
				}

				if( empty( $_POST['message' ] ) || empty( $_POST['theme' ] ) )
				{
					throw new Exception( $this->error_text[4] );
				}

				$doct = $this->getDoctrine()->getManager();
				$result = $doct->getRepository( 'BlokBundle:Support' )->addMessageToUser( $doct, $id, $this->getUser() );

				$this->get('notice')->add( 'success', $this->result[0] );
				return $this->redirectToRoute('blok_admin_users_message', [ 'id' => $id ] );


			} catch( Exception $e)
			{
				$this->get('notice')->add( 'danger', $e->getMessage() );
				return $this->redirectToRoute('blok_admin_users_message', [ 'id' => $id ] );
			}

		}

		return $this->render('BlokBundle:Blok:admin\users\message.html.twig', [ 'users' => $user ] );

	}

	public function editAction( Request $request, $id )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[2], false, '' );

		$em = $this->getDoctrine()->getManager();
		$repos = $em->getRepository('BlokBundle:User');
		$users = $repos->findOneById( $id );

		if( $users === null )
		{
			$this->get('notice')->add( 'danger', $this->error_text[0] );
			return $this->redirectToRoute('blok_admin_users' );
		}

		$form = $this->createForm( EditUser::class, new EditUserValidator() );
		$form->handleRequest( $request );

		if( $request->isMethod( 'POST' ) )
		{

			if( $form->isValid() )
			{

				if( ( $users->getUsername() == $form->get( 'username' )->getData() && $users->getEmail() == $form->get( 'email' )->getData() )
				|| empty( $errors_exists = $repos->exists_data( $form ) ) )
				{
					$repos->SaveProfile($em, $users, $form, 'adminSaveProfile');
					$this->get('notice')->add('success', $this->result[4] );

				} else {

					$this->get('notice')->add('danger', implode( '<br>', $errors_exists ) );
				}

			} else {

				$this->get('notice')->add('danger', ErrorsForm::get( $form->getErrors( true ) ) );
			}

			return $this->redirectToRoute('blok_admin_users_edit', [ 'id' => $id ] );
		}

		return $this->render('BlokBundle:Blok:admin\users\edit.html.twig',
			[ 'form' => $form->createView(), 'users' => $users ] );

	}

}