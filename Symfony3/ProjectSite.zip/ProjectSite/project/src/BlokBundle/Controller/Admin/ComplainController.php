<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Cache\FileSystemCache;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class ComplainController extends Controller
{

	private $result = [
		'Пользоваткль был успешно создан!',
		'База пользователей была очищена!',
		'Пользователи в количестве %d для теста сгенерированы!',];
	private $error_text = [
		'Пользователь с такими логином или почтой уже существует.',
		'Произошла системная ошибка при создании юзера.'];


	private function getComplainCount( FileSystemCache $cache, $doct )
	{

		if( !$count = $cache->get( 'complain_count' ) )
		{
			$count = $doct->createQuery('SELECT COUNT(c.id) FROM BlokBundle:Complain c')->getSingleScalarResult();
			$cache->set( 'complain_count', $count )->flush();
		}

		return (int)$count;
	}


	public function listComplainAction( Request $request, $page = 1 )
	{

		$doct = $this->getDoctrine()->getManager();
		$complain_repos = $doct->getRepository( 'BlokBundle:Complain' );

		$count = $this->getComplainCount( new FileSystemCache('guest'), $doct );

		$paginate = $this->get( 'pagination' );
		$paginate->setCount( $count )->setUrl( $this->generateUrl('blok_admin_complain') )->countOnPage( $this->get( 'options' )->guest_on_page );

		$list_complain = $paginate->setData( $complain_repos, [], [], $page );

		return $this->render('BlokBundle:Blok:admin\complain.html.twig',
			[ 'paginate' => $paginate, 'list_complain' => $list_complain ] );

	}

}