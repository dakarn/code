<?php

namespace BlokBundle\Controller\Admin;

use BlokBundle\Entity\FormBuild\Admin\News;
use BlokBundle\Entity\FormValidator\Admin\NewsValidator;
use BlokBundle\Helper\CheckPrivInRole;
use BlokBundle\Helper\ErrorsForm;
use BlokBundle\Helper\Flash;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\HttpFoundation\Request;


class NewsController extends Controller
{

	private $need_role = [ 'ROLE_ADMIN_HELPER', 'ROLE_MODER', 'ROLE_ADMIN' ];
	private $need_priv = [ 'news:create', 'news:delete', 'news:edit' ];
	private $result = [
		'Новость успешно добавлена!',
		'Новость успешно изменена!',
		'Новость успешно удалена!',
		'Приватность комментирования изменена!',
		'База с новостями и комментариями была очищена и удалена!'
	];
	private $error = [
		'Данная новость не найдена.'
	];


	public function addNews( $request )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$form = $this->createForm( News::class, new NewsValidator() );
		$form->handleRequest( $request );

		if( $request->isMethod( 'POST' ) )
		{

			try
			{
				$doct = $this->getDoctrine()->getManager();
				$repos = $doct->getRepository( 'BlokBundle:News' );
				$result = $repos->createNews( $doct, $form, $this->container );

				if( $result !== true )
				{
					throw new Exception( ErrorsForm::get( $result ) );
				}

				return Flash::exec( $this->container,'s', $this->result[0],'blok_admin_news', ['act'=>'add'] );

			} catch( Exception $e )
			{
				return Flash::exec($this->container,'d', $e->getMessage(),'blok_admin_news', ['act'=>'add'] );

			}

		}

		return $this->render('BlokBundle:Blok:admin\news\add.html.twig', [ 'form' => $form->createView() ]  );
	}


	public function listNews()
	{


		$doct = $this->getDoctrine()->getManager();
		$news = $doct->getRepository( 'BlokBundle:News' )->findBy( [], [ 'createdAt' => 'DESC'], 10 );

		return $this->render('BlokBundle:Blok:admin\news\index.html.twig', [ 'newsall' => $news ] );
	}


	public function deleteNews()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:News' );
		$result = $repos->deleteNews( $doct );

		if( $result !== true )
		{
			$this->result[2] = $result;
		}

		return Flash::exec( $this->container,'s', $this->result[2],'blok_admin_news', ['act'=>'list_news'] );
	}


	public function clearAllNews()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[2], false, '' );

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:News' )->clearAllNews();

		return Flash::exec( $this->container,'s', $this->result[4],'blok_admin_news', ['act'=>'list_news'] );
	}


	public function closeCommentNews()
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[1], false, '' );

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:News' );
		$result = $repos->closeCommentNews( $doct );

		if( $result !== true )
		{
			$this->result[3] = $result;
		}

		return Flash::exec( $this->container,'s', $this->result[3],'blok_admin_news', ['act'=>'list_news'] );
	}


	public function editNews( $request )
	{

		CheckPrivInRole::legal( $this->container, $this->need_role[0], false, '' );

		$doct = $this->getDoctrine()->getManager();
		$repos = $doct->getRepository( 'BlokBundle:News' );
		$news = $repos->findOneById( abs( (int)$_GET['news_id'] ) );

		if( $news === null )
		{
			return Flash::exec($this->container,'s', $this->error[0],'blok_admin_news', ['act'=>'list_news'] );
		}

		$form = $this->createForm( News::class, new NewsValidator() );
		$form->handleRequest( $request );

		if( $request->isMethod( 'POST' ) )
		{

			try
			{
				$result = $repos->editNews( $doct, $news, $form );

				if( $result !== true )
				{
					throw new Exception( ErrorsForm::get( $result ) );
				}

				return Flash::exec( $this->container,'s', $this->result[1],'blok_admin_news', ['act'=>'list_news'] );

			} catch( Exception $e )
			{
				return Flash::exec( $this->container,'d', $e->getMessage(),'blok_admin_news', ['act'=>'list_news'] );

			}

		}

		return $this->render('BlokBundle:Blok:admin\news\edit.html.twig', [ 'form' => $form->createView(), 'news' => $news ]  );
	}


	public function actAction( Request $request, $act )
	{

		switch( $act )
		{
			case 'add': return $this->addNews( $request );  break;
			case 'list_news': return $this->listNews( $request ); break;
			case 'delete': return $this->deleteNews( $request ); break;
			case 'edit': return $this->editNews( $request ); break;
			case 'close-comment': return $this->closeCommentNews( $request ); break;
			case 'clearall': return $this->clearAllNews( $request ); break;
		}


	}

}