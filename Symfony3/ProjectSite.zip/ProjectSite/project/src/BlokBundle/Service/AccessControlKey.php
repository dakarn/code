<?php

namespace BlokBundle\Service;

use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\JsonResponse;


class AccessControlKey {


	private $admin_key_api = '234679';
	private $opt = [];
	private $sc;
	private $doct;
	private $conn;
	private $error = [ 'Ваш ключ API не найден в базе. Проверьте правильность ключа.',
		'У данного ключа истек срок покупки, и он недейстаителен.',
		'Данный функционал требует API ключ для доступа. Вы можете купить его на нашем сайте.',
		'К сожалению, в данный момент работа API приостановлена в связи с возникшими проблемами. Попробуйте снова позже.',
		'У вас нет прав для этого API.',
		'Данный API ключ забанен, как и пользователь купивший этот ключ.' ];

	private $error_code = [ 5, 6, 7, 8, 9, 10 ];
	private $access_control_key = [
		'BlokBundle\Controller\Api\UsersController::getAction',
		'BlokBundle\Controller\Api\SmsController::sendAction',
		'BlokBundle\Controller\Api\UsersController::getallAction',
		'BlokBundle\Controller\Api\GuestController::getAction',
	];


	private function onlyAdminApi()
	{

		if( $this->opt[1] == 'on' && !isset( $_GET['key_admin'] ) )
		{
			throw new Exception( $this->error[4], $this->error_code[4] );
		}

		if( isset( $_GET['key_admin'] )&&  $_GET['key_admin'] !== $this->admin_key_api )
		{
			throw new Exception( $this->error[4], $this->error_code[4] );
		}
	}

	private function enableApi()
	{

		if( !$this->opt[0] == 'on' )
		{
			throw new Exception( $this->error[3], $this->error_code[3] );
		}
	}

	private function setTypeSQL( array $type )
	{

		if( count( $type ) == 1 )
		{
			return 'type_key = "'.$type[0].'" AND ';
		}

		$str = '( ';

		foreach( $type as $value )
		{
			$str .= 'type_key = "'.$value.'" OR ';
		}

		$str = substr( $str, 0,-3 ).' ) AND';
		return 	$str;

	}

	public function __construct( ContainerInterface $sc)
	{
		$this->sc = $sc;
		$this->doct = $this->sc->get('doctrine')->getManager();
		$this->conn = $this->sc->get('doctrine')->getConnection();
		$opt = $this->sc->get('options');
		$this->opt[0] = $opt->key( 'enable_api' );
		$this->opt[1] = $opt->key( 'only_admin_api' );
	}

	public function access_control_key( $method, array $typeKey = ['full'] )
	{

		try
		{

			if( !is_array( $typeKey ) )
			{
				throw new Exception( $this->error[2], $this->error_code[3] );
			}

			$this->onlyAdminApi();
			$this->enableApi();

			if( in_array( $method, $this->access_control_key ))
			{

				if( empty( $_GET['keyCode'] ) )
				{
					throw new Exception( $this->error[2], $this->error_code[2] );
				}


				$query = $this->conn->prepare( 'SELECT k.*, kp.* 
				FROM keys_access k JOIN keys_property kp
				WHERE k.key_code = :code AND '.$this->setTypeSQL($typeKey).' kp.id = k.id' );


				$query->execute( ['code' => $_GET['keyCode'] ] );
				$get_key = $query->fetch( 5 );

				if( $get_key == null )
				{
					throw new Exception( $this->error[0], $this->error_code[0] );
				}

				if( unserialize($get_key->property )['ban'] == 1 )
				{
					throw new Exception( $this->error[5], $this->error_code[5] );
				}

				if( $get_key->expires_at < time() )
				{
					throw new Exception( $this->error[1], $this->error_code[1] );
				}

			}

			return true;

		} catch( Exception $e ) {

			$answer = ['success' => false, 'error' => $e->getMessage(), 'errorCode' => $e->getCode() ];
			return new JsonResponse( json_encode( $answer ), 200, [], true );
		}

	}


	public function access_control_key_auth( $user, array $typeKey )
	{

		if( !is_array( $typeKey ) ) return false;

		$get_key = $this->doct->getRepository( 'BlokBundle:KeysAccess' )
							  ->findOneBy( [  'userId' => $user->getId(), 'keyType' => $typeKey ] );

		if( $get_key === null )
		{
			return false;
		}

		return true;
	}

}