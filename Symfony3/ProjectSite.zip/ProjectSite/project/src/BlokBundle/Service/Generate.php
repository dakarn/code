<?php

namespace BlokBundle\Service;


class Generate
{

	private $word = 'eitQhZjbuFheiqu0zw4or2o9upmn8vbBxNfa7dq6PYtwTi5poey4bvv3xzm2nR1TUQWRQSJHIOPRUVBNMZAQWSREFDVC';


	public function __construct(){ }


	public function generateKeyCode( $length )
	{
		$len_word = strlen( $this->word );
		$result_word = '';
		$i = 0;

		while( $i < $length )
		{
			$result_word .= $this->word[ rand( 0, $len_word - 1 )];
			++$i;
		}

		return $result_word;
	}


	public function generatePassword( $length )
	{
		$len_word = strlen( $this->word );
		$result_word = '';
		$i = 0;

		while( $i < $length )
		{
			$result_word .= $this->word[ rand( 0, $len_word - 1 )];
			++$i;
		}

		return $result_word;
	}

	public function generateActivateCode( $length )
	{
		$len_word = strlen( $this->word );
		$result_word = '';
		$i = 0;

		while( $i < $length )
		{
			$result_word .= $this->word[ rand( 0, $len_word - 1 )];
			++$i;
		}

		return $result_word;
	}


	public function generateNameImage( $length )
	{
		$len_word = strlen( $this->word );
		$result_word = '';
		$i = 0;

		while( $i < $length )
		{
			$result_word .= $this->word[ rand( 0, $len_word - 1 )];
			++$i;
		}

		return $result_word;
	}

}