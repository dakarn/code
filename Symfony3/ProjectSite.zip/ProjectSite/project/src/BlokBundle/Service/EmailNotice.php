<?php

namespace BlokBundle\Service;

use Symfony\Component\DependencyInjection\ContainerInterface;

class EmailNotice {


	private $sc;


	public function __construct( ContainerInterface $sc )
	{
		$this->sc = $sc;
	}


	private function headers()
	{
		$header = '';
		$headers = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=UTF-8' . "\r\n";
		$headers .= 'From: admin@sf.ru '. "\r\n";

		return $headers;

	}


	public function EmailRegister( $form, $activate_key )
	{

		$site = $this->sc->get('options')->key('site_url');
		$template = 'email/new-user.html.twig';

		$subject = sprintf( 'Регистрация на %s.', strtolower( $site ) );
		$username = $form->get('username')->getData();
		$pass = $form->get('password')->getData();
		$email = $form->get('email')->getData();

		$arr = [ 'username' => $username, 'activate_key' => $activate_key, 'password' => $pass, 'site' => $site ];

		return mail( $email, $subject, $this->sc->get('twig')->render($template, $arr), $this->headers() );

	}


	public function EmailChangePassword( $user, $password_new )
	{

		$site = $this->sc->get('options')->key('site_url');
		$template = 'email/change-password.html.twig';

		$subject = sprintf( 'Изменение пароля на %s.',  strtolower( $site ) );
		$username = $user->getUsername();
		$arr = [ 'username' => $username, 'password' => $password_new, 'site' => $site ];

		return mail( $user->getEmail(), $subject, $this->sc->get('twig')->render($template, $arr), $this->headers() );
	}

	public function EmailChangeProfile( $user )
	{

		$site = $this->sc->get('options')->key('site_url');
		$template = 'email/change-profile.html.twig';

		$subject = sprintf( 'Изменение профиля на %s.',  strtolower( $site ) );
		$arr = [ 'site' => $site ];

		return mail( $user->getEmail(), $subject, $this->sc->get('twig')->render($template, $arr), $this->headers() );
	}


	public function EmailPayment( $user, $count_money, $id )
	{

		$site = $this->sc->get('options')->key('site_url');
		$template = 'email/notice-about-payment.html.twig';

		$subject = sprintf( 'Пополнение личевого счета на сумму %s%s на сайте %s.',
			$this->sc->get('options')->currency, $count_money, strtolower( $site ) );
		$arr = [ 'id' => $id, 'site' => $site, 'user' => $user, 'count_money' => $count_money ];

		return mail( $user->getEmail(), $subject, $this->sc->get('twig')->render($template, $arr), $this->headers() );
	}


	public function EmailAnswerSupport( $user, $support_id )
	{

		$site = $this->sc->get('options')->key('site_url');
		$template = 'email/notice-about-support.html.twig';

		$subject = sprintf( 'Ответ от тех. поддержки на %s.',  strtolower( $site ) );
		$arr = [ 'site' => $site, 'user' => $user, 'support_id' => $support_id ];

		return mail( $user->getEmail(), $subject, $this->sc->get('twig')->render($template, $arr), $this->headers() );
	}


	public function EmailBuy( $user, $count_money, $oper_id )
	{

		$site = $this->sc->get('options')->key('site_url');
		$template = 'email/notice-about-buy.html.twig';

		$subject = sprintf( 'Покупка на %s.', strtolower( $site ) );

		$arr = [ 'text' => '', 'count_money' => $count_money, 'id' => $oper_id, 'user' => $user, 'site' => $site ];

		return mail( $user->getEmail(), $subject, $this->sc->get('twig')->render($template, $arr), $this->headers() );
	}


	public function EmailRecovery( $user, $email, $password )
	{

		$site = $this->sc->get('options')->key('site_url');
		$template = 'email/recovery-password.html.twig';

		$subject = sprintf( 'Восстановление пароля на %s.', strtolower( $site ) );
		$username = $user->getUsername();

		$arr = [ 'username' => $username, 'password' => $password, 'site' => $site ];

		return mail( $email, $subject, $this->sc->get('twig')->render($template, $arr), $this->headers() );
	}

	public function EmailManyAuth( $user )
	{

		$site = $this->sc->get('options')->site_url;
		$template = 'email/notice-many-auth.html.twig';

		$subject = sprintf( 'Слишком частые попытки входа.', strtolower( $site ) );
		$username = $user->getUsername();

		$arr = [ 'site' => $site ];

		return mail( $user->getEmail(), $subject, $this->sc->get('twig')->render($template, $arr), $this->headers() );
	}

	public function EmailLowBalance( $user )
	{

		$site = $this->sc->get('options')->key('site_url');
		$template = 'email/notice-low-balance.html.twig';

		$subject = sprintf( 'Низкий баланс счета на %s.', strtolower( $site ) );
		$username = $user->getUsername();

		$arr = [ 'site' => $site ];

		return mail( $user->getEmail(), $subject, $this->sc->get('twig')->render($template, $arr), $this->headers() );
	}

	public function EmailNewNews( $users, $form )
	{

		$site = $this->sc->get('options')->key('site_url');
		$template = 'email/notice-new-news.html.twig';
		$subject = sprintf( 'Обновление на %s.', strtolower( $site ) );

		$arr = [ 'site' => $site, 'text' => $form->get( 'message' )->getData(),
		'title' => $form->get( 'title' )->getData() ];

		foreach ( $users as $user )
		{
			$arr['user'] = $user;
			mail( $user->getEmail(), $subject, $this->sc->get('twig')->render($template, $arr), $this->headers());
		}

	}

}