<?php

namespace BlokBundle\Service;

use Symfony\Component\Config\Definition\Exception\Exception;
use Symfony\Component\DependencyInjection\ContainerInterface;

class Options
{

	private $sc;
	private $arr_keys = [];
	private $arr_roles = [];
	private $redis;


	public function __construct( ContainerInterface $sc )
	{
		$this->sc = $sc;
	}


	public function clearMemory()
	{
		if( $this->redis === null )
		{
			$this->redis = new \Redis;
			$this->redis->connect('127.0.0.1', 6379 );
		}

		$this->redis->hDel( 'options' );
		$this->redis->hDel( 'roles' );
		$this->redis->flushAll();

	}

	private function loaderRedis()
    {

	    $this->redis = new \Redis;
	    $connect = $this->redis->connect('127.0.0.1', 6379 );

	    $options = $this->redis->hgetAll( 'options' );
	    $roles = $this->redis->hgetAll( 'roles' );

	    if( !$options )
	    {
		    $this->loaderOnlyDB();
		    $this->redis->hmset( 'options', $this->arr_keys );
		    $this->redis->hmset( 'roles', $this->arr_roles );

	    } else {

		    $this->arr_keys = $options;
		    $this->arr_roles = $roles;
	    }

	    $this->redis->close();
	    $this->redis = null;

    }

	private function loaderOnlyDB( $return = false )
	{

		$doct = $this->sc->get('doctrine')->getManager();
		$options = $doct->getRepository( 'BlokBundle:Options' )->findAll();
		$roles = $doct->getRepository( 'BlokBundle:Role' )->findAll();


		foreach( $options as $key => $value )
		{
			$this->arr_keys[ $value->getName() ] = $value->getValue();
		}

		foreach( $roles as $key => $value )
		{
			$this->arr_roles[ $value->getName() ] = $value->getPrivilegy();
		}


		if( $return ) return $this->arr_keys;

	}


	public function getRoles()
	{
		return $this->arr_roles;
	}

	public function loader( $method )
	{
		call_user_func( [$this, $method] );
	}

	public function __get( $name )
	{
		return isset( $this->arr_keys[$name] ) ?  $this->arr_keys[$name] : false;
	}

	public function key( $key )
	{
		return isset( $this->arr_keys[$key] ) ?  $this->arr_keys[$key] : false;
	}


	public function all()
	{
		return $this->arr_keys;
	}


	public function has( $key )
	{
		return isset( $this->arr_keys[$key] ) ? true : false;
	}

}