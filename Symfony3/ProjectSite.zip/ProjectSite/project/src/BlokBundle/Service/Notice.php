<?php

namespace BlokBundle\Service;

use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Session\Session;

class Notice {


	private $text;
	private $sc;
	private $html_code = '<div class="alert alert-%s"><b><span class="glyphicon glyphicon-%s"></span> %s</b></div>';

	public function __construct( ContainerInterface $sc)
	{
		$this->sc = $sc;
	}

	public function add( $type, $text )
	{
		$this->text = $text;

		if( is_array( $text ) ){ $this->text = implode( '', $this->text ); }

		$session = new Session();
		$session->getFlashBag()->add( $type, $this->text.'' );

	}

	public function render()
	{
		$flashes = new Session();
		$flashes = $flashes->getFlashBag()->all();

		if( count( $flashes ) == 0 ) return;

		$flash = '<p>';
		$type_glyph = 'exclamation-sign';

		foreach( $flashes as $key=>$value )
		{

			if( $key == 'success' ){ $type_glyph = 'ok'; }

			$flash .= sprintf( $this->html_code, htmlspecialchars( $key ), $type_glyph, $value[0] );
		}

		return $flash.'</p><br>';
	}

	public function getAll()
	{
		$flash = [];
		$flashes = new Session();
		$flashes = $flashes->getFlashBag()->all();

		foreach( $flashes as $key=>$value )
		{
			$flash[] = [ 'type' => $key, 'text' => $value[0] ];
		}

		return $flash;
	}

	public function get( $type )
	{
	}

}