<?php

namespace BlokBundle\EventListener;

use BlokBundle\Cache\FileSystemCache;
use BlokBundle\Entity\VisitHost;
use Symfony\Component\HttpKernel\Event\GetResponseEvent;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Session\Session;


class RequestListener {


    private $sc;
    private $user;
    private $doct;


	public function __construct(  ContainerInterface $sc )
	{
		$this->sc = $sc;
	}

	public function onKernelRequest( GetResponseEvent $event )
	{

		if( $event->isMasterRequest() )
		{

			$this->loadOptions();

			if( $this->sc->get('security.authorization_checker')->isGranted('ROLE_USER' ) )
			{
				$this->user = $this->sc->get('security.token_storage')->getToken()->getUser();
				$this->updateUser();
				$this->isBanned();
			}

			$this->visitHost();

		}

	}


	private function loadOptions()
	{
		$this->sc->get('options')->loader( 'loaderRedis' );
	}


	private  function isBanned()
	{

		$session = new Session();

		if( $session->has( 'ban_user' ) ){ return true; }

		$ban = $this->doct->getRepository('BlokBundle:Banned')->findOneByUserId( $this->user->id );

		if( $ban !== null )
		{
			$session->set('ban_user', $ban );
		}

	}

	private function updateUser()
	{

		$this->doct = $this->sc->get('doctrine')->getManager();

		$this->user->setUpdatedAt( time() );
		$this->user->setLastEnter( serialize( [$_SERVER['REMOTE_ADDR'] , $_SERVER['HTTP_USER_AGENT'] ] ) );
		$this->doct->persist( $this->user );
		$this->doct->flush();
	}


	private function visitHost()
	{

		if( $this->doct === null )
		{
			$this->doct = $this->sc->get('doctrine')->getManager();
		}

		$cache = new FileSystemCache('guest');

		$ip = $_SERVER['REMOTE_ADDR'];
		$ref = $_SERVER['HTTP_REFERER'] ?? '';
		$ua = $_SERVER['HTTP_USER_AGENT'] ?? '';

		$visit = $this->doct->getRepository('BlokBundle:VisitHost')->findOneBy([ 'ip' => ip2long($ip) ]);

		if( $visit === null )
		{
			$visit = new VisitHost();
			$visit->setIp( ip2long($ip) )->setReferer( $ref )->setCountVisit( 0 );
			$visit->setUa( $ua )->setVisitTime( new \DateTime() );

			$this->doct->persist($visit);
			$this->doct->flush();

			$cache->counter('incr', 'count_uniq_visit');

		} else {

			$visit->setCountVisit( $visit->getCountVisit() + 1 );
			$this->doct->flush();

		}


		$cache->counter('incr', 'count_visit')->flush();


	}

}