<?php

namespace BlokBundle\Twig;


class CustomTwigFilter extends \Twig_Extension {


	public function getFilters()
	{
		return array(
			new \Twig_SimpleFilter('bbcode', array($this, 'bbcodeFilter')),
			new \Twig_SimpleFilter('role_name', array($this, 'roleFilter')),
			new \Twig_SimpleFilter('smile', array($this, 'smileFilter')),
			new \Twig_SimpleFilter('currency', array($this, 'currencyFilter')),
			new \Twig_SimpleFilter('gender', array($this, 'genderFilter')),
			new \Twig_SimpleFilter('ban_level', array($this, 'ban_levelFilter')),
			new \Twig_SimpleFilter('keyname', array($this, 'keyNameFilter')),
			new \Twig_SimpleFilter('statusTopic', array($this, 'statusTopicFilter')),
			new \Twig_SimpleFilter('quotePost', array($this, 'quotePostFilter')),
			new \Twig_SimpleFilter('quotePostReverse', array($this, 'quotePostReverseFilter')),
			new \Twig_SimpleFilter('json_decode', array($this, 'jsonDecodeFilter')),
			new \Twig_SimpleFilter('type_support', array($this, 'typeSupportFilter')),
			new \Twig_SimpleFilter('complain', array($this, 'complainFilter')),
			new \Twig_SimpleFilter('numToIp', array($this, 'numToIpFilter')),
		);
	}

	public function bbcodeFilter( $text )
    {

    	$spoiler = '<div style="padding: 10px;border: thin solid gray;" onClick=$(".spoiler").slideToggle();>Спойлер<br><br><div style="display: none;" class="spoiler">dfdfd</div></div>';

    	$text = preg_replace( '|\[small\](.*)\[/small\]|U', '<small>$1</small>', $text );
    	$text = preg_replace( '|\[underline\](.*)\[/underline\]|U', '<span style="text-decoration: underline">$1</span>', $text );
    	$text = preg_replace( '|\[code\](.*)\[/code\]|U', '<code>$1</code>', $text );
    	$text = preg_replace( '|\[mark\](.*)\[/mark\]|U', '<mark>$1</mark>', $text );
    	$text = preg_replace( '|\[b\](.*)\[/b\]|U', '<b>$1</b>', $text );
    	$text = preg_replace( '|\[em\](.*)\[/em\]|U', '<em>$1</em>', $text );
    	$text = preg_replace( '|\[i\](.*)\[/i\]|U', '<i>$1</i>', $text );
    	$text = preg_replace( '|\[color=([a-z]*)\](.*)\[/color\]|U', '<span style="color: $1;">$2</span>', $text );
	    $text = str_replace( '[br]', '<br>', $text );
	    $text = str_replace( '[p]', '<p>', $text );
	    $text = str_replace( '[/p]', '</p>', $text );
	    $text = str_replace( PHP_EOL, '<br>', $text );

		return $text;
    }

    public function smileFilter( $text )
    {

	    $text = str_replace( ':)', 'Пользователь', $text );
	    $text = str_replace( ';)', 'Пользователь', $text );
	    $text = str_replace( ':(', 'Помощник админа', $text );
	    $text = str_replace( ';(', 'Администратор', $text );
	    $text = str_replace( ':-)', 'Модератор', $text );
	    $text = str_replace( ':D', 'Модератор', $text );
	    $text = str_replace( ':/', 'Модератор', $text );
	    $text = str_replace( ':\'(', 'Модератор', $text );
	    $text = str_replace( '<3', 'Модератор', $text );

		return $text;
    }

	public function typeSupportFilter( $text )
	{

		$text = str_replace( 'payment', 'Пополнение и Оплата', $text );
		$text = str_replace( 'buy', 'Покупка', $text );
		$text = str_replace( 'ban', 'Блокировка', $text );
		$text = str_replace( 'errors', 'Нашли ошибку или баг', $text );
		$text = str_replace( 'idea', 'Идей и предложения', $text );
		$text = str_replace( 'message_admin', 'Сообщение от ТП', $text );

		return $text;
	}

	public function roleFilter( $text )
	{

		$text = str_replace( 'ROLE_USER', 'Пользователь', $text );
		$text = str_replace( 'ROLE_MODER', 'Модератор', $text );
		$text = str_replace( 'ROLE_ADMIN_HELPER', 'Помощник админа', $text );
		$text = str_replace( 'ROLE_ADMIN', 'Администратор', $text );
		$text = str_replace( 'ROLE_SUPPORT', 'Тех. поддержка', $text );
		$text = str_replace( 'ROLE_MODER_GUEST', 'Модератор гостевой книги', $text );
		$text = str_replace( 'ROLE_MODER_FORUM', 'Модератор форума', $text );
		return $text;
	}


	public function currencyFilter( $currency )
	{

		if( strlen( $currency ) == 2 )
		{
			return '0.'.$currency;
		}

		if( strlen( $currency ) == 1 )
		{
			return '0.0'.$currency;
		}

		$end_str = substr( $currency, -2 );

		if( $end_str == '00' )
		{
			$currency = substr( $currency, 0, strlen( $currency)-2 );
			$currency .= '.00';

		} else {

			$currency = substr( $currency, 0, strlen( $currency)-2 );
			$currency .= '.'.$end_str;
		}

		return $currency;
	}


	public function genderFilter( $gender )
	{

		$gender = str_replace( 'other', 'Другое', $gender);
		$gender = str_replace( 'woman', 'Женский', $gender);
		$gender = str_replace( 'man', 'Мужской', $gender);

		return $gender;
	}

	public function complainFilter( $gender )
	{

		$gender = str_replace( 'post', 'На пост форума', $gender);
		$gender = str_replace( 'theme', 'На тему', $gender);
		$gender = str_replace( 'user', 'На юзера', $gender);

		return $gender;
	}

	public function numToIpFilter( $ip )
	{
		return long2ip( $ip );
	}


	public function statusTopicFilter( $topic )
	{

		$topic = str_replace( '1', 'Закрыто', $topic);
		$topic = str_replace( '0', 'Открыто', $topic);

		return $topic;
	}

	public function ban_levelFilter( $ban )
	{

		$ban = str_replace( '6', 'Полный', $ban);
		$ban = str_replace( '5', 'Средний', $ban);
		$ban = str_replace( '4', 'Частичный', $ban);
		$ban = str_replace( '3', 'Слабый', $ban);

		return $ban;
	}


	public function keyNameFilter( $key )
	{

		$key = str_replace( 'full', 'Полный доступ', $key);
		$key = str_replace( 'api', 'Доступ только к API', $key);
		$key = str_replace( 'telephone', 'Доступ только к телефону', $key);
		$key = str_replace( 'hosting', 'Доступ к хостингу', $key);
		$key = str_replace( 'internet', 'Доступ к интернету', $key);
		$key = str_replace( 'sms', 'Доступ к отправке SMS', $key);
		$key = str_replace( 'proxy', 'Доступ к выделенному прокси', $key);

		return $key;
	}


	public function quotePostFilter( $text )
	{
		$text = str_replace( '[quote-post-theme]', '<div class="quote-post-theme">', $text );
		$text = str_replace( '[/quote-post-theme]', '</div>', $text );

		return $text;
	}


	public function quotePostReverseFilter( $text )
	{
		$text = str_replace( '<div class="quote-post-theme">','[quote-post-theme]', $text );
		$text = str_replace( '</div>', '[/quote-post-theme]', $text );

		return $text;
	}

	public function jsonDecodeFilter( $text )
	{

		return json_decode( $text, true );
	}
}

