<?php

use Symfony\Component\HttpFoundation\Request;

define( 'ROOT', $_SERVER['DOCUMENT_ROOT'] );
define( 'PATH_TO_IMAGE', '/assets/image/' );
define( 'PATH_TO_MENU_ICON', '/assets/image/icon-menu/' );
define( 'PATH_TO_PICTURE_FORUM', '/assets/image/forum/' );
define( 'PATH_TO_PICTURE_SUPPORT', '/assets/image/support/' );
define( 'PATH_TO_PICTURE_NEWS', '/assets/image/news/' );

$loader = require __DIR__.'/../app/autoload.php';
include_once __DIR__.'/../var/bootstrap.php.cache';

$kernel = new AppKernel('prod', true );
$kernel->loadClassCache();
//$kernel = new AppCache($kernel);
//Request::enableHttpMethodParameterOverride();


$request = Request::createFromGlobals();
$response = $kernel->handle($request);
$response->send();
$kernel->terminate($request, $response);
