function forum_EditPost( target, post_id ) {


	var update = '#update-post-text-'+post_id;
	var post = '#post-'+post_id;
	var text_post = '.text-post-'+post_id;
	var form_edit = '.form-editpost';
	var url_action = $( '#url_editpost' ).text()+'?post_id='+post_id;
	var quote_class = '<div class="quote-post-theme">';

	$( update ).remove();

	$(target).remove();
	$( post ).html( $( form_edit ).html() );

	text_post = bbcode_reverse( $( text_post ).html() );

	if( text_post.search( quote_class ) !== -1 )
	{
		text_post = text_post.replace( /<div class="quote-post-theme">(.*)<\/div>/g, '');
		text_post = text_post.replace( /<br><p>(.*)<\/p>/g, '$1');
	}

	$( post+' form textarea').val( text_post );
	$( post+' form' ).attr( 'action', url_action );

	$( post ).slideToggle();

}


function assignPicture()
{

	if( $('[name="assign_file[]"]').length > 9 ) return;

	var target = '#block-assing-picture';
	var input = '<input accept="image/*" type="file" name="assign_file[]" value="Выбрать файл"><br>';

	$( target ).append( input );
}

function forum_AnswerPost( username )
{

	var form = '.form-addpost';
	var div = '.form-addpost form textarea';
	var text = '[b]'+username+'[/b], ';

	$( div ).val( text );
	$( form ).slideDown();
}


function forum_QuotePost( id )
{

	var form_div = '.form-addpost';
	var form = '.form-addpost form';
	var inputType = '.form-addpost form input[name=type_post]';
	var div_text = '.block-quote-text';
	var text = $( '.text-post-'+id ).html();
	var addHideenInput = '<input type="hidden" name="post_id_quote" value="'+id+'">';

	$( '[name=post_id_quote]' ).remove();

	$( form ).append( addHideenInput );
	$( inputType ).val( 'quote' );

	$( '.block-quote' ).show();
	$( div_text ).html( text );

	$( form_div ).slideDown();

}


function forum_UsefullPost( post_id )
{

	var url = '/ajax/forum/post/usefull/';
	var target = '#usefull-post-'+post_id;

	$.post( url,  { post_id: post_id },
		function (data) {

			if( data.success )
			{
				$(target).text(data.usefull);
			}

		}, 'json' );
}


function voteInTheme( url, theme_id, csrf )
{

	if( $('.btn-vote').is(':hidden') )
	{
		$('.btn-vote').show();
		$('.bar-vote').hide();
		return;
	}

	var vote_id = $('[name=vote_variant]:checked').val();
	var target = '#block-vote-theme';

	if( !vote_id ) return;

	$.post( url,
		{ theme_id: theme_id, vote_id: vote_id, _csrf_token: csrf },
		function (data) {

			$(target).html(data.text);

		}, 'json' );


}

function voteView()
{
	$('.btn-vote').hide();
	$('.bar-vote').show();
}