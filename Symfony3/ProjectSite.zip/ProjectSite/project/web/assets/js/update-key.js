var Update_Key =( function(){


	var elem_type = [ '[name=duration_key]' ];
	var total_price = '#total-price';
	var total_price_discount = '#total-price-discount';
	var selectPrice;
	var fixedFloat = 2;


	function selectDuration( event )
	{

		var duration = parseFloat( $( this ).children('option:selected').data('ration') );
		$( total_price ).html( (selectPrice * duration).toFixed( fixedFloat ) );

		var full_price = $( total_price ).html();

		var discount = parseFloat( $( this ).children('option:selected').data('discount') );
		$( total_price_discount ).html( ( full_price - ( full_price / 100 ) * discount ).toFixed( fixedFloat ) );

	}


	return {

		init: function()
		{
			$( elem_type[0] ).change( selectDuration )

		},

		addValue: function( price )
		{
			selectPrice = price;
		}
	}

})();


$( document ).ready( function(){


	Update_Key.init();

});
