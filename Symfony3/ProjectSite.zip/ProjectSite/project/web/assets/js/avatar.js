var LoadAvatar = (function(){

	var img;
	var ext = /(jpg|jpeg|png|bmp)/i;
	var size = [];

	function showImgAvatar()
	{

			var reader = new FileReader();
			reader.readAsDataURL(img);

			reader.onload = function (event)
			{
				$('#src-new-avatar').html('<img src="' + event.target.result + '" width="'+size[0]+'px" height="'+size[1]+'px">');
			}
	}

	function checkExtension()
	{
		if( ext.test( img.name ) != 1 )
		{
			return false;
		}

		return true;
	}

	return {

		init: function()
		{
			$('[name=avatar]').change( function( event )
			{
				$('#loadbutton').show();

				if( window.File && window.FileReader) {

					img = event.target.files[0];

					if( !checkExtension() ) return;

					showImgAvatar();

				}
			});
		},

		setSize: function( w, h)
		{
            size = [ w, h ];
		}
	}

})();

$(function() {

	LoadAvatar.init();

});
