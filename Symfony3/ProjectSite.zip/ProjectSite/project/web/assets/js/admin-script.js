var GuestAdmin = (function(){


	return {

		formEdit: function ( form_id ) {

			$('.operation-edit' + form_id ).slideToggle();
		},

		formAnswer: function ( form_id ) {

			$('.operation-answer' + form_id ).slideToggle();

		}
	}

})();


$(document).ready( function() {

	fixed_left_menu();
	priv_list_delet_copy();
	edit_memu_select();

});


function fixed_left_menu()
{

	$(window).scroll( function(){

		if( $('body').height() < 1600 )
		{
			return;
		}

		var style = { 'position': 'fixed', 'top': '20px', 'left': '60px', 'width': '220px' };
		var height = 226;
		var scroll = $(window).scrollTop();

		if( scroll > height )
		{
			$('.menu-render').css( style );

		} else {

			$('.menu-render').removeAttr('style');
		}

	});

}


function edit_memu_select()
{

	var elemEdit = '[name=item_edit]';
	var btn = '#btn-item-edit';

	$( btn ).click( function()
	{
		var itemUrl =  $( elemEdit ).children('option:selected').data('name');
		var itemName =  $( elemEdit ).children('option:selected').html();
		var itemPublic =  $( elemEdit ).children('option:selected').data('public');

		$('[name=new_name]').val( itemName );
		$('[name=new_title]').val( itemUrl );
		$('[name=public_menu]').val( itemPublic );

	});
}

function priv_list_delet_copy()
{

	if( !document.getElementsByName( 'privilegy_role' )[0]  ) return;

	var elem = 'block-items-priv';
	var subelem = 'div';
	var value = $( '[name=privilegy_role]' ).val().split( ';' );
	var span = document.getElementsByClassName( elem )[0].getElementsByTagName( subelem );

	for( var item in span )
	{
		for( var value_val in value )
		{
			if( span[item].innerHTML == value[value_val].trim()+';' ){ span[item].remove(); }
		}
	}

}