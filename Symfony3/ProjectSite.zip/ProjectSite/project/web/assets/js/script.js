$(document).ready( function() {

	$( '[href="//captcha.org/captcha.html?symfony"]' ).html('');
	$( '[href="//captcha.org/captcha.html?symfony"]' ).attr( 'title','');

	$( '.descKey-item' ).click( function( event ){

		$( '#modalKeyCode' ).html( $( this ).data( 'key' ) );
		$( '#modalCreatedKey' ).html( $( this ).data( 'created' ) );
		$( '#modalExpiresKey' ).html( $( this ).data( 'expires' ) );
		$( '#modalTypeKey' ).html( $( this ).data( 'type' ) );

		$('#descKeyModal').modal();

	});

	Notice.startAjax();


});


function location_url( url )
{

	var ok = false;

	if( !arguments[1] ){ var ok = confirm( 'Вы действительно хотите выпольнить операцию?' ); }

	if( ok)
	{
		location.href = 'http://sf.ru' + url.trim();
		return;
	}

	location.href = 'http://sf.ru' + url.trim();

}


function load_history( type )
{

		var action = type;
		var result = '#result-ajax';
		var divshow = '#action';
		var count = '#count-operation';

		$.post('/ajax/history/',
		{
			act: action,
		},
		function(data)
		{

			$( count ).html( data.count );
			$( divshow ).html('');

			$( result+' > tbody' ).html( '' );
			$(result).show();

			for( var item in data.list )
			{
				$(result).append( '<tr><td>'+data.list[item].type+'</td><td>'+data.list[item].created+'</td><td>'+data.list[item].descript+'</td></tr>' );
			}

		}, 'json' );
}


function LoadFormPayment( payment ) {


	var div = '#result-ajax';
	var spl = '<div class="form';

	$.post('/ajax/payment-form/',
		{
			payment: payment,
		},
		function(data)
		{
			data = data.split( spl );

			$( div ).html( spl+data[1] );

		} );

}


function resizePicture( target, to_size_w, to_size_h )
{

	var old_w = target.width;
	var old_h = target.height;

	while( true )
	{
		old_h /= 1.02;
		old_w /= 1.02;

		if( old_w < to_size_w && old_h < to_size_h )
		{
			target.width = old_w;
			target.height = old_h;
			break;
		}

	}

}

function openBindFiles( target, post_id, to_size_w, to_size_h )
{

	var bind = '#bind-files-'+post_id;
	var replace_str = ['plus','minus'];
	var update_pos = '#update-post-text-'+post_id;

	if( $( bind ).attr('data-already') == 0 )
	{
		var images = ( $('#bind-files-' + post_id + ' img') );
		$( bind ).attr('data-already', 1 );

		for (var i = 0; i < images.length; ++i) {
			resizePicture(images[i], to_size_w, to_size_h);
		}

	}

	if( $(bind).is(':visible') ){ replace_str = replace_str.reverse(); }

	$( bind ).slideToggle();
	$( update_pos ).css( 'bottom', -2 );
	$( target ).html( $( target ).html().replace( replace_str[0], replace_str[1] ) );

}


function bbcode_reverse( text )
{

	text = text.replace( /<b>(.*)<\/b>/g, '[b]$1[/b]' );
	text = text.replace( /<i>(.*)<\/i>/g, '[i]$1[/i]' );
	text = text.replace( /<code>(.*)<\/code>/g, '[code]$1[/code]' );
	text = text.replace( /<p>(.*)<\/p>/g, '[p]$1[/p]' );
	text = text.replace( /<em>(.*)<\/em>/g, '[em]$1[/em]' );
	text = text.replace( /<mark>(.*)<\/mark>/g, '[mark]$1[/mark]' );
	text = text.replace( /<small>(.*)<\/small>/g, '[small]$1[/small]' );
	text = text.replace( /<span style="color: ([a-z]*);">(.*)<\/span>/g, '[color=$1]$2[/color]' );
	text = text.replace( /<underline>(.*)<\/underline>/g, '[underline]$1[/underline]' );
	text = text.replace( /<br>/g, '[br]' );

	return text;
}

function loadCommentNews( news_id )
{

	var url = '/ajax/news/get/comments/';
	var target = '#block-comment-list';

	$.post( url,  { news_id: news_id },
		function (data) {

			if( data.success )
			{
				for ( var item in data.list )
				{
					$(target).append( '<div class="news-comment-list">ID: ' + data.list[item].userId + '' +
						'[' + data.list[item].created + ']<br><br>' + data.list[item].text + '</div>');
				}
			}

		}, 'json' );
}

var Notice = (function () {

	var need_loaders = 30;
	var type_speed = [10000,40000,10000];
	var count_loaders = 0;
	var url = '/ajax/notice/get/';
	var target = '.block-interact-notice';
	var btn_close = '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
	var date = '';
	var timer;
	var type_msg = ['Тех. поддержка','Новый пост в теме'];

	function editSpeed()
	{
		++count_loaders;

		if( count_loaders > need_loaders )
		{
			type_speed[0] = type_speed[1];
			clearInterval(timer);
			Notice.startAjax();
		}
	}

	function parseAjax(data)
	{

		var type_text = '';
		count_loaders = 0;
		type_speed[0] = type_speed[2];
		clearInterval(timer);
		Notice.startAjax();

		for ( var item in data.list )
		{

			var js = JSON.parse( data.list[item] );

			if( js.create ) { date = '['+js.create+']'; }

			if( js.type == 'support' ) { type_text = type_msg[0]; }
			if( js.type == 'theme' ) { type_text = type_msg[1]; }

			$(target).html( $(target).html() + '' +
				'<div class="item-list-notice">'+btn_close+'' +
				'<p><b>'+type_text+'</b> '+date+' </p>' +
				''+js.text+'' +
				'</div>' );

		}

	}

	return {

		startAjax: function()
		{

			timer = setInterval( function() {

				Notice.loadNotice();
				editSpeed();

			}, type_speed[0] );

		},

		loadNotice: function()
		{

			$.post( url,  {}, function (data)
			{

				if( data.count == 0 ) return;

				if( data.success )
				{
					parseAjax(data);
				}

			}, 'json' );

		}

	}

})();


var Faq_tabs = {

	div: 'tabs-',
	currentTabs: 'tabs-global',
	switch:	function( elem_id )
	{
			if( this.currentTabs !== '' )
			{
				$( '#'+this.currentTabs ).hide();
			}

			this.currentTabs = this.div+elem_id;
			$( '#'+this.currentTabs ).show();
	}
};