function LoadListNumber()
{

	var result = '#result-ajax';
	var title = '<h4>Список номеров</h4><br>';
	var title_div = '#title-list';
	var notfound = '<div class="alert alert-info"><b>У вас не подключен номер.</b></div>';

	$.post('/ajax/telephone/getlist/',  {},
	function (data) {


			$(result + ' > tbody').html();
			$( title_div ).html( title );

			$(result).show();

			if( data.count == 0 )
			{
				$( result ).html( notfound );
			}

			for ( var item in data.list )
			{
				$(result).append('<tr><td>' + data.list[item].id + '</td><td>' + data.list[item].number + '</td>' +
			    '<td>' + data.list[item].created + '</td><td>' + data.list[item].btn + '</td></tr>');
			}

	}, 'json' );

}