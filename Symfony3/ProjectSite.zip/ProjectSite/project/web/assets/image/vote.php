<?php


class VoteBar {


	private $count_vote = -1;
	private $width = 0;
	private $width_img = 0;
	private $colortext = [200, 230, 255];


	public function __construct()
	{

		$this->build();

		if( $this->count_vote == -1 ) return;

		$this->renderBar();
	}

	private function build()
	{

		if( !isset( $_GET['count_vote'] ) ) return;

		$this->count_vote = intval( $_GET['count_vote'] );
		$this->width_img = $this->count_vote * 8;
		$this->width = round( ( $this->width_img )/2 ) - 6;

	}

	private function renderBar()
	{


		if( $this->count_vote == 1 )
		{
			$this->count_vote = 1;
			$this->width_img = 16;
			$this->width += 3;
		}

		$image=imagecreate( $this->width_img, 25 );
		imagecolorallocate( $image, 0, 100, 0);

		$text=imagecolorallocate( $image, $this->colortext[0], $this->colortext[1], $this->colortext[2] );

		imagestring($image,3, $this->width,5,$this->count_vote.'%', $text);

		header('Content-type: image/jpg');
		imagepng($image);
		imagedestroy($image);

	}

}


new VoteBar();
