<?php if (!class_exists('CaptchaConfiguration')) { return; }


return [
	'ExampleCaptcha' => [
		'UserInputID' => 'captchaCode',
		'ImageWidth' => 260,
		'ImageHeight' => 60,
	],

];